#!/usr/bin/env python3
"""22_figures_3.py — Fig 9 (KEGG loops), Fig 10 (membrane energetics),
Fig 11 (origin dynamics), Fig 12 (lambda2 fragmentation)."""
import os, json, xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures"); PRO = os.path.join(ROOT, "data", "processed")
RAW = os.path.join(ROOT, "data", "raw")
OI = {"orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442",
      "blue": "#0072B2", "verm": "#D55E00", "purple": "#CC79A7", "black": "#000000",
      "grey": "#7F7F7F"}
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "savefig.bbox": "tight", "axes.unicode_minus": False,
})
S = 190/25.4
def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=600); plt.close(fig); print("saved", name)

# ============================================================ Fig 9: KEGG
kegg = json.load(open(os.path.join(PRO, "kegg_topology.json")))
fig = plt.figure(figsize=(S, S*0.40))
gs = fig.add_gridspec(1, 2, width_ratios=[1.15, 1], wspace=0.32)

ax = fig.add_subplot(gs[0, 0])
items = sorted(kegg.values(), key=lambda e: (e["kind"], e["organism"], e["pathway"]))
cols = {"metabolic": OI["blue"], "signaling": OI["orange"]}
ys = np.arange(len(items))[::-1]
for y, e in zip(ys, items):
    ax.barh(y, e["beta1"]/e["nodes"], color=cols[e["kind"]], height=0.62)
ax.set_yticks(ys)
ax.set_yticklabels([f"{e['organism'][:14]} · {e['pathway'][:24]}" for e in items], fontsize=6.0)
ax.set_xlabel("loop density  $\\beta_1 / V$")
ax.set_title("Real KEGG graphs: metabolic loops vs. signalling trees", fontsize=8)
hs = [plt.Rectangle((0, 0), 1, 1, color=cols["metabolic"]),
      plt.Rectangle((0, 0), 1, 1, color=cols["signaling"])]
ax.legend(hs, ["metabolic (stoichiometric)", "signalling (regulatory)"],
          frameon=False, fontsize=6.4, loc="lower right")

ax = fig.add_subplot(gs[0, 1])
# draw TCA cycle compound graph (eco00020), highlight cycles
tree = ET.parse(os.path.join(RAW, "kgml_eco00020.xml")); root = tree.getroot()
G = nx.Graph()
for rxn in root.findall("reaction"):
    subs = [s.attrib["id"] for s in rxn.findall("substrate")]
    prods = [s.attrib["id"] for s in rxn.findall("product")]
    for s in subs:
        for p in prods:
            if s != p: G.add_edge(s, p)
G.remove_nodes_from(list(nx.isolates(G)))
G = max(nx.connected_components(G), key=len) # largest component
H = G if isinstance(G, nx.Graph) else None
# rebuild
G = nx.Graph()
for rxn in root.findall("reaction"):
    subs = [s.attrib["id"] for s in rxn.findall("substrate")]
    prods = [s.attrib["id"] for s in rxn.findall("product")]
    for s in subs:
        for p in prods:
            if s != p: G.add_edge(s, p)
G.remove_nodes_from(list(nx.isolates(G)))
comp = max(nx.connected_components(G), key=len)
H = G.subgraph(comp).copy()
pos = nx.spring_layout(H, seed=14, iterations=200)
cycle_edges = set()
cb = nx.cycle_basis(H)
for cyc in cb:
    for a, b in zip(cyc, cyc[1:] + cyc[:1]):
        cycle_edges.add(frozenset((a, b)))
nx.draw_networkx_edges(H, pos, ax=ax, edge_color="#BBBBBB", width=0.8)
ce = [e for e in H.edges() if frozenset(e) in cycle_edges]
nx.draw_networkx_edges(H, pos, ax=ax, edgelist=ce, edge_color=OI["verm"], width=1.6)
nx.draw_networkx_nodes(H, pos, ax=ax, node_color=OI["sky"], node_size=22, linewidths=0.3)
n, m, cc = H.number_of_nodes(), H.number_of_edges(), nx.number_connected_components(H)
ax.set_title(f"E. coli TCA graph: $V$={n}, $E$={m}, $\\beta_1$={m-n+cc}", fontsize=8)
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)
fig.tight_layout()
save(fig, "fig08_kegg_loops.png")

# ============================================================ Fig 10: membrane energetics
me = json.load(open(os.path.join(PRO, "membrane_energetics.json")))
KB = me["constants"]["kBT_pNnm"]
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))

ax = axes[0]
r = np.linspace(0.1, 60, 400)
for gam, sig, c, lab in [(20, 2.0, OI["blue"], "$\\Gamma$=20 pN, $\\Sigma$=2 mN/m"),
                         (20, 0.5, OI["green"], "$\\Gamma$=20 pN, $\\Sigma$=0.5 mN/m"),
                         (30, 0.5, OI["verm"], "$\\Gamma$=30 pN, $\\Sigma$=0.5 mN/m")]:
    E = (2*np.pi*gam*r - np.pi*sig*r**2) / KB
    ax.plot(r, E, color=c, lw=1.3, label=lab)
ax.axhline(0, color="#999999", lw=0.6)
ax.set_xlabel("pore radius $r$ (nm)")
ax.set_ylabel("pore energy (k$_B$T)")
ax.set_title("Nucleated pores: barrier $\\pi\\Gamma^2/\\Sigma$", fontsize=8.5)
ax.legend(frameon=False, fontsize=6.4, loc="upper right")
ax.set_ylim(-800, 8000)

ax = axes[1]
sc = me["scission"]
systems = ["EPC (kappa=11 kBT)", "ER-like (kappa=15 kBT)", "DOPC (kappa=24 kBT)"]
labels = ["EPC ($\\kappa$=11)", "ER-like ($\\kappa$=15)", "DOPC ($\\kappa$=24)"]
xpos = np.arange(3)
for i, (sysname, lab) in enumerate(zip(systems, labels)):
    vals = sorted([s["barrier_kBT"] for s in sc if s["system"] == sysname])
    for j, v in enumerate(vals):
        ax.bar(i + (j-1)*0.22, v, width=0.2, color=OI["blue"], alpha=0.45 + 0.27*j)
    ax.text(i, max(vals)*1.04, lab, ha="center", fontsize=6.8)
bud = me["budgets"]
ax.bar(3.2, bud["10 GTP (low estimate)"], width=0.28, color=OI["verm"], alpha=0.6)
ax.bar(3.6, bud["25 GTP (mid estimate)"], width=0.28, color=OI["verm"], alpha=0.8)
ax.bar(4.0, bud["50 GTP (high estimate)"], width=0.28, color=OI["verm"])
ax.text(3.6, bud["50 GTP (high estimate)"]*1.04, "dynamin\n10–50 GTP", ha="center", fontsize=6.8,
        color=OI["verm"])
ax.set_yscale("log")
ax.set_xticks([]); ax.set_xlim(-0.6, 4.6)
ax.set_ylabel("energy (k$_B$T)")
ax.set_title("Topological barrier $4\\pi|\\bar\\kappa|$ vs. budget", fontsize=8.5)
fig.tight_layout(w_pad=2.0)
save(fig, "fig07_membrane_energetics.png")

# ============================================================ Fig 11: origin dynamics
od = json.load(open(os.path.join(PRO, "origin_dynamics.json")))
br = json.load(open(os.path.join(PRO, "origin_dynamics_branches.json")))
fig = plt.figure(figsize=(S, S*0.72))
gs = fig.add_gridspec(2, 2, hspace=0.5, wspace=0.33)

ax = fig.add_subplot(gs[0, 0])
for lab, c in [("m", OI["blue"]), ("e", OI["verm"]), ("i", OI["green"])]:
    ax.plot(od["traj"]["sup"]["t"], od["traj"]["sup"][lab], color=c, lw=1.3, label=f"${lab}(t)$")
ax.set_xlabel("time"); ax.set_ylabel("state variables")
ax.set_title("a  ignition above threshold ($\\rho$ = 0.9)", fontsize=8)
ax.legend(frameon=False, fontsize=6.8, loc="center right")

ax = fig.add_subplot(gs[0, 1])
rho = np.array(br["branch"]["rho"]); e = np.array(br["branch"]["e"]); st = np.array(br["branch"]["stable"])
for cl in (1, 2, 3):
    m = st == {1: True, 2: False, 3: False}[cl]
    if cl == 1:
        ax.plot(rho[st], e[st], ".", ms=2.5, color=OI["verm"], label="stable")
    else:
        ax.plot(rho[~st], e[~st], ".", ms=2.5, color=OI["grey"], label="unstable")
ax.axvline(br["rho_SN"], color=OI["black"], ls="--", lw=0.9)
ax.text(br["rho_SN"]+0.02, 0.05, "$\\rho_{SN}\\approx$0.31", fontsize=7)
ax.set_xlabel("coupling $\\rho$"); ax.set_ylabel("steady-state gradient $e^*$")
ax.set_title("b  saddle-node of the live branch", fontsize=8)
ax.legend(frameon=False, fontsize=6.8, loc="upper left")

ax = fig.add_subplot(gs[1, 0])
PH = np.array(od["phase"]["live"])
ax.imshow(PH, origin="lower", aspect="auto", cmap="YlGnBu",
          extent=[min(od["phase"]["rhos"]), max(od["phase"]["rhos"]),
                  min(od["phase"]["ells"]), max(od["phase"]["ells"])])
ax.set_xlabel("coupling $\\rho$"); ax.set_ylabel("leak $\\ell$")
ax.set_title("c  live basin in ($\\rho$, $\\ell$) plane", fontsize=8)

ax = fig.add_subplot(gs[1, 1])
seeds = np.array(br["basin"]["seeds"]); bnd = br["basin"]["boundary"]
xs = [s for s, b in zip(seeds, bnd) if b is not None]
ys = [b for b in bnd if b is not None]
ax.plot(xs, ys, "o-", color=OI["verm"], ms=3.5, lw=1.2)
ax.axhline(br["rho_SN"], color=OI["grey"], ls=":", lw=0.9)
ax.text(0.32, br["rho_SN"]+0.02, "saddle-node", fontsize=6.6, color=OI["grey"])
ax.set_xlabel("founder-pulse seed size $s_0$")
ax.set_ylabel("ignition threshold $\\rho_{ign}$")
ax.set_title("d  small founders need strong coupling", fontsize=8)
fig.tight_layout()
save(fig, "fig11_origin_dynamics.png")

# ============================================================ Fig 12: lambda2 fragmentation
lam = json.load(open(os.path.join(PRO, "lambda2_fragmentation.json")))
res = np.array(lam["results"])
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.38), gridspec_kw=dict(width_ratios=[1.3, 1]))
ax = axes[0]
ax.errorbar(res[:, 0], res[:, 1], yerr=res[:, 2], fmt="o-", color=OI["blue"],
            ms=3.5, lw=1.2, capsize=2)
ax.axvline(0.5, color=OI["verm"], ls="--", lw=1.0)
ax.text(0.505, res[:, 1].max()*0.9, "bond percolation\nthreshold (2-D square lattice)",
        fontsize=6.6, color=OI["verm"])
ax.set_xlabel("edge-pruning probability $p$")
ax.set_ylabel("algebraic connectivity $\\lambda_2$")
ax.set_title("Fragmentation collapses $\\lambda_2$ (28×20 lattice)", fontsize=8.5)

ax = axes[1]
ax.plot(res[:, 0], res[:, 3], "s-", color=OI["green"], ms=3.5, lw=1.2)
ax.set_xlabel("edge-pruning probability $p$")
ax.set_ylabel("P(network connected)")
ax.set_title("Loss of connectivity", fontsize=8.5)
fig.tight_layout(w_pad=1.8)
save(fig, "fig12_lambda2_fragmentation.png")
print("BATCH 3 DONE")
