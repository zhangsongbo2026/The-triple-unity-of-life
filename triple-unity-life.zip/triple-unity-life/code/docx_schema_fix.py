"""docx schema fixer per pandoc-2.9 OMML/wml playbook:
1. m:rPr child order -> [lit, nor, scr, sty, brk, aln]; drop sty when nor present
2. settings.xml: dedupe proofState; enforce element order
3. [Content_Types].xml: ensure png/jpeg defaults
4. document.xml: pStyle first in pPr; spacing after keepNext etc.; pgMar full attributes
5. styles.xml: qFormat after basedOn/next/link, before pPr
"""
import zipfile, shutil, sys, re
from lxml import etree

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'

def qn(ns, tag): return '{%s}%s' % (ns, tag)

def fix_math_rpr(root):
    order = ['lit', 'nor', 'scr', 'sty', 'brk', 'aln']
    for rpr in root.iter(qn(M, 'rPr')):
        children = list(rpr)
        keyed = {}
        others = []
        for ch in children:
            tag = etree.QName(ch).localname
            if tag in order:
                keyed[tag] = ch
            else:
                others.append(ch)
        for ch in children:
            rpr.remove(ch)
        for tag in order:
            if tag in keyed:
                if tag == 'sty' and 'nor' in keyed:
                    continue
                rpr.append(keyed[tag])
        for ch in others:
            rpr.append(ch)

PPR_ORDER = ['pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr', 'widowControl',
             'numPr', 'suppressLineNumbers', 'pBdr', 'shd', 'tabs', 'suppressAutoHyphens',
             'kinsoku', 'wordWrap', 'overflowPunct', 'topLinePunct', 'autoSpaceDE', 'autoSpaceDN',
             'bidi', 'adjustRightInd', 'snapToGrid', 'spacing', 'ind', 'contextualSpacing',
             'mirrorIndents', 'suppressOverlap', 'jc', 'textDirection', 'textAlignment',
             'textboxTightWrap', 'outlineLvl', 'divId', 'cnfStyle', 'rPr', 'sectPr', 'pPrChange']

def fix_ppr(root):
    for ppr in root.iter(qn(W, 'pPr')):
        children = list(ppr)
        def key(ch):
            tag = etree.QName(ch).localname
            return PPR_ORDER.index(tag) if tag in PPR_ORDER else len(PPR_ORDER)+5
        children_sorted = sorted(children, key=key)
        for ch in children: ppr.remove(ch)
        for ch in children_sorted: ppr.append(ch)

def fix_sectpr(root):
    for sect in root.iter(qn(W, 'sectPr')):
        for mar in sect.iter(qn(W, 'pgMar')):
            for att in ['top', 'right', 'bottom', 'left', 'header', 'footer', 'gutter']:
                if mar.get(att) is None:
                    mar.set(att, '0')

def fix_settings(data_bytes):
    root = etree.fromstring(data_bytes)
    # dedupe proofState
    ps = root.findall(qn(W, 'proofState'))
    for extra in ps[1:]:
        root.remove(extra)
    order = ['zoom', 'removePersonalInformation', 'removeDateAndTime', 'doNotDisplayPageBoundaries',
             'displayBackgroundShape', 'printPostScriptOverText', 'printFractionalCharacterWidth',
             'printFormsData', 'embedTrueTypeFonts', 'embedSystemFonts', 'saveSubsetFonts',
             'saveFormsData', 'mirrorMargins', 'alignBordersAndEdges', 'bordersDoNotSurroundHeader',
             'bordersDoNotSurroundFooter', 'gutterAtTop', 'hideSpellingErrors', 'hideGrammaticalErrors',
             'activeWritingStyle', 'proofState', 'formsDesign', 'attachedTemplate', 'linkStyles',
             'stylePaneFormatFilter', 'stylePaneSortMethod', 'documentType', 'mailMerge', 'revisionView',
             'trackChanges', 'doNotTrackMoves', 'doNotTrackFormatting', 'documentProtection',
             'autoFormatOverride', 'styleLockTheme', 'styleLockQFSet', 'defaultTabStop',
             'autoHyphenation', 'consecutiveHyphenLimit', 'hyphenationZone', 'doNotHyphenateCaps',
             'showEnvelope', 'summaryLength', 'clickAndTypeStyle', 'defaultTableStyle', 'evenAndOddHeaders',
             'bookFoldRevPrinting', 'bookFoldPrinting', 'bookFoldPrintingSheets', 'drawingGridHorizontalSpacing',
             'drawingGridVerticalSpacing', 'displayHorizontalDrawingGridEvery', 'displayVerticalDrawingGridEvery',
             'doNotUseMarginsForDrawingGridOrigin', 'drawingGridHorizontalOrigin', 'drawingGridVerticalOrigin',
             'doNotShadeFormData', 'noPunctuationKerning', 'characterSpacingControl', 'printTwoOnOne',
             'strictFirstAndLastChars', 'noLineBreaksAfter', 'noLineBreaksBefore', 'savePreviewPicture',
             'doNotValidateAgainstSchema', 'saveInvalidXml', 'ignoreMixedContent', 'alwaysShowPlaceholderText',
             'doNotDemarcateInvalidXml', 'saveXmlDataOnly', 'useXSLTWhenSaving', 'saveThroughXslt',
             'showXMLTags', 'alwaysMergeEmptyNamespace', 'updateFields', 'hdrShapeDefaults', 'footnotePr',
             'endnotePr', 'compat', 'docVars', 'rsids', 'mathPr', 'attachedSchema', 'themeFontLang', 'clrSchemeMapping',
             'doNotIncludeSubdocsInStats', 'doNotAutoCompressPictures', 'forceUpgrade', 'captions',
             'readModeInkLockDown', 'smartTagType', 'decimalSymbol', 'listSeparator']
    children = list(root)
    def key(ch):
        tag = etree.QName(ch).localname
        return order.index(tag) if tag in order else len(order)+5
    for ch in children: root.remove(ch)
    for ch in sorted(children, key=key): root.append(ch)
    return etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)

def fix_styles(data_bytes):
    root = etree.fromstring(data_bytes)
    for st in root.iter(qn(W, 'style')):
        children = list(st)
        def key(ch):
            tag = etree.QName(ch).localname
            if tag in ('name', 'aliases', 'basedOn', 'next', 'link', 'autoRedefine', 'hidden', 'uiPriority',
                       'semiHidden', 'unhideWhenUsed', 'qFormat', 'locked', 'personal', 'personalCompose',
                       'personalReply', 'rsid', 'pPr', 'rPr', 'tblPr', 'trPr', 'tcPr', 'tblStylePr'):
                return 0
            return 1
        # order: name, aliases, basedOn, next, link, ..., qFormat, pPr, rPr
        sub = {'name':0,'aliases':1,'basedOn':2,'next':3,'link':4,'autoRedefine':5,'hidden':6,
               'uiPriority':7,'semiHidden':8,'unhideWhenUsed':9,'qFormat':10,'locked':11,
               'personal':12,'personalCompose':13,'personalReply':14,'rsid':15,
               'pPr':16,'rPr':17,'tblPr':18,'trPr':19,'tcPr':20,'tblStylePr':21}
        children_sorted = sorted(children, key=lambda ch: sub.get(etree.QName(ch).localname, 99))
        for ch in children: st.remove(ch)
        for ch in children_sorted: st.append(ch)
    return etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)

def main(path):
    tmp = path + '.tmp.docx'
    shutil.copy(path, tmp)
    zin = zipfile.ZipFile(tmp, 'r')
    items = zin.namelist()
    zout = zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED)
    for item in items:
        data = zin.read(item)
        if item == 'word/document.xml':
            root = etree.fromstring(data)
            fix_math_rpr(root); fix_ppr(root); fix_sectpr(root)
            data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
        elif item == 'word/settings.xml':
            data = fix_settings(data)
        elif item == 'word/styles.xml':
            data = fix_styles(data)
        elif item == '[Content_Types].xml':
            txt = data.decode('utf-8')
            for ext, ct in [('png', 'image/png'), ('jpeg', 'image/jpeg'), ('jpg', 'image/jpeg'), ('emf', 'image/x-emf')]:
                if 'Extension="%s"' % ext not in txt:
                    txt = txt.replace('</Types>', '<Default Extension="%s" ContentType="%s"/></Types>' % (ext, ct))
            data = txt.encode('utf-8')
        zout.writestr(item, data)
    zout.close(); zin.close()
    os.remove(tmp)

import os
if __name__ == '__main__':
    main(sys.argv[1])
    print('schema fixes applied to', sys.argv[1])
