#!/usr/bin/env python3
"""21_figures_2.py — Fig 5 (error threshold), Fig 6 (genetic code),
Fig 7 (TDA curves + barcodes), Fig 8 (typing + noise robustness)."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
PRO = os.path.join(ROOT, "data", "processed")
OI = {"orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442",
      "blue": "#0072B2", "verm": "#D55E00", "purple": "#CC79A7", "black": "#000000",
      "grey": "#7F7F7F"}
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "savefig.bbox": "tight", "axes.unicode_minus": False,
})
S = 190/25.4
def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=600); plt.close(fig); print("saved", name)

# ============================================================ Fig 5: error threshold
et = json.load(open(os.path.join(PRO, "error_threshold_sim.json")))
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))

ax = axes[0]
sig = 5.0
U = np.linspace(0, 0.95, 200)
x_exact = np.clip(((1-U)*sig - 1)/(sig-1), 0, 1)
ax.plot(U, x_exact, color=OI["blue"], lw=1.4, label="exact, $\\sigma$ = 5")
ax.plot(et["U"], et["x"], "o", ms=3.5, color=OI["verm"], label="Wright–Fisher simulation")
ax.axvline(et["U_c"], color=OI["black"], lw=1.0, ls="--")
ax.text(et["U_c"]-0.015, 0.72, "$U_c = 1-1/\\sigma$", rotation=90, va="center",
        ha="right", fontsize=7)
ax.set_xlabel("per-genome error rate $U$")
ax.set_ylabel("master-sequence frequency $x$")
ax.set_title("Error threshold (single peak, $L$ = 50)", fontsize=8.5)
ax.legend(frameon=False, fontsize=7, loc="upper right")

ax = axes[1]
L = np.logspace(0.5, 6.7, 200)     # genome size (nt)
for s, c in [(2, OI["sky"]), (5, OI["blue"]), (20, OI["black"])]:
    ax.axhline(1 - 1/s, color=c, lw=1.0, ls="--", alpha=0.8)
    ax.text(2.2, 1 - 1/s + 0.03, f"$\\sigma$ = {s}", fontsize=6.6, color=c)
# real bands (literature-compiled; see text for sources)
ax.fill_between([3, 3.5e4], 0.04, 1.0, color=OI["verm"], alpha=0.16)
ax.text(1.5e2, 0.55, "RNA viruses\n($\\mu_b\\sim10^{-6}$–$10^{-4}$ per nt;\nSanjuán et al. 2010)",
        fontsize=6.4, color=OI["verm"])
ax.fill_between([5e5, 1.3e7], 0.001, 0.006, color=OI["blue"], alpha=0.18)
ax.text(1.1e6, 0.028, "DNA microbes ($U\\approx$0.003; Drake 1991)", fontsize=6.4, color=OI["blue"])
ax.scatter([371], [0.4], marker="s", s=22, color=OI["purple"], zorder=5)
ax.annotate("viroid (Gago et al. 2009)", xy=(371, 0.4), xytext=(1.3e3, 0.62),
            fontsize=6.4, color=OI["purple"],
            arrowprops=dict(arrowstyle="->", lw=0.7, color=OI["purple"]))
# nidovirus proofreading marker
ax.annotate("", xy=(3.8e4, 0.35), xytext=(2.6e4, 0.12),
            arrowprops=dict(arrowstyle="->", lw=1.4, color=OI["green"]))
ax.text(3.9e4, 0.37, "nidovirus proofreading\n(nsp14 ExoN) extends the cap", fontsize=6.4,
        color=OI["green"])
ax.set_xscale("log"); ax.set_ylim(0, 1.05); ax.set_xlim(1e2, 2e7)
ax.set_xlabel("genome size (nt)")
ax.set_ylabel("per-genome error rate $U$")
ax.set_title("Real genomes sit at or below the threshold", fontsize=8.5)
fig.tight_layout(w_pad=1.6)
save(fig, "fig06_error_threshold.png")

# ============================================================ Fig 6: genetic code
cd = json.load(open(os.path.join(PRO, "code_minimization.json")))
ms_rand = np.load(os.path.join(PRO, "code_random_ms_v2.npy"))
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40), gridspec_kw=dict(width_ratios=[1.3, 1]))

ax = axes[0]
ax.hist(ms_rand, bins=120, color=OI["sky"], alpha=0.75, density=True)
ax.axvline(cd["standard"]["Ms"], color=OI["verm"], lw=1.6)
ax.text(cd["standard"]["Ms"]-0.15, ax.get_ylim()[1]*0.9, "standard code", rotation=90,
        ha="right", va="top", fontsize=7, color=OI["verm"])
altc = [OI["orange"], OI["green"], OI["purple"], OI["yellow"], OI["grey"], OI["blue"], OI["black"]]
for (k, v), c in zip(cd["alternatives"].items(), altc):
    ax.axvline(v["Ms"], color=c, lw=0.9, ls=":")
ax.set_xlim(4.5, 18)
ax.set_xlabel("$M_s$: mean squared change in polar requirement")
ax.set_ylabel("density of $10^6$ random codes")
ax.set_title("Standard and variant codes vs. random codes", fontsize=8.5)

ax = axes[1]
names = ["Standard"] + list(cd["alternatives"].keys())
vals = [cd["standard"]["percentile"]] + [v["percentile"] for v in cd["alternatives"].values()]
cols = [OI["verm"]] + altc
ys = np.arange(len(names))[::-1]
ax.barh(ys, vals, color=cols, height=0.62)
ax.set_yticks(ys); ax.set_yticklabels([n[:26] for n in names], fontsize=6.6)
ax.set_xscale("log")
ax.set_xlabel("percentile among $10^6$ random codes (log)")
ax.set_title("All natural codes in the best 0.01%", fontsize=8.5)
for y, v in zip(ys, vals):
    ax.text(v*1.25, y, f"{v:.3f}%", va="center", fontsize=6.4)
ax.set_xlim(8e-5, 2)
fig.tight_layout(w_pad=1.8)
save(fig, "fig05_code_minimization.png")

# ============================================================ Fig 7: TDA curves + barcodes
tda = json.load(open(os.path.join(PRO, "tda_results.json")))
eps = np.load(os.path.join(PRO, "tda_eps_grid.npy"))
show = ["1MBN", "1GFL", "1FHA", "1PMA"]
names = {"1MBN": "myoglobin (153 aa)", "1GFL": "GFP dimer (460 aa)",
         "1FHA": "ferritin 24-mer (4128 aa)", "1PMA": "20S proteasome (5936 aa)"}
fig = plt.figure(figsize=(S, S*0.52))
gs = fig.add_gridspec(2, 4, hspace=0.60, wspace=0.52, height_ratios=[1.25, 1])
for j, pid in enumerate(show):
    ax = fig.add_subplot(gs[0, j])
    cur = tda["tda"][pid]["curves"]
    grid = eps if pid != "1FHA" else np.linspace(0, 40, 96)
    for k, (b, c) in enumerate([("0", OI["blue"]), ("1", OI["orange"]), ("2", OI["verm"])]):
        y = np.array(cur[b])
        ax.plot(grid, y, color=c, lw=1.3, label=f"$\\beta_{k}$")
    ax.set_title(names[pid], fontsize=7.2)
    if j == 0:
        ax.set_ylabel("Betti number")
        ax.legend(frameon=False, fontsize=6.4, loc="upper right")
    ax.set_xlabel("radius $\\varepsilon$ (Å)")

# barcodes for GFP (dimers->cavity) and ferritin
for j, pid in enumerate(["1GFL", "1FHA"]):
    ax = fig.add_subplot(gs[1, j])
    # recompute diagrams quickly from saved feats? We saved dgms only in structure run, not in tda json.
    # Recompute here for the two showcase structures.
    from ripser import ripser
    RAW = os.path.join(ROOT, "data", "raw")
    X = np.load(os.path.join(RAW, ("1FHA_assembly_ca.npy" if pid == "1FHA" else f"{pid}_ca.npy")))
    idx = np.linspace(0, len(X)-1, 350 if pid != "1FHA" else 500).astype(int)
    Xs = X[idx]
    emax = 24 if pid != "1FHA" else 40
    r = ripser(Xs, maxdim=2, thresh=emax)
    for k, (dim, col) in enumerate([(1, OI["orange"]), (2, OI["verm"])]):
        dgm = r["dgms"][dim]
        dgm = dgm[np.isfinite(dgm[:, 1])]
        dgm = dgm[np.argsort(dgm[:, 0])][-28:]   # top 28 bars for readability
        for bi, (b, d) in enumerate(dgm):
            ax.plot([b, d], [bi + (0 if k == 1 else 30)]*2, color=col, lw=1.0)
    ax.set_xlabel("radius $\\varepsilon$ (Å)")
    ax.set_yticks([])
    ax.set_title(f"{pid}: H$_1$ / H$_2$ barcodes", fontsize=7.2)
    ax.set_xlim(0, emax)

# panel letters
for i, ax in enumerate(fig.axes):
    if ax.get_title():
        continue
fig.tight_layout()
save(fig, "fig09_tda_curves.png")

# ============================================================ Fig 8: typing + robustness
pids = tda["pids"]; arch = {p: tda["tda"][p]["arch"] for p in pids}
lab3 = np.array(tda["lab3"]); Vn = np.array(tda["Vn"])
fig = plt.figure(figsize=(S, S*0.36))
gs = fig.add_gridspec(1, 3, wspace=0.42)

# MDS on correlation-normalized curves
C = np.array([np.concatenate([tda["tda"][p]["curves"]["0"],
                              tda["tda"][p]["curves"]["1"],
                              tda["tda"][p]["curves"]["2"]]) for p in pids])
Cn = C / (C.max(axis=1, keepdims=True) + 1e-12)
from scipy.spatial.distance import pdist, squareform
from scipy.cluster.hierarchy import linkage, dendrogram
D = squareform(pdist(Cn, "correlation"))
ax = fig.add_subplot(gs[0, 0])
Z = linkage(Cn, method="average", metric="correlation")
den = dendrogram(Z, labels=pids, ax=ax, color_threshold=1.2, above_threshold_color=OI["grey"],
                 leaf_font_size=5.0, orientation="left")
ax.set_title("average-linkage clustering", fontsize=8)
ax.set_xlabel("correlation distance")

ax = fig.add_subplot(gs[0, 1])
nres = np.array([tda["tda"][p]["n_residues"] for p in pids], float)
b1auc = np.array([tda["tda"][p]["feats"]["b1_auc"] for p in pids])
cmap = {1: OI["verm"], 2: OI["purple"], 3: OI["blue"]}
for cl in (1, 2, 3):
    m = lab3 == cl
    ax.scatter(nres[m], b1auc[m], s=26, color=cmap[cl], label=f"cluster {cl}", zorder=3)
for p, x, y in zip(pids, nres, b1auc):
    if p in ("1PMA", "1OEL", "1BMF", "1FHA", "1MBN", "1GFL"):
        ax.annotate(p, (x, y), textcoords="offset points", xytext=(3, 3), fontsize=5.6)
ax.set_xscale("log")
ax.set_xlabel("residues (log)"); ax.set_ylabel("$\\beta_1$ AUC (normalised)")
ax.set_title("loop content vs. size", fontsize=8)
ax.legend(frameon=False, fontsize=6.2, loc="upper left")

ax = fig.add_subplot(gs[0, 2])
sigs = [0.0, 1.0, 2.0, 3.0]
mk = {"1MBN": "o", "1AKI": "s", "1GFL": "^", "1FHA": "D"}
cl2 = {"1MBN": OI["blue"], "1AKI": OI["orange"], "1GFL": OI["green"], "1FHA": OI["verm"]}
for pid in mk:
    ys = [tda["noise"][f"{pid}_s{s}"]["corr_mean"] for s in sigs]
    es = [tda["noise"][f"{pid}_s{s}"]["corr_sd"] for s in sigs]
    ax.errorbar(sigs, ys, yerr=es, fmt=mk[pid] + "-", color=cl2[pid], ms=3.5,
                lw=1.1, capsize=2, label=pid)
ax.set_xlabel("Gaussian noise on C$\\alpha$ (Å)")
ax.set_ylabel("curve correlation vs. noise-free")
ax.set_ylim(0.90, 1.005)
ax.set_title("robustness to coordinate noise", fontsize=8)
ax.legend(frameon=False, fontsize=6.0, loc="lower left")
fig.tight_layout()
save(fig, "fig10_typing.png")
print("BATCH 2 DONE")
