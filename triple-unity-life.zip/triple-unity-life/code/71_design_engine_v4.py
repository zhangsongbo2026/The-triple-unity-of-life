#!/usr/bin/env python3
"""71_design_engine_v4.py — V4 design table: criterion split + basal-leak (eps) sweep.

Fixes review-round-4 Problem 1: V3's minimal ODE (§6.2) has an exactly absorbing
dead state (founder event necessary), while the V3 design-table criterion (i) was
read as requiring an unstable all-low state (no founder needed).  Resolution:
(a) split criterion (i) into PERSISTENCE (stable all-high attractor + load-bearing
    ring) and SPONTANEOUS GENESIS (system ignites from the near-dead state);
(b) sweep a basal-leak parameter eps added to every node:
        prod_j += EPS * (1 - x_j)
    EPS=0 reproduces the V3 engine exactly; EPS>0 is the basal-flux regime that
    the MM engine's basal enzymes already embody.
Per parameter set we record:
    allon   : some random IC reaches all-ON (>=0.1)
    loadb   : cycle necessity (breaking a cycle edge collapses the all-ON state)
    spont   : ignition from the near-dead IC (0.01,0.01,0.01) to all-high (>=0.5)
    recover : knockdown self-repair (V3 criterion ii)
Q  = # params with allon & loadb   (V3 semantics, continuity)
Qp = # params with allon & loadb & recover (self-maintenance + repair)
nspont = # params with spont
Env: EPS (leak), NPARAM (default 200), RESTRICT=1 (Hamiltonian 3-cycle only),
     SUBSETFILE (path with topo ids, one per line -> subset mode for convergence).
Output: data/design_table_v4_eps{EPS}.json/.csv (+ .npy)
"""
import os, json, math
import numpy as np
from numba import njit

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
SRC = np.array([0,0,0,1,1,1,2,2,2], np.int64)
DST = np.array([0,1,2,0,1,2,0,1,2], np.int64)
NTOPO = 3**9
EPS = float(os.environ.get("EPS", "0.0"))
NPARAM = int(os.environ.get("NPARAM", 200))
G = 5
T = 50.0
DT = 0.1
NSTEP = int(T / DT)
CONV = 1e-3

@njit
def xorshift(state):
    state ^= (state << 13) & 0xFFFFFFFFFFFFFFFF
    state ^= state >> 7
    state ^= (state << 17) & 0xFFFFFFFFFFFFFFFF
    return state

@njit
def u01(state):
    return (state >> 11) * (1.0 / 9007199254740992.0)

@njit
def rhs(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, out):
    for j in range(3):
        prod = 0.0
        deg = 0.0
        for e in range(9):
            if DST[e] != j or s9[e] == 0:
                continue
            xs = x[SRC[e]]
            if s9[e] > 0:
                prod += k[e] * xs * (1.0 - x[j]) / ((1.0 - x[j]) + K[e])
            else:
                deg += k[e] * xs * x[j] / (x[j] + K[e])
        if flags[j] == 1 or flags[j] == 3:
            prod += 0.5 * kb_act[j] * (1.0 - x[j]) / ((1.0 - x[j]) + Kb_act[j])
        if flags[j] == 2 or flags[j] == 3:
            deg += 0.5 * kb_de[j] * x[j] / (x[j] + Kb_de[j])
        prod += eps * (1.0 - x[j])
        out[j] = prod - deg

@njit
def integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, nsteps, outS):
    x0 = x.copy()
    dx = np.zeros(3)
    for step in range(nsteps):
        rhs(x0, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, dx)
        k1 = dx.copy()
        xt = np.empty(3)
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + 0.5 * DT * k1[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, dx)
        k2 = dx.copy()
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + 0.5 * DT * k2[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, dx)
        k3 = dx.copy()
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + DT * k3[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, dx)
        k4 = dx.copy()
        maxd = 0.0
        for j in range(3):
            x0[j] = min(1.0, max(0.0, x0[j] + DT / 6.0 * (k1[j] + 2*k2[j] + 2*k3[j] + k4[j])))
            if abs(k1[j]) > maxd:
                maxd = abs(k1[j])
        if maxd < CONV:
            break
    for j in range(3):
        outS[j] = x0[j]

@njit
def run_topo(tid, s9, cyc_edges, ncyc, nparam, eps):
    Q = 0; Qp = 0; nspont = 0; nrec = 0
    basin_sum = 0.0
    rng_state = (tid * 2654435761 + 12345) & 0xFFFFFFFFFFFFFFFF
    for p in range(nparam):
        rng_state = xorshift(rng_state)
        k = np.zeros(9); K = np.zeros(9)
        for e in range(9):
            if s9[e] != 0:
                rng_state = xorshift(rng_state)
                k[e] = 0.1 * math.pow(100.0, u01(rng_state))
                rng_state = xorshift(rng_state)
                K[e] = 0.001 * math.pow(100000.0, u01(rng_state))
        flags = np.zeros(3, dtype=np.int64)
        kb_act = np.zeros(3); Kb_act = np.zeros(3)
        kb_de = np.zeros(3); Kb_de = np.zeros(3)
        for j in range(3):
            pos_in = 0; neg_in = 0
            for e in range(9):
                if DST[e] == j and s9[e] != 0:
                    if s9[e] > 0:
                        pos_in += 1
                    else:
                        neg_in += 1
            if pos_in > 0 and neg_in == 0:
                flags[j] = 2
            elif neg_in > 0 and pos_in == 0:
                flags[j] = 1
            elif pos_in == 0 and neg_in == 0:
                flags[j] = 3
            if flags[j] == 1 or flags[j] == 3:
                rng_state = xorshift(rng_state)
                kb_act[j] = 0.1 * math.pow(100.0, u01(rng_state))
                rng_state = xorshift(rng_state)
                Kb_act[j] = 0.001 * math.pow(100000.0, u01(rng_state))
            if flags[j] == 2 or flags[j] == 3:
                rng_state = xorshift(rng_state)
                kb_de[j] = 0.1 * math.pow(100.0, u01(rng_state))
                rng_state = xorshift(rng_state)
                Kb_de[j] = 0.001 * math.pow(100000.0, u01(rng_state))
        # spontaneous genesis: near-dead IC
        outS = np.zeros(3)
        xlow = np.array([0.01, 0.01, 0.01])
        integrate(xlow, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, NSTEP, outS)
        spont = True
        for j in range(3):
            if outS[j] < 0.5:
                spont = False
        if spont:
            nspont += 1
        # steady phase: G random ICs
        n_on = 0
        S = np.zeros(3)
        S_count = 0
        for g in range(G):
            x = np.empty(3)
            for j in range(3):
                rng_state = xorshift(rng_state)
                x[j] = 0.05 + 0.9 * u01(rng_state)
            integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, NSTEP, outS)
            on = True
            for j in range(3):
                if outS[j] < 0.1:
                    on = False
            if on:
                n_on += 1
                for j in range(3):
                    S[j] += outS[j]
                S_count += 1
        if n_on == 0:
            continue
        for j in range(3):
            S[j] /= S_count
        basin_frac = n_on / G
        # recovery: 3 knockdowns from S
        ok_rec = True
        for kd in range(3):
            x = S.copy()
            x[kd] *= 0.3
            integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, NSTEP, outS)
            for j in range(3):
                denom = S[j] if S[j] > 0.1 else 0.1
                if outS[j] / denom < 0.8:
                    ok_rec = False
        # cycle-necessity
        load_bearing = False
        for c in range(ncyc):
            if load_bearing:
                break
            for eidx in range(3):
                e = cyc_edges[c, eidx]
                if e < 0 or s9[e] == 0:
                    continue
                s_mod = s9.copy()
                s_mod[e] = 0
                x = S.copy()
                integrate(x, s_mod, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, eps, NSTEP, outS)
                collapsed = False
                for j in range(3):
                    if outS[j] < 0.1:
                        collapsed = True
                if collapsed:
                    load_bearing = True
                    break
        if load_bearing:
            Q += 1
            basin_sum += basin_frac
            if ok_rec:
                Qp += 1
                nrec += 1
    return tid, Q, Qp, nspont, nrec, (basin_sum / Q if Q > 0 else 0.0)

def _worker(t, s, c, n):
    return run_topo(t, s, c, c.shape[0], n, EPS)

def _job(job):
    return _worker(*job)

def main():
    topo = np.zeros((NTOPO, 9), np.int8)
    for t in range(NTOPO):
        v = t
        for e in range(9):
            topo[t, e] = (v % 3) - 1
            v //= 3
    cyc_list = []
    for t in range(NTOPO):
        s = topo[t]
        cyc = []
        for e in range(9):
            if SRC[e] == DST[e] and s[e] != 0:
                cyc.append([e, -1, -1])
        for e1 in range(9):
            for e2 in range(9):
                if SRC[e1] == DST[e2] and DST[e1] == SRC[e2] and SRC[e1] != DST[e1] \
                   and s[e1] != 0 and s[e2] != 0:
                    cyc.append([e1, e2, -1])
        for cycE in ([1, 5, 6], [2, 7, 3]):
            if all(s[e] != 0 for e in cycE):
                cyc.append([cycE[0], cycE[1], cycE[2]])
        if len(cyc) > 0:
            arr = np.full((len(cyc), 3), -1, np.int64)
            for i, c in enumerate(cyc):
                arr[i, :len(c)] = c
            cyc_list.append(arr)
        else:
            cyc_list.append(np.zeros((0, 3), np.int64))
    has_cycle = np.array([len(c) > 0 for c in cyc_list])
    idx_cycle = np.where(has_cycle)[0]
    if os.environ.get("RESTRICT") == "1":
        keep = []
        for t in idx_cycle:
            s = topo[t]
            if (s[1] != 0 and s[5] != 0 and s[6] != 0) or (s[2] != 0 and s[7] != 0 and s[3] != 0):
                keep.append(t)
        idx_cycle = np.array(keep, dtype=idx_cycle.dtype)
    sub = os.environ.get("SUBSETFILE")
    if sub:
        ids = [int(x) for x in open(sub).read().split()]
        idx_cycle = np.array([t for t in idx_cycle if t in set(ids)], dtype=idx_cycle.dtype)
    print(f"EPS={EPS} NPARAM={NPARAM} topologies: {len(idx_cycle)}", flush=True)

    canon = np.zeros(9, np.int8); canon[1] = 1; canon[5] = 1; canon[6] = 1
    canon_id = int(sum(int(v) * (3**e) for e, v in enumerate((canon+1))))

    import time
    from multiprocessing import Pool
    t0 = time.time()
    # warm-up in parent to avoid numba cache races in forked workers
    _ = run_topo(canon_id, topo[canon_id].astype(np.int64), cyc_list[canon_id],
                 cyc_list[canon_id].shape[0], 1, EPS)
    jobs = [(int(tid), topo[tid].astype(np.int64), cyc_list[tid], NPARAM) for tid in idx_cycle]
    with Pool(processes=12, maxtasksperchild=4) as pool:
        done = 0
        out = []
        for r in pool.imap(_job, jobs, chunksize=1):
            out.append(r)
            done += 1
            if done % 100 == 0:
                print(f"progress {done}/{len(jobs)} ({time.time()-t0:.0f}s)", flush=True)
    print(f"pool done in {time.time()-t0:.0f}s", flush=True)

    Qs = np.zeros(NTOPO); Qps = np.zeros(NTOPO); SP = np.zeros(NTOPO); BA = np.zeros(NTOPO)
    for (tid, Q, Qp, nsp, nrec, basin) in out:
        Qs[tid] = Q; Qps[tid] = Qp; SP[tid] = nsp; BA[tid] = basin
    func = np.where(Qs > 0)[0]
    total_params = len(idx_cycle) * NPARAM
    classes = {"all-pos 3-cycle": [], "3-cycle 1-neg": [], "3-cycle 2-neg": []}
    for t in func:
        s = topo[t]
        has3pos = (s[1] > 0 and s[5] > 0 and s[6] > 0) or (s[2] > 0 and s[7] > 0 and s[3] > 0)
        nnegs = []
        for cycE in ([1,5,6], [2,7,3]):
            if all(s[e] != 0 for e in cycE):
                nnegs.append(sum(1 for e in cycE if s[e] < 0))
        nneg = max(nnegs) if nnegs else -1
        if has3pos:
            classes["all-pos 3-cycle"].append(t)
        elif nneg == 1:
            classes["3-cycle 1-neg"].append(t)
        elif nneg >= 2:
            classes["3-cycle 2-neg"].append(t)
    summary = {}
    for kk, ts in classes.items():
        summary[kk] = dict(count=len(ts),
                           median_Q=float(np.median(Qs[ts])) if ts else 0.0,
                           median_Qp=float(np.median(Qps[ts])) if ts else 0.0)
    allspont = int(SP[list(func)].sum()) if len(func) else 0
    outj = dict(EPS=EPS, n_param=NPARAM, n_ic=G, T=T,
                n_topo=int(len(idx_cycle)), functional_count=int(len(func)),
                total_param_sets=int(total_params),
                spont_param_sets=allspont,
                spont_fraction=round(allspont / total_params, 5),
                Q_median=float(np.median(Qs[func])) if len(func) else 0,
                canonical=dict(id=canon_id, Q=float(Qs[canon_id]),
                               Qp=float(Qps[canon_id]), spont=int(SP[canon_id]),
                               basin=float(BA[canon_id])),
                classes=summary)
    tag = ("eps" + str(EPS)).replace(".", "p").replace("-", "m")
    tag += os.environ.get("SUFFIX", "")
    json.dump(outj, open(os.path.join(OUT, f"design_table_v4_{tag}.json"), "w"), indent=1)
    np.savez(os.path.join(OUT, f"design_table_v4_{tag}.npz"), Q=Qs, Qp=Qps, spont=SP, basin=BA)
    import csv
    with open(os.path.join(OUT, f"design_table_v4_{tag}.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["topo_id", "Q", "Qp", "nspont", "basin", "signs(9)"])
        for t in func:
            w.writerow([t, int(Qs[t]), int(Qps[t]), int(SP[t]), f"{BA[t]:.3f}",
                        "".join({-1: "-", 0: "0", 1: "+"}[int(v)] for v in topo[t])])
    print(json.dumps(outj, indent=1))
    print("saved", tag, "total", time.time() - t0)

if __name__ == "__main__":
    main()
