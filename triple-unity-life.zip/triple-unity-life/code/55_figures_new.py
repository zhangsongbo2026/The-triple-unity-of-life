#!/usr/bin/env python3
"""55_figures_new.py — V3 new figures:
fig03 margin statistics | fig09 KEGG blind | fig12 design table |
fig13 basin surface | fig15 SOC avalanches."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures"); PRO = os.path.join(ROOT, "data", "processed")
OI = {"orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442",
      "blue": "#0072B2", "verm": "#D55E00", "purple": "#CC79A7", "black": "#000000",
      "grey": "#7F7F7F"}
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.7, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "savefig.bbox": "tight", "axes.unicode_minus": False})
S = 190/25.4
def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=600); plt.close(fig); print("saved", name)

# ================================================== fig03: margin statistics
ms = json.load(open(os.path.join(PRO, "margin_statistics.json")))
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))
ax = axes[0]
names = [r["system"].replace(" mitochondrion", " mito.").replace("Thermoalkaliphilic ATP synthase", "Thermoalkaliphile")
         for r in ms["systems"]]
pvals = [r["P_margin_pos"] for r in ms["systems"]]
meds = [r["margin_median_kJ"] for r in ms["systems"]]
ci = [r["margin_ci90"] for r in ms["systems"]]
ys = np.arange(len(names))[::-1]
cols = [OI["verm"] if p < 0.5 else OI["green"] for p in pvals]
for y, r, c in zip(ys, ms["systems"], cols):
    lo, hi = r["margin_ci90"]
    ax.plot([lo, hi], [y, y], color=c, lw=1.4, alpha=0.75)
    ax.scatter([r["margin_median_kJ"]], [y], color=c, s=26, zorder=5)
ax.axvline(0, color=OI["black"], lw=1.0, ls="--")
ax.set_yticks(ys); ax.set_yticklabels([f"{n} (c={r['c']})" for n, r in zip(names, ms["systems"])], fontsize=6.6)
ax.set_xlabel("thermodynamic margin $M$ (kJ/mol)")
ax.set_title("Monte-Carlo margins: $P(M>0)$ colours", fontsize=8.5)
ax2 = ax.twiny()
ax2.scatter(pvals, ys, marker="s", s=20, color=OI["blue"], alpha=0.75)
ax2.set_xlabel("$P(M>0)$", color=OI["blue"]); ax2.tick_params(colors=OI["blue"])
ax2.set_xlim(-0.1, 1.25); ax2.spines["top"].set_visible(True)

ax = axes[1]
# null |M| distribution vs real percentiles — recompute null quickly
rng = np.random.default_rng(42)
F = 96.485
c_null = rng.uniform(4, 20, 400000); dp_null = rng.uniform(0.150, 0.250, 400000)
dG_null = rng.uniform(50, 65, 400000)
M_null = (c_null/3.0)*F*dp_null - dG_null
ax.hist(np.abs(M_null), bins=80, color=OI["sky"], alpha=0.75, density=True)
zm = ms["zero_model"]["real_percentiles"]
for (name, pct), c in zip(zm.items(), [OI["verm"], OI["verm"], OI["verm"], OI["blue"], OI["green"], OI["purple"]]):
    short = name.split()[0] if "mito" not in name else name.split()[0]
    ax.axvline(abs(dict((r["system"], abs(r["margin_median_kJ"])) for r in ms["systems"])[name]),
               color=c, lw=1.4)
ax.set_xlim(0, 120)
ax.set_xlabel("|margin| (kJ/mol)")
ax.set_ylabel("null density")
ax.set_title("Real rotors sit near the floor\n(mean 12.5th percentile of null)", fontsize=8.5)
fig.tight_layout(w_pad=2.0)
save(fig, "fig03_margin.png")

# ================================================== fig09: KEGG blind
kb = json.load(open(os.path.join(PRO, "kegg_blind.json")))
import csv as _csv
rows = list(_csv.DictReader(open(os.path.join(PRO, "kegg_features.csv"))))
fig = plt.figure(figsize=(S, S*0.36))
gs = fig.add_gridspec(1, 3, wspace=0.42)
ax = fig.add_subplot(gs[0, 0])
cmap = {"MET": OI["blue"], "GEN": OI["orange"], "ENV": OI["verm"]}
for t in ("MET", "GEN", "ENV"):
    xs = [float(r["frac_cyc"]) for r in rows if r["label"] == t]
    ys2 = [float(r["beta1_over_V"]) for r in rows if r["label"] == t]
    ax.scatter(xs, ys2, s=12, color=cmap[t], alpha=0.65, label=t)
ax.set_xlabel("directed-cycle edge fraction")
ax.set_ylabel("loop density $\\beta_1/V$")
ax.set_title("a  class means differ 4–16x", fontsize=8)
ax.legend(frameon=False, fontsize=6.4)

ax = fig.add_subplot(gs[0, 1])
conf = kb["confusion"]; ks = sorted(conf)
mat = np.array([[conf[k].get(t, 0) for t in ("MET", "GEN", "ENV")] for k in ks], float)
matn = mat / mat.sum(1, keepdims=True)
im = ax.imshow(matn, cmap="YlGnBu", vmin=0, vmax=1)
ax.set_xticks(range(3)); ax.set_xticklabels(["MET", "GEN", "ENV"], fontsize=7)
ax.set_yticks(range(len(ks))); ax.set_yticklabels(ks, fontsize=7)
for i in range(len(ks)):
    for j in range(3):
        ax.text(j, i, f"{matn[i, j]:.2f}", ha="center", va="center", fontsize=6.5,
                color="white" if matn[i, j] > 0.6 else "black")
ax.set_title(f"b  blind clustering, k={kb['best_k']}", fontsize=8)
ax.set_xlabel("true class"); ax.set_ylabel("blind cluster")

ax = fig.add_subplot(gs[0, 2])
zs = kb["nulls"]
labels_z = [z["label"] for z in zs]
zf = [z["frac_cyc_z"] for z in zs]
zl = [z["lam2_z"] for z in zs]
for t in ("MET", "GEN", "ENV"):
    xs = [zf[i] for i in range(len(zs)) if labels_z[i] == t]
    ys3 = [zl[i] for i in range(len(zs)) if labels_z[i] == t]
    ax.scatter(xs, ys3, s=14, color=cmap[t], alpha=0.7, label=t)
ax.axhline(0, color="#999999", lw=0.6); ax.axvline(0, color="#999999", lw=0.6)
ax.set_xlabel("directed-cycle fraction z-score")
ax.set_ylabel("$\\lambda_2$ z-score (deg-preserving null)")
ax.set_title("c  z-scores vs rewired nulls", fontsize=8)
fig.tight_layout()
save(fig, "fig09_kegg_blind.png")

# ================================================== fig12 + fig13: design table & basin
dp = os.path.join(PRO, "design_table_v3.json")
if os.path.exists(dp):
    dt = json.load(open(dp))
    res = np.load(os.path.join(PRO, "design_table_res_v3.npy"))
    fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))
    ax = axes[0]
    cls = dt["classes"]; ks = list(cls)
    xs = np.arange(len(ks))
    ax.bar(xs, [c["count"] for c in cls.values()],
           color=[OI["green"], OI["sky"], OI["orange"], OI["purple"], OI["yellow"], OI["grey"], OI["blue"]][:len(ks)])
    ax.set_yscale("log")
    ax.set_xticks(xs); ax.set_xticklabels([k.replace(" ", "\n") for k in ks], fontsize=6.0)
    ax.set_ylabel("number of functional topologies")
    ax.set_title(f"a  self-maintaining designs (of {dt['n_cycle_topo']})", fontsize=8.5)
    ax2 = ax.twinx(); ax2.spines["top"].set_visible(False)
    med = [c["median_Q"] for c in cls.values()]
    ax2.plot(xs, med, "o--", color=OI["black"], ms=4, lw=1)
    ax2.set_ylabel("median Q", fontsize=7)
    ax = axes[1]
    Qs = res[res[:, 0] > 0, 0]
    ax.hist(np.log10(Qs[Qs > 0]), bins=40, color=OI["sky"], alpha=0.8, density=True)
    qcan = dt["canonical"]["Q"]
    if qcan > 0:
        ax.axvline(np.log10(qcan), color=OI["verm"], lw=1.6)
        ax.text(np.log10(qcan)+0.05, ax.get_ylim()[1]*0.85,
                f"C1$\\wedge$C2$\\wedge$C3\nQ={qcan:.0f}", fontsize=7, color=OI["verm"])
    ax.set_xlabel("$\\log_{10} Q$ (robustness)")
    ax.set_ylabel("density of functional topologies")
    ax.set_title("b  robustness distribution", fontsize=8.5)
    fig.tight_layout(w_pad=2.0)
    save(fig, "fig13_design_table.png")

bs = os.path.join(PRO, "basin_surface.json")
if os.path.exists(bs):
    bs = json.load(open(bs))
    fig, ax = plt.subplots(figsize=(90/25.4, 90/25.4*0.75))
    Bv = np.array(bs["B"])
    im = ax.imshow(Bv, origin="lower", aspect="auto", cmap="viridis",
                   extent=[min(bs["rhos"]), max(bs["rhos"]), min(bs["ells"]), max(bs["ells"])])
    cs = ax.contour(bs["rhos"], bs["ells"], Bv, levels=[0.1, 0.3, 0.5, 0.7, 0.9],
                    colors="white", linewidths=0.7)
    ax.clabel(cs, fontsize=6, fmt="%.1f")
    ax.set_xlabel("coupling $\\rho$"); ax.set_ylabel("leak $\\ell$")
    ax.set_title("Basin volume $B(\\rho,\\ell)$ of the live attractor", fontsize=8.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.046); cb.set_label("fraction of ICs flowing to live state", fontsize=7)
    save(fig, "fig14_basin_surface.png")

# ================================================== fig15: founder patches
fp = os.path.join(PRO, "founder_patch.json")
if os.path.exists(fp):
    fpd = json.load(open(fp))
    fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))
    ax = axes[0]
    rhos = sorted(set(r["rho"] for r in fpd["results"]))
    rads = sorted(set(r["patch_r"] for r in fpd["results"]))
    cmapc = {"extinct": "#BBBBBB", "pinned": OI["orange"], "expanding": OI["green"]}
    for ir, rho in enumerate(rhos):
        for ip, pr in enumerate(rads):
            rs = [r for r in fpd["results"] if r["rho"] == rho and r["patch_r"] == pr]
            cls = set(r["cls"] for r in rs)
            c = cmapc[sorted(cls, key=lambda x: ["extinct", "pinned", "expanding"].index(x))[-1]]
            ax.scatter([ir], [ip], s=180, color=c, marker="s")
    ax.set_xticks(range(len(rhos))); ax.set_xticklabels([f"$\\rho$={r}" for r in rhos], fontsize=7)
    ax.set_yticks(range(len(rads))); ax.set_yticklabels([f"r={r}" for r in rads], fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel("coupling"); ax.set_ylabel("founder patch radius (sites)")
    hs = [plt.Line2D([0], [0], marker="s", color="w", markerfacecolor=c, markersize=7)
          for c in (cmapc["extinct"], cmapc["pinned"], cmapc["expanding"])]
    ax.legend(hs, ["extinct", "pinned island", "expanding"], frameon=False, fontsize=6.2, loc="upper left")
    ax.set_title("a  founder viability is generic; spread is not", fontsize=8)

    ax = axes[1]
    for rho, c in zip(rhos, [OI["blue"], OI["green"], OI["verm"]]):
        rs = sorted([r for r in fpd["results"] if r["rho"] == rho], key=lambda r: r["founder_area"])
        ax.plot([r["founder_area"] for r in rs], [r["live_area"] for r in rs], "o-",
                color=c, ms=3.5, lw=1.1, label=f"$\\rho$={rho}")
    lim = [0, 0.8]
    ax.plot(lim, lim, "k:", lw=0.8)
    ax.text(0.42, 0.36, "live = founder", fontsize=6.4, rotation=38, color=OI["grey"])
    ax.set_xlabel("founder area (fraction of lattice)")
    ax.set_ylabel("live area at t = 400")
    ax.set_title("b  pinned islands: live = founder", fontsize=8)
    ax.legend(frameon=False, fontsize=6.6)
    fig.tight_layout(w_pad=2.0)
    save(fig, "fig15_founder.png")

print("DONE 55")
