#!/usr/bin/env python3
"""20_figures_1.py — Fig 1 (framework), Fig 2 (coupling window), Fig 3 (ET ruler), Fig 4 (homology).
Journal of Theoretical Biology target: single col 90 mm, double col 190 mm; 600 dpi PNG.
"""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from Bio import Phylo

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
PRO = os.path.join(ROOT, "data", "processed")
os.makedirs(FIG, exist_ok=True)

# Okabe-Ito
OI = {"orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442",
      "blue": "#0072B2", "verm": "#D55E00", "purple": "#CC79A7", "black": "#000000",
      "grey": "#7F7F7F"}
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.7, "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 120, "savefig.dpi": 600, "savefig.bbox": "tight",
    "axes.unicode_minus": False,
})

def save(fig, name):
    fig.savefig(os.path.join(FIG, name), dpi=600)
    plt.close(fig)
    print("saved", name)

# ============================================================ Fig 1: framework
S = 190/25.4
fig = plt.figure(figsize=(S, S*0.62))
ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 10); ax.set_ylim(0, 6.2); ax.axis("off")

def box(x, y, w, h, fc, title, lines, title_c="white", tc="#222222"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.06,rounding_size=0.12",
                                fc=fc, ec="none", zorder=2))
    ax.text(x+w/2, y+h-0.28, title, ha="center", va="center", fontsize=9.5,
            fontweight="bold", color=title_c, zorder=3)
    for k, ln in enumerate(lines):
        ax.text(x+w/2, y+h-0.62-0.30*k, ln, ha="center", va="center", fontsize=7.3, color=tc, zorder=3)

def arrow(p1, p2, color, lw=2.2, style="-|>", rad=0.0, lab=None, loff=(0, 0.16)):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=16, lw=lw,
                                 color=color, connectionstyle=f"arc3,rad={rad}", zorder=4))
    if lab:
        mx, my = (p1[0]+p2[0])/2 + loff[0], (p1[1]+p2[1])/2 + loff[1]
        ax.text(mx, my, lab, ha="center", va="center", fontsize=7.6, color=color,
                fontweight="bold", zorder=5)

box(0.15, 3.55, 3.0, 2.35, OI["blue"],
    "Language layer (structure)",
    ["closed membrane, genus $g$  ($\\chi$)",
     "metabolic loops  ($\\beta_1$)",
     "conserved linkage  (Lk)",
     "persistence barcodes  $\\{b_i,d_i\\}$"])
box(3.50, 3.55, 3.0, 2.35, OI["green"],
    "Mechanism layer (energy)",
    ["Nernst–Planck + Mitchell",
     "$\\Delta p$ = 150–250 mV",
     "Marcus tunnelling, 14 Å rule",
     "rotary catalysis $n_H$ = c/3"])
box(6.85, 3.55, 3.0, 2.35, OI["orange"],
    "Symbol layer (information)",
    ["64-codon channel",
     "Hopfield–Ninio proofreading",
     "error-minimised code",
     "quasispecies threshold"])

arrow((3.16, 4.72), (3.50, 4.72), OI["black"], lab="C1", rad=0)
arrow((6.50, 4.72), (6.85, 4.72), OI["black"], lab="C2")
# C3 feedback arrow from symbol back to language (curved underneath)
ax.add_patch(FancyArrowPatch((8.35, 3.52), (1.65, 3.52), arrowstyle="-|>", mutation_scale=16,
                             lw=2.2, color=OI["black"],
                             connectionstyle="arc3,rad=0.35", zorder=4))
ax.text(5.0, 2.02, "C3", ha="center", fontsize=7.6, fontweight="bold", color=OI["black"])
ax.text(5.0, 1.66, "structure → energy → information → structure", ha="center", fontsize=8.0, color="#444444")

ax.text(5.0, 6.02, "Life = closure + gradient + code + continued dissipation",
        ha="center", fontsize=9.2, fontweight="bold", color="#222222")
ax.text(5.0, 0.72, "Closed-loop attractor requires all three: remove one layer and the loop collapses",
        ha="center", fontsize=7.8, color=OI["grey"], style="italic")
ax.text(0.15, 0.18, "evidence discipline:  A empirical · B inference · C model · D interpretation",
        fontsize=7.2, color=OI["grey"])
save(fig, "fig01_framework.png")

# ============================================================ Fig 2: coupling window
cw = json.load(open(os.path.join(PRO, "coupling_window.json")))
F = 96.485
fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40), gridspec_kw=dict(width_ratios=[1.25, 1]))

ax = axes[0]
dp = np.linspace(120, 280, 200)
for dg, c in zip([50, 55, 60, 65], [OI["sky"], OI["blue"], OI["green"], OI["black"]]):
    ax.plot(dp, dg/(F*dp/1000), color=c, lw=1.2, label=f"$\\Delta G_{{ATP}}$ = {dg} kJ/mol")
marks = [("bovine mito (c8)", 8/3, OI["verm"], "8"),
         ("yeast mito (c10)", 10/3, OI["verm"], "10"),
         ("E. coli (c10)", 10/3, OI["verm"], "10"),
         ("chloroplast (c14)", 14/3, OI["green"], "14"),
         ("Spirulina (c15)", 15/3, OI["green"], "15"),
         ("Synechocystis (c13)", 13/3, OI["green"], "13")]
seen = set()
for lab, n, c, ct in marks:
    if ct in seen: continue
    seen.add(ct)
    ax.scatter([None], [n], s=0)  # legend proxy
ring_types = [(8/3, OI["verm"], "8"), (10/3, OI["verm"], "10"),
              (13/3, OI["green"], "13"), (14/3, OI["green"], "14"), (15/3, OI["green"], "15")]
for n, c, ct in ring_types:
    ax.scatter([200 if ct in ("8","10") else 155][0:1]*1, [n], s=26, color=c, zorder=5)
    ax.annotate(f"c{ct}", (200 if ct in ("8","10") else 155, n),
                textcoords="offset points", xytext=(-16, -2), fontsize=7, color=c)
ax.axvspan(150, 250, color=OI["sky"], alpha=0.10)
ax.text(200, 5.9, "measured $\\Delta p$ range\n(150–250 mV)", ha="center", fontsize=7, color=OI["blue"])
ax.set_xlabel("proton-motive force  $\\Delta p$  (mV)")
ax.set_ylabel("minimum $n_H = \\Delta G_{ATP} / (F\\,\\Delta p)$")
ax.set_title("Thermodynamic floor for H$^+$/ATP coupling", fontsize=8.5)
ax.legend(frameon=False, fontsize=6.6, loc="lower left")
ax.set_xlim(120, 280); ax.set_ylim(1.8, 6.2)

ax = axes[1]
sysd = [("H. salinarum", 230, 25, OI["purple"]),
        ("B. subtilis", 220, 20, OI["purple"]),
        ("cardiac mito.", 200, 15, OI["verm"]),
        ("liver mito.", 190, 15, OI["verm"]),
        ("E. coli", 180, 15, OI["blue"]),
        ("yeast mito.", 180, 15, OI["verm"]),
        ("thylakoid", 160, 15, OI["green"]),
        ("S. lactis", 170, 15, OI["sky"])]
ys = np.arange(len(sysd))[::-1]
for (lab, v, e, c), y in zip(sysd, ys):
    ax.errorbar([v], [y], xerr=[[e], [e]], fmt="o", color=c, capsize=2.5, ms=4.5, lw=1.2)
ax.set_yticks(ys); ax.set_yticklabels([s[0] for s in sysd])
ax.set_xlabel("reported $\\Delta p$  (mV)")
ax.set_title("Proton-motive force across life", fontsize=8.5)
ax.set_xlim(130, 265)
fig.tight_layout(w_pad=1.6)
save(fig, "fig02_coupling_window.png")

# ============================================================ Fig 3: ET ruler
fig, ax = plt.subplots(figsize=(90/25.4, 90/25.4*0.78))
d = np.linspace(3, 30, 200)
beta0, beta1 = 1.1, 1.1
k_ref = 1e13  # activationless contact rate, Moser-Dutton convention (10^13 s^-1)
ax.fill_between(d, np.log10(k_ref) - beta1*d, np.log10(k_ref) - 0.9*d,
                color=OI["sky"], alpha=0.25, label="tunneling decay band $\\beta$ = 0.9–1.4 Å$^{-1}$")
ax.fill_between(d, np.log10(k_ref) - 1.4*d, np.log10(k_ref) - 1.35*d,
                color=OI["sky"], alpha=0.18)
ax.plot(d, np.log10(k_ref) - beta0*d, color=OI["blue"], lw=1.6,
        label="Moser–Dutton ruler, $\\beta$ = 1.1 Å$^{-1}$")
ax.axvline(14, color=OI["verm"], lw=1.2, ls="--")
ax.text(14.25, 2.4, "14 Å ceiling between redox cofactors\n(Page et al. 1999; Moser et al. 2006)",
        fontsize=6.8, color=OI["verm"], rotation=90, va="top")
ax.axhspan(2, 3.3, color=OI["green"], alpha=0.14)
ax.text(28.6, 2.62, "respiratory turnover\n$10^2$–$10^3$ s$^{-1}$", fontsize=6.8,
        color=OI["green"], ha="right")
ax.annotate("longer hops must be bridged\nby cofactor chains", xy=(21, 4.9), xytext=(19.2, 7.6),
            fontsize=6.8, color="#444444",
            arrowprops=dict(arrowstyle="->", lw=0.8, color="#444444"))
ax.set_xlim(3, 30); ax.set_ylim(-1, 13)
ax.set_xlabel("donor–acceptor distance (Å)")
ax.set_ylabel("electron-transfer rate $k_{ET}$ (s$^{-1}$, log scale)")
ax.legend(frameon=False, fontsize=6.8, loc="upper right")
save(fig, "fig03_et_ruler.png")

# ============================================================ Fig 4: ATP synthase homology
hom = json.load(open(os.path.join(PRO, "atp_homology.json")))
labels, ident = hom["labels"], np.array(hom["identity"])
meta = hom["meta"]
# order: by subunit then type
order = sorted(range(len(labels)),
               key=lambda i: (meta[labels[i]]["subunit"], meta[labels[i]]["type"]))
short = {"F-type (bacterium)": "F: bacterium", "F-type (mitochondrion)": "F: mitochondrion",
         "F-type (chloroplast)": "F: chloroplast", "F-type (cyanobacterium)": "F: cyanobacterium",
         "A-type (archaeon)": "A: archaeon", "V-type (human lysosome)": "V: human",
         "V-type (yeast vacuole)": "V: yeast"}
lab_s = [f"{labels[i][:-2]} ({short[meta[labels[i]]['type']]})" for i in order]
M = ident[np.ix_(order, order)]

fig = plt.figure(figsize=(S, S*0.42))
gs = fig.add_gridspec(1, 2, width_ratios=[1.15, 1], wspace=0.35)
ax = fig.add_subplot(gs[0, 0])
im = ax.imshow(M*100, cmap="viridis", vmin=0, vmax=100)
ax.set_xticks(range(len(lab_s))); ax.set_yticks(range(len(lab_s)))
ax.set_xticklabels(lab_s, rotation=90, fontsize=5.4)
ax.set_yticklabels(lab_s, fontsize=5.4)
for i in range(len(lab_s)):
    for j in range(len(lab_s)):
        if i < j and M[i, j] > 0.5:
            ax.text(j, i, f"{M[i,j]*100:.0f}", ha="center", va="center", fontsize=4.6,
                    color="white" if M[i, j] < 0.75 else "black")
ax.set_title("Pairwise identity (%)", fontsize=8.5)
cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.ax.tick_params(labelsize=6)

ax = fig.add_subplot(gs[0, 1])
tree = Phylo.read(os.path.join(PRO, "atp_synthase_nj.newick"), "newick")
tree.ladderize()
type_c = {"F": OI["blue"], "A": OI["verm"], "V": OI["green"]}
Phylo.draw(tree, axes=ax, do_show=False, show_confidence=False,
           label_func=lambda c: c.name if c.is_terminal() else "")
for c, x in zip(tree.get_terminals(), [0.5]*99):
    pass
for t in ax.texts:
    nm = t.get_text()
    t.set_fontsize(5.2)
    sub = "alpha" if nm.endswith("_a") else ("beta" if nm.endswith("_b") else "")
    key = nm if nm in meta else None
    t.set_color(type_c.get(nm[-5], "#333333") if nm[:2] in ("EC","BS","HS","YE","AR") else "#333333")
ax.set_title("Neighbour-joining tree (α/β paralogs predate the F/A/V split)", fontsize=8)
ax.set_xlabel("substitutions per site")
ax.set_xticks([]); ax.set_yticks([])
for sp in ax.spines.values(): sp.set_visible(False)
fig.suptitle("")
save(fig, "fig04_atp_homology.png")
print("BATCH 1 DONE")
