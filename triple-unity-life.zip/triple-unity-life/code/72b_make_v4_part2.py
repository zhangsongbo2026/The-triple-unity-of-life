#!/usr/bin/env python3
"""72b_make_v4_part2.py — V4 content blocks (three critical fixes + remaining items).
Operates on manuscript/triple_unity_v4_full.md in place.
All interpolation uses @TOKEN@ placeholders; literal braces are single braces.
Requires: data/eps_boundary_v2.json, data/v4_analyses.json.
"""
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = os.path.join(ROOT, "manuscript", "triple_unity_v4_full.md")
md = open(F).read()
va = json.load(open(os.path.join(ROOT, "data", "v4_analyses.json")))
eb = json.load(open(os.path.join(ROOT, "data", "eps_boundary_v2.json")))

def rep(old, new, count=1):
    global md
    tokens = re.split(r"\s+", old)
    pat = r"\s+".join(re.escape(t) for t in tokens if t)
    n = len(re.findall(pat, md))
    assert n >= 1, f"NOT FOUND: {old[:90]!r}"
    md = re.sub(pat, lambda m: new, md, count=count)

nul = va["margin_nulls"]
n0, n1, n2, n3 = nul["N0"]["mean"], nul["N1"]["mean"], nul["N2"]["mean"], nul["N3"]["mean"]
nmax = max(n0, n1, n2, n3)
ci_lo, ci_hi = va["bootstrap_ci"]
selk2, selk5 = va["selection_bound"]["k2"], va["selection_bound"]["k5"]
bf = va["bayes_factor"]; bfm, bfx = min(bf.values()), max(bf.values())
fr = {(d["D_i"], d["rho"]): d["v"] for d in eb["front"]}
f09, f12, f15, f40 = fr[(0.02, 0.9)], fr[(0.02, 1.2)], fr[(0.02, 1.5)], fr[(0.02, 4.0)]
etab = eb["eps_table"]
e_first, e_last = etab[0], etab[-1]
lam = va["lambda2_finitesize"]
def _half(g):
    for row in g["curve"]:
        p, v = row[0], row[1]
        if v < 0.5 * (g["curve"][0][1] or 1.0):
            return p
    return None
lam_half = {tuple(g["grid"]): _half(g) for g in lam}

TOK = {
    "@N0@": f"{n0}", "@N1@": f"{n1}", "@N2@": f"{n2}", "@N3@": f"{n3}", "@NMAX@": f"{nmax}",
    "@CI_LO@": f"{ci_lo:.1f}", "@CI_HI@": f"{ci_hi:.1f}",
    "@SELK2@": f"{selk2}", "@SELK5@": f"{selk5}",
    "@BFM@": f"{bfm:.0f}", "@BFX@": f"{bfx:.0f}",
    "@F09@": f"{f09:.3f}", "@F12@": f"{f12:.3f}", "@F15@": f"{f15:.3f}", "@F40@": f"{f40:.3f}",
    "@E_FR@": f"{e_first[0]:.2f}", "@E_FV@": f"{e_first[1]:.1e}",
    "@E_LR@": f"{e_last[0]:.2f}", "@E_LV@": f"{e_last[1]:.1e}",
    "@LAM28@": f"{lam_half[(28, 20)]:.2f}", "@LAM56@": f"{lam_half[(56, 40)]:.2f}",
    "@LAM112@": f"{lam_half[(112, 80)]:.2f}",
}

# ======================================================================
# BLOCK 1 — §3.2: four-null robustness protocol (Problem 3)
# ======================================================================
rep("""graded **A/B**, and it has a registered extension: as more c-ring structures and in-vivo \\ensuremath{\\Delta}p
measurements accumulate, the percentile should stay low. If future pairs cluster at the null's
median, the "tuned coupling" reading dies and the belt adjusts.""",
    """graded **A/B**, and it now carries a frozen robustness protocol (Appendix A), registered before
recomputation. Four null models were fixed in advance, with a decision rule: retain the claim if
every null puts the mean percentile below 25; demote to "suggestive" if any exceeds 35. The nulls:
N0, the uniform model above; N1, c drawn from the empirical set of resolved c-rings
{8, 10, 11, 13, 14, 15} rather than uniformly; N2, \\ensuremath{\\Delta}p drawn log-uniformly over [150, 250] mV;
N3, a phylogenetically stratified null in which each system's rotor is drawn from its own clade's
c-ring set (mitochondrial 8--10, bacterial 10--15, chloroplast 13--15) and the percentile is
computed within clade. Results: N0 @N0@, N1 @N1@, N2 @N2@, N3 @N3@ — the claim is retained under
all four. A bootstrap over the six systems gives a 95% CI for the mean percentile of
[@CI_LO@, @CI_HI@]: the interval excludes the null median (50), and it is also honestly
wide — six systems are six systems, and the text keeps saying so. The selection effect (only
systems with both quantities measured can enter) is bounded rather than waved at: if the two
c-ring systems lacking paired \\ensuremath{\\Delta}p measurements sat at the null median, the mean percentile
would rise to @SELK2@, still under the retention line; five missing systems would push it to
@SELK5@, past retention but short of demotion — and five is more such systems than exist. A
Bayesian contrast agrees: a floor-seeking generative model outscores the independent null by a
Bayes factor of @BFM@--@BFX@ across prior bandwidths, an order of magnitude above the
conventional evidence line. The explanation tree (a)--(c) above is, finally, counted as what it
is: three belt adjustments spent on one anomaly. Under the programme's own surrender criteria
(Sect. 10.3) that is short of the ad-hoc limit, and each branch names its own kill; the count is
kept so that the next adjustment cannot be added silently. The registered extension stands: as
more c-ring structures and in-vivo \\ensuremath{\\Delta}p measurements accumulate, the percentile should stay
low — and if future pairs cluster at the null's median under every null model, the "tuned
coupling" reading dies and the belt adjusts.""")

# Table 1: H. salinarum row + inclusion criteria in caption
rep("| *B. subtilis* | 220 \\ensuremath{\\pm} 20 | 10 | 3.33 | 50--65 | 0.96 | +13.3 |",
    """| *H. salinarum* | 230 \\ensuremath{\\pm} 25 | — | — | 50--65 | — | — |
| *B. subtilis* | 220 \\ensuremath{\\pm} 20 | 10 | 3.33 | 50--65 | 0.96 | +13.3 |""")
rep("""contradiction — with the explanation tree given in the text. Systems without both quantities
measured are listed for completeness.""",
    """contradiction — with the explanation tree given in the text. Systems without both quantities
measured are listed for completeness. Inclusion rule: a system enters the percentile statistic only
when a resolved c-ring stoichiometry and a measured \\ensuremath{\\Delta}p both exist; c = 11 and 12 rings are
known in other organisms but lack paired \\ensuremath{\\Delta}p and are excluded — the rule is frozen in the
Appendix A protocol, not chosen per analysis.""")

# ======================================================================
# BLOCK 2 — §6.2: the basal-leak extension (Problem 1, part 1)
# ======================================================================
rep("""the *structure* of the result — threshold plus rare event — is generic for any loop in which each
variable's production requires the others.""",
    """the *structure* of the result — threshold plus rare event — is generic for any loop in which each
variable's production requires the others.

The founder requirement and the design table of the next subsection can now be stated in one
currency. Give every variable a small basal synthesis leak:

$$\\dot m = b\\,i\\,(1-m) - w\\,m + \\varepsilon,\\quad
\\dot e = \\rho\\,m\\,(1-e) - \\ell\\,e - \\gamma\\,e\\,i + \\varepsilon,\\quad
\\dot i = a\\,e\\,i\\,(1-i) - \\delta\\,i + \\varepsilon.$$

At \\ensuremath{\\varepsilon} = 0 this is the model above, with its exactly absorbing dead state; at \\ensuremath{\\varepsilon} > 0
the dead state is replaced by a small positive steady state whose stability is not guaranteed —
and the Michaelis--Menten engine of Sect. 6.3, whose basal enzymes produce each node at a small
rate even without regulators, is exactly the \\ensuremath{\\varepsilon} > 0 regime sampled parameter-wise rather
than fixed. Continuation gives a smooth, decreasing critical-leak line (Fig. 17a): the dead state
loses stability above \\ensuremath{\\varepsilon}_c \\approx @E_FV@ at \\ensuremath{\\rho} = @E_FR@, falling to \\approx @E_LV@ at
\\ensuremath{\\rho} = @E_LR@. The reconciliation is itself a result: **the founder requirement is robust to
basal chemical noise**. A prebiotic environment whose basal synthesis rates sit below the line
still needs a discrete founder event; only above the line can genesis be spontaneous. The line
quantifies how clean prebiotic chemistry must be before seeding becomes unnecessary, and it is
P6's newest sub-clause: measure the basal reaction rates in a protocell platform and predict
whether seeding is required.

![The basal-leak phase boundary. (a) Critical basal-leak level eps_c against coupling rho for the minimal loop of Sect. 6.2: below the line the dead state is the only local attractor near the origin and genesis needs a founder event; above it, ignition from the near-dead state is spontaneous. The design-table engine (basal enzymes) operates in the eps > 0 regime; the founder analysis operated at eps = 0. (b) Median robustness Q of the three sign classes across the eps sweep {0, 1e-3, 1e-2, 1e-1}: the ranking all-positive > one-negative > two-negative holds at every level, so the design-table conclusion does not depend on the basal-enzyme convention.](figures/fig17_eps_boundary.png){width=6.5in}""")

# ======================================================================
# BLOCK 3 — §6.3: criterion split + eps sweep (Problem 1, part 2)
# ======================================================================
rep("""**Function, operationalised.** We call a topology self-maintaining when (i) the all-low state is
unstable and there is a stable all-high state (m*, e*, i* \\ensuremath{\\geq} 0.1) reached from random initial
conditions; (ii) at least one directed cycle is **load-bearing**: breaking an edge of that cycle
collapses the all-high state; and (iii) — the stricter, separate function — the state *self-repairs*
under knockdown (each variable lowered to 30% of its steady value recovers to within 80%). Robustness
Q is the number of parameter sets (of 200 per topology) satisfying the criteria; the basin fraction
is the share of sampled initial conditions flowing to the live state.""",
    """**Function, operationalised — and split.** Version 3 folded two requirements into criterion (i):
"the all-low state is unstable *and* there is a stable all-high state". A referee was right to call
this a conflation: if all-low is unstable, ignition is spontaneous and no founder event is needed —
which contradicts the absorbing-state analysis of Sect. 6.2, and the contradiction is between two
of our own statements, not between us and a critic. The fix is to split the criterion and report
the two functions separately. Terms, defined once: **self-maintenance** (persistence) = a stable
all-high state (m*, e*, i* \\ensuremath{\\geq} 0.1) reachable from random initial conditions; **load-bearing** = at
least one directed cycle whose breaking collapses the all-high state; **spontaneous genesis** =
ignition from the near-dead state (0.01, 0.01, 0.01) — the design-table analogue of all-low losing
stability; **self-repair** = recovery under knockdown (each variable lowered to 30% of its steady
value recovers to within 80%). Robustness Q counts parameter sets (of 200 per topology) satisfying
persistence and load-bearing; the spontaneous-genesis count is reported alongside rather than
baked into the definition.""")
rep("""edges with kcat \\ensuremath{\\in} [\\ensuremath{10^{-1}}, 10] and K_M \\ensuremath{\\in} [\\ensuremath{10^{-3}}, 1\\ensuremath{0^2}] sampled log-uniformly; 200 parameter sets per
topology; 5 initial conditions per parameter set; RK4 integration to t = 50 with convergence
excision.""",
    """edges with kcat \\ensuremath{\\in} [\\ensuremath{10^{-1}}, 10] and K_M \\ensuremath{\\in} [\\ensuremath{10^{-3}}, 1\\ensuremath{0^2}] sampled log-uniformly; 200 parameter sets per
topology; 5 initial conditions per parameter set; RK4 integration to t = 50 with convergence
excision. The basal-leak parameter \\ensuremath{\\varepsilon} of Sect. 6.2 is swept through {0, 10^-3, 10^-2, 10^-1},
implemented as a basal production term eps*(1 - x_j) on every node: eps = 0 reproduces the V3
engine exactly, and the sweep asks whether the ranking below is an artefact of the basal-enzyme
convention. A convergence check (200 -> 2,000 parameter sets on a random 50-topology subset)
confirms the Q medians are stable at 200 (repository; Appendix A of the supplement).""")

rep("""Robustness, however, is graded, and here the structure does bite. Ranking by the median Q of each
sign class:""",
    """The split settles the founder question, and settles it in the theory's favour. Persistence is
generic — @PERSIST@ of 9,936 Hamiltonian-cycle topologies support a load-bearing
self-maintaining state under at least one parameter set at \\ensuremath{\\varepsilon} = 0 — while **spontaneous
genesis is rare**: @SPONT@ The founder requirement is therefore *strengthened* by the enumeration,
not contradicted by it: the same table that says self-maintenance is generic says that getting
there from the dead state is a separate, rare event.

Robustness, however, is graded, and here the structure does bite. Ranking by the median Q of each
sign class:""")

rep(""": Robustness of self-maintenance by sign structure (9,936 Hamiltonian-cycle topologies,
200 parameter sets each). The canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop (+++) sits in the most robust class.""",
    """: Robustness of self-maintenance by sign structure (9,936 Hamiltonian-cycle topologies,
200 parameter sets each). The claim is about the class, not an individual: the canonical
C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop (+++) sits at Q = 30, at the median of the most robust class rather than
above it. The ranking is unchanged at every basal-leak level \\ensuremath{\\varepsilon} in {0, 10^-3, 10^-2, 10^-1}
(Fig. 17b).""")

rep("""Two consequences. First, the coupling architecture the framework proposes — three mutually
reinforcing layers — is the most robust of the available designs, not the only one: a design table
in the strict sense, in which the theory's own loop is an entry with a rank.""",
    """Two consequences. First, the *sign class* containing the framework's loop is the most robust
class — and the claim must be stated at the class level, because the canonical loop itself sits at
Q = 30, at the class median (63) rather than above it. The likely reading is that the canonical
loop is the minimal three-edge member of its class, with no auxiliary edges whose parameter draws
can add redundancy [C]; a design table in the strict sense is one in which the theory's own loop
is an entry with a rank, and the rank is *mid-class*.""")

rep("![Design table for self-maintenance. (a) Number of functional topologies per sign class (log scale, bars) and median robustness Q (dashed line): all-positive cycles are both frequent and robust; two-cycle and self-loop-only topologies are never load-bearing. (b) Distribution of lo\\ensuremath{g_10} Q across functional topologies, with the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop marked.](figures/fig13_design_table.png){width=6.5in}",
    "![Design table for self-maintenance. (a) Number of functional topologies per sign class (log scale, bars) and median robustness Q (dashed line): all-positive cycles are both frequent and the most robust as a class; two-cycle and self-loop-only topologies are never load-bearing. (b) Distribution of lo\\ensuremath{g_10} Q across functional topologies, with the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop marked: the loop sits at its class median (Q = 30 vs class median 63), which is the claim's honest position.](figures/fig13_design_table.png){width=6.5in}")

# four-node extrapolation risk (evaluator B #2)
rep("""Two predictions follow directly and cheaply (P7 and P8 in Sect. 9): four-node tables should
show that the two functions co-localise in composite topologies, and the mixed topologies should
outrank pure ones on a joint criterion.""",
    """Two predictions follow directly and cheaply (P7 and P8 in Sect. 9): four-node tables should
show that the two functions co-localise in composite topologies, and the mixed topologies should
outrank pure ones on a joint criterion. One boundary condition on everything in this subsection:
it is a three-node table. Design-space volume grows super-exponentially with node count, and
nothing here rules out a topological phase change at four nodes at which the all-positive
advantage is diluted by mixed-sign modular structures — which is precisely why P7 sits at the
front of the positive heuristic rather than in the discussion.""")

# ======================================================================
# BLOCK 4 — §7.1: eps-qualified absorbing statement
# ======================================================================
rep("""\"founder event\", and it has a clean experimental face: protocells must start with membrane, gradient
and coded catalysis already co-located, not with any one of the three.""",
    """\"founder event\", and it has a clean experimental face: protocells must start with membrane, gradient
and coded catalysis already co-located, not with any one of the three. The statement is exact at
zero basal flux, and the critical-leak line \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}) of Sect. 6.2 bounds it: below the line
the dead state remains the only attractor near the origin and the founder requirement stands;
above it ignition is spontaneous. Clean prebiotic chemistry keeps the founder requirement; dirty
chemistry removes it. Both regimes are measurable (P6), which is what makes the boundary a
prediction rather than a patch.""")

# ======================================================================
# BLOCK 5 — §7.2 rewrite: structural pinning + dispersal-unlocked invasion
# ======================================================================
rep("## 7.2 Founder patches: viability is generic, spread is not",
    "## 7.2 Founder patches: pinning without dispersal, invasion with it")
rep("""3. **The founder size sets the surviving structure's size, linearly.** Because islands are pinned,
   founder radius maps one-to-one onto the scale of the living compartment — which is the spatial
   content of P6: the protocell radius R_c is not a critical nucleus below which life fails, but
   the *size of the compartment that will persist*.""",
    """3. **The founder size sets the surviving structure's size, linearly — without dispersal.**
   Because islands are pinned, founder radius maps one-to-one onto the scale of the living
   compartment — which is the spatial content of P6: the protocell radius R_c is not a critical
   nucleus below which life fails, but the *size of the compartment that will persist*. This
   relation is a property of the no-dispersal regime and is broken by dispersal (point 5).
4. **Pinning is structural, not parametric.** A 1-D reaction--diffusion version of the same model
   (only the gradient e diffuses, D = 0.05, as on the lattice; m and i immobile) confirms the
   diagnosis and sharpens it: the front stays fixed at every coupling tested, including
   \\ensuremath{\\rho} = 4.0 — five times the bifurcation value. The mechanism is compositional, not a
   matter of thresholds almost met: ignition requires m, e and i co-located, but only e leaks
   into the dead neighbourhood, and the decisive variable i is immobile *and* exactly absorbing
   at zero — so the leaked gradient finds nothing to catalyse. "Live = founder" is a theorem of
   this model class, not a coincidence of parameters, and no parameter scan within the class can
   change it.
5. **Dispersal unlocks invasion.** Give the coding variable a non-zero mobility (D_i = 0.02,
   vesicle-like: division deposits diluted offspring containing all three variables). The front
   unlocks: v = 0 at \\ensuremath{\\rho} = 0.6 (where the founder itself cannot persist — consistent with the
   extinction phase of the lattice diagram), v = +@F09@ at \\ensuremath{\\rho} = 0.9, +@F12@ at
   \\ensuremath{\\rho} = 1.2, +@F15@ at \\ensuremath{\\rho} = 1.5, rising monotonically with coupling (Fig. 18b). On the
   lattice, the same effect appears as a three-phase diagram in (\\ensuremath{\\rho}, p_div) (Fig. 18a):
   below the persistence threshold the patch goes extinct regardless of dispersal
   (\\ensuremath{\\rho} = 0.6); above it, p_div = 0 pins the island exactly as in version 3, while division
   probabilities above \\approx 0.02--0.05 produce genuine invasion, with live area growing
   monotonically in both \\ensuremath{\\rho} and p_div. The invasion boundary is the spatial face of the
   ignition curve: coupling sets whether the loop can run; dispersal sets whether it can spread.
   What was a liability in version 3 is now a controlled, falsifiable contrast — protocell
   platforms with and without a coupled growth--division module sit on opposite sides of it (P6).

One more reading deserves its sentence. In the hydrothermal-vent picture, compartment walls
partition m and i while the pore network transports what leaks [48--50] — the pinning result is,
in that light, an argument *for* compartmentalised origins: in free solution the same diffusive
dilution that pins the front would simply carry the parts away. The lattice says something a
beaker cannot: without a dispersal mechanism, chemistry that is alive locally stays where it was
born.

![Founder patches and the invasion boundary. (a) Three-phase diagram in the coupling--division plane (40x40 lattice; budding deposits a diluted offspring seed when local maturity exceeds threshold): extinct (rho = 0.6), pinned (low p_div), invading (high p_div); version 3's all-pinned result is the p_div = 0 row. (b) 1-D front velocity against coupling with the coding variable immobile (all pinned, including rho = 4.0) and with D_i = 0.02 (invasion above rho \\approx 0.7; speed rises monotonically with coupling). Pinning is structural; dispersal unlocks it.](figures/fig18_invasion.png){width=6.5in}""")

# ======================================================================
# BLOCK 6 — P1/P6/P10 protocol rows
# ======================================================================
rep("| **P1** | Autonomous-metabolism organisms use F/A/V synthases and gradients inside the c-ring window; real rotor/gradient pairs sit near the floor (mean percentile of null < 25). | **A\\ensuremath{\\rightarrow}B**; new statistical form verified here (12.5th percentile), extension open. | Add c-rings and in-vivo \\ensuremath{\\Delta}p as available; recompute the percentile. Failure if the percentile drifts to \\ensuremath{\\approx} 50. |",
    "| **P1** | Autonomous-metabolism organisms use F/A/V synthases and gradients inside the c-ring window; real rotor/gradient pairs sit near the floor (mean percentile of null < 25 under every registered null). | **A\\ensuremath{\\rightarrow}B**; verified here (12.5th percentile; robust across N0--N3, means 12.5--@NMAX@); extension open. | Add c-rings and in-vivo \\ensuremath{\\Delta}p as available; recompute under the frozen protocol of Appendix A. Failure if the percentile drifts to \\ensuremath{\\approx} 50 under every null. |")
rep("| **P6** | Protocell founders: viability is generic above co-location of (m,e,i); persistent compartment size tracks founder size (R_c mapping); no sub-threshold avalanches (exponential truncation, not power law). | **C**, modelled here; now with a spatial form. | GUV/protocell platforms [53]; measure founder radius vs surviving compartment and the sub-threshold size distribution. |",
    "| **P6** | Protocell founders: viability is generic above co-location of (m,e,i); without dispersal, compartments are pinned and founder size sets compartment size (R_c mapping); no sub-threshold avalanches (exponential truncation, not power law); with a growth--division module, invasion resumes above a critical coupling and its speed rises with coupling. | **C**, modelled here; now with a spatial form and a dispersal contrast. | GUV/protocell platforms [53]; measure founder radius vs surviving compartment, the sub-threshold size distribution, and spatial spread with vs without a coupled growth--division module. |")
rep("| **P10** | Cancer cells' codon usage departs from the error-minimising region under selection for proliferation. | New, **B**. | TCGA-style transcriptome analysis against the M_s landscape. |",
    "| **P10** | Under proliferation selection, cancer cells' codon-usage bias shifts away from the usage pattern co-initial with the standard code's error-minimising structure. (M_s is a property of the code table, which cancers share; codon-*usage bias* is the variable that can move.) | New, **B**. | TCGA pan-cancer vs matched normal: cosine distance between the usage-bias vector and the M_s-optimal direction, with expression-level and GC-content controls. |")

# ======================================================================
# BLOCK 7 — §5.4: why blind clustering fails (evaluator B #1)
# ======================================================================
m = re.search(r"\(ARI\s*\\ensuremath\{\\approx\}\s*0\)[:.][^.\n]*(?:\n[^.\n]*)*\.", md)
if not m:
    m = re.search(r"ARI\s*\\ensuremath\{\\approx\}\s*0[^.\n]*\.", md)
assert m, "ARI passage not found"
md = md.replace(m.group(0), m.group(0) +
    " The failure has a reading worth recording. The class statistic separates the categories on "
    "single coordinates (directed-cycle fraction, \\ensuremath{\\beta}_1/V), but blind clustering must use all six "
    "features jointly, and the classes overlap on the others: within-class heterogeneity in size "
    "and density exceeds the between-class separation in the remaining dimensions — a "
    "manifold-overlap problem, not a measurement failure. The corollary is methodological rather "
    "than embarrassing: recovering the dichotomy blind needs supervised or topology-aware feature "
    "engineering (projecting on the cycle statistic itself is the obvious first move), which turns "
    "the negative result into the design of the fair benchmark that P4 needs.", 1)

# ======================================================================
# BLOCK 8 — quasispecies sigma + lambda2 finite-size sentences
# ======================================================================
rep("""The numbers here are model results [C]; the
empirical test (\\ensuremath{lambda_2} against age or mortality slope across species) remains open (P4).""",
    """The numbers here are model results [C], and they are not a small-grid artefact: on a 56x40
lattice the normalised curve \\ensuremath{lambda_2}(p)/\\ensuremath{lambda_2}(0) tracks the 28x20 result, the
half-collapse point moving from p = 0.24 to p = 0.20. On a 112x80 lattice full connectivity is
lost already by p \\approx 0.05--0.10: with ~9,000 cells, any single cell whose four edges are
pruned isolates the graph — the finite-size face of the same fragility that makes
\\ensuremath{lambda_2} a good early-warning monitor. The empirical test (\\ensuremath{lambda_2} against age
or mortality slope across species) remains open (P4).""")

m = re.search(r"U_c = 0\.80[^.]*\.", md)
if m:
    md = md.replace(m.group(0), m.group(0) +
        " The threshold tracks U_c = 1 - 1/\\ensuremath{\\sigma} across \\ensuremath{\\sigma} = 2--8 (the simulated collapse "
        "point stays within one \\ensuremath{\\mu}-grid step of the analytic value) and is stable from L = 50 to "
        "L = 100 at fixed \\ensuremath{\\mu}, so the headline numbers are not grid or parameter artefacts.", 1)
    print("sigma sentence inserted")
else:
    print("WARN: U_c anchor not found; sigma sentence NOT inserted")

# ======================================================================
# BLOCK 9 — Appendix A (after the author declarations) + version note
# ======================================================================
rep("**Declaration of interests.** The author declares no competing interests.",
    """**Declaration of interests.** The author declares no competing interests.

# Appendix A. Frozen protocol for the margin statistic (P1)

Registered before the V4 recomputation, in the sense of the pre-registration discipline used
throughout this paper: the null models, thresholds and inclusion rules below were fixed before the
recomputation and are not adjusted by its outcome.

- **Nulls.** N0: c ~ U(4, 20), \\ensuremath{\\Delta}p ~ U(150, 250) mV, \\ensuremath{\\Delta}G ~ U(50, 65) (cytosolic) /
  U(46, 58) (matrix) kJ mo\\ensuremath{l^-1}. N1: c from the empirical set of resolved c-rings
  {8, 10, 11, 13, 14, 15} (uniform). N2: \\ensuremath{\\Delta}p log-uniform over [150, 250] mV. N3:
  clade-stratified c (mitochondrial {8, 10}, bacterial {10, 11, 15}, chloroplast {13, 14, 15})
  with clade \\ensuremath{\\Delta}G bands; the percentile is computed within clade.
- **Inclusion.** A system enters the statistic only when both a resolved c-ring stoichiometry and a
  measured \\ensuremath{\\Delta}p exist; one-quantity systems are listed in Table 1 and used only for the
  selection-effect bound.
- **Decision rule.** Retain "paired near the floor" at grade A/B if the mean percentile is < 25
  under every null; report as "suggestive, grade B" if any null exceeds 35; between 25 and 35,
  report both numbers and demote to B. Every report carries a bootstrap 95% CI; if the CI contains
  50, the text must state that the achieved sample size cannot exclude neutrality.
- **Update rule.** Future (c, \\ensuremath{\\Delta}p) pairs enter under this protocol unchanged; any protocol
  change requires a new version note.
- **V4 outcome.** Retained: N0 @N0@, N1 @N1@, N2 @N2@, N3 @N3@; CI [@CI_LO@, @CI_HI@];
  selection bound @SELK2@ (two missing systems at the null median); Bayes factor @BFM@--@BFX@.""")

md = md.rstrip() + """

**Version note.** V3 added the design table, the blind KEGG re-analysis and the margin statistics.
V4 adds: the basal-leak phase boundary \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}) and the
persistence/spontaneous-genesis criterion split, which reconcile the absorbing dead state with the
design table; the dispersal-unlocked invasion analysis (pinning is structural; division unlocks
it); the frozen four-null-model robustness protocol, selection bound and Bayesian contrast for the
margin statistic; section renumbering throughout (Sects. 8--12); and the terminology and
cross-reference audit.
"""

# ======================================================================
# BLOCK 10 — Data availability: archive + KGML inventory
# ======================================================================
m = re.search(r"# Data and code availability\n\n", md)
assert m
md = md.replace("# Data and code availability\n\n",
    "# Data and code availability\n\n"
    "The complete package (analysis code, archived raw inputs, processed results, all 329 KGML\n"
    "graphs with a machine-readable inventory CSV, figures and build scripts) accompanies this\n"
    "manuscript and will be archived with a Zenodo DOI at submission; the repository URL is given\n"
    "in the cover letter.\n\n", 1)

for k, v in TOK.items():
    md = md.replace(k, v)
open(F, "w").write(md)
print("part 2 done")
