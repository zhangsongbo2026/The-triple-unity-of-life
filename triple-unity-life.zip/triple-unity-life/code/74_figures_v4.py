#!/usr/bin/env python3
"""74_figures_v4.py — V4 new figures: fig17 (eps boundary + eps-sweep ranking)
and fig18 (budding phase diagram + front velocities). Okabe-Ito palette, 600 dpi.
"""
import glob, json, os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
va = json.load(open(os.path.join(ROOT, "data", "v4_analyses.json")))
eb = json.load(open(os.path.join(ROOT, "data", "eps_boundary_v2.json")))

# Okabe-Ito
OI = {"blue": "#0072B2", "orange": "#E69F00", "green": "#009E73", "red": "#D55E00",
      "purple": "#CC79A7", "sky": "#56B4E9", "yellow": "#F0E442", "black": "#000000"}
plt.rcParams.update({"font.size": 8.5, "axes.linewidth": 0.8,
                     "xtick.direction": "out", "ytick.direction": "out"})

# ---------------- fig17 ----------------
fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7))
ax = axes[0]
tab = np.array(eb["eps_table"])
ax.semilogy(tab[:, 0], tab[:, 1], "-o", color=OI["blue"], ms=3.5, lw=1.4)
ax.set_xlabel(r"coupling $\rho$")
ax.set_ylabel(r"critical basal leak $\varepsilon_c(\rho)$")
ax.set_title("(a) founder requirement vs basal chemical noise", fontsize=8.5)
ax.axhspan(1e-4, 1e-3, color="0.92", zorder=0)
ax.text(0.98, 0.06, "spontaneous ignition above the line;\nfounder event required below it",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=7, color="0.35")

ax = axes[1]
runs = {}
for f in sorted(glob.glob(os.path.join(ROOT, "data", "design_table_v4_eps*.json"))):
    d = json.load(open(f)); runs[d["EPS"]] = d
epss = sorted(runs)
series = {"all-pos 3-cycle": ("all-positive", OI["blue"], "o"),
          "3-cycle 1-neg": ("one-negative", OI["orange"], "s"),
          "3-cycle 2-neg": ("two-negative", OI["purple"], "^")}
for key, (lab, col, mk) in series.items():
    ys = [runs[e]["classes"][key]["median_Q"] for e in epss]
    ax.plot(range(len(epss)), ys, "-" + mk, color=col, ms=4.5, lw=1.4, label=lab)
ax.set_xticks(range(len(epss)))
ax.set_xticklabels(["0", r"$10^{-3}$", r"$10^{-2}$", r"$10^{-1}$"])
ax.set_xlabel(r"basal leak $\varepsilon$")
ax.set_ylabel("median robustness Q")
ax.legend(frameon=False, fontsize=7, loc="right")
ax.set_title("(b) sign-class ranking is eps-independent", fontsize=8.5)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig17_eps_boundary.png"), dpi=600)
plt.close(fig)
print("fig17 saved")

# ---------------- fig18 ----------------
fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
ax = axes[0]
phase = va["budding_phase"]
rhos = sorted({p["rho"] for p in phase})
pdivs = sorted({p["p_div"] for p in phase})
cmap = {"extinct": OI["black"], "pinned": OI["sky"], "invading": OI["green"]}
Z = np.zeros((len(pdivs), len(rhos), 4))
for i, pd in enumerate(pdivs):
    for j, r in enumerate(rhos):
        rec = next(p for p in phase if p["rho"] == r and p["p_div"] == pd)
        c = list(matplotlib.colors.to_rgb(cmap[rec["cls"]]))
        Z[i, j] = c + [1]
ax.imshow(Z, origin="lower", aspect="auto",
          extent=(min(rhos)-0.15, max(rhos)+0.15, min(pdivs)-0.005, max(pdivs)+0.005))
ax.set_xlabel(r"coupling $\rho$")
ax.set_ylabel(r"division probability $p_{\rm div}$")
ax.set_title("(a) lattice phases: extinct / pinned / invading", fontsize=8.5)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor=cmap["extinct"], label="extinct"),
                   Patch(facecolor=cmap["pinned"], label="pinned (V3 regime)"),
                   Patch(facecolor=cmap["green"], label="invading")],
          frameon=False, fontsize=7, loc="upper left")

ax = axes[1]
fr = va["front_velocity"]
for Di, col, lab in ((0.0, OI["purple"], r"$D_i=0$ (immobile coding)"),
                     (0.02, OI["green"], r"$D_i=0.02$ (dispersal)")):
    pts = sorted([(d["rho"], d["v"]) for d in fr if d["D_i"] == Di])
    ax.plot([p[0] for p in pts], [p[1] for p in pts], "-o", color=col, ms=4, lw=1.4, label=lab)
ax.axhline(0, color="0.6", lw=0.8)
ax.set_xlabel(r"coupling $\rho$")
ax.set_ylabel("1-D front velocity  $v$")
ax.legend(frameon=False, fontsize=7, loc="upper left")
ax.set_title("(b) dispersal unlocks invasion", fontsize=8.5)
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig18_invasion.png"), dpi=600)
plt.close(fig)
print("fig18 saved")
