#!/usr/bin/env python3
"""51_design_engine.py — Reviewer-C M2/M3: exhaustive search of 3-node signed
directed topologies for SELF-MAINTENANCE (Ma et al. 2009 paradigm, adapted).

Function 'self-maintenance' (operationalised):
  (i)  all-ON attractor: steady state with m*,e*,i* >= 0.1 reached from random ICs;
  (ii) self-repair: knockdown (x -> 0.3 x) of each variable recovers to S;
  (iii) loop-necessity: breaking an edge of at least one directed cycle
       collapses the all-ON state (feedforward DAGs fail by construction).
Robustness Q = number of parameter sets passing (i)-(iii).
Basin volume = fraction of G random ICs reaching the all-ON state (per functional param set).
Output: data/processed/design_table.json + design_table.csv
"""
import os, json, math
import numpy as np
from numba import njit

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "processed")

# edge index: 0:(0->0) 1:(0->1) 2:(0->2) 3:(1->0) 4:(1->1) 5:(1->2) 6:(2->0) 7:(2->1) 8:(2->2)
SRC = np.array([0,0,0,1,1,1,2,2,2], np.int64)
DST = np.array([0,1,2,0,1,2,0,1,2], np.int64)
NTOPO = 3**9
NPARAM = int(__import__('os').environ.get('NPARAM', 120))        # parameter sets per topology
G = 5               # random ICs per param set
T = 50.0
DT = 0.1
NSTEP = int(T / DT)
CONV = 1e-3

@njit(cache=True)
def xorshift(state):
    state ^= (state << 13) & 0xFFFFFFFFFFFFFFFF
    state ^= state >> 7
    state ^= (state << 17) & 0xFFFFFFFFFFFFFFFF
    return state

@njit(cache=True)
def u01(state):
    return (state >> 11) * (1.0 / 9007199254740992.0)

@njit(cache=True)
def rhs(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, out):
    # flags[j]: 0 no basal, 1 basal activation only, 2 basal deactivation only, 3 both
    for j in range(3):
        prod = 0.0
        deg = 0.0
        for e in range(9):
            if DST[e] != j or s9[e] == 0:
                continue
            xs = x[SRC[e]]
            if s9[e] > 0:
                prod += k[e] * xs * (1.0 - x[j]) / ((1.0 - x[j]) + K[e])
            else:
                deg += k[e] * xs * x[j] / (x[j] + K[e])
        if flags[j] == 1 or flags[j] == 3:
            prod += 0.5 * kb_act[j] * (1.0 - x[j]) / ((1.0 - x[j]) + Kb_act[j])
        if flags[j] == 2 or flags[j] == 3:
            deg += 0.5 * kb_de[j] * x[j] / (x[j] + Kb_de[j])
        out[j] = prod - deg

@njit(cache=True)
def integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, nsteps, outS):
    x0 = x.copy()
    dx = np.zeros(3)
    for step in range(nsteps):
        rhs(x0, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, dx)
        k1 = dx.copy()
        xt = np.empty(3)
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + 0.5 * DT * k1[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, dx)
        k2 = dx.copy()
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + 0.5 * DT * k2[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, dx)
        k3 = dx.copy()
        for j in range(3):
            xt[j] = min(1.0, max(0.0, x0[j] + DT * k3[j]))
        rhs(xt, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, dx)
        k4 = dx.copy()
        maxd = 0.0
        for j in range(3):
            x0[j] = min(1.0, max(0.0, x0[j] + DT / 6.0 * (k1[j] + 2*k2[j] + 2*k3[j] + k4[j])))
            if abs(k1[j]) > maxd:
                maxd = abs(k1[j])
        if maxd < CONV:
            break
    for j in range(3):
        outS[j] = x0[j]

@njit(cache=True)
def run_topo(tid, s9, cycles, ncyc, cyc_edges):
    res = np.zeros(4)
    # cycles: array (ncyc, 3) of edge indices (-1 padded); breaking each edge of each cycle
    rng_state = (tid * 2654435761 + 12345) & 0xFFFFFFFFFFFFFFFF
    # per-edge params generated on the fly; basal per node-direction
    Q = 0
    basin_sum = 0.0
    basin_frac_sum = 0.0
    n_cand = 0
    for p in range(NPARAM):
        rng_state = xorshift(rng_state)
        k = np.zeros(9); K = np.zeros(9)
        ne = 0
        for e in range(9):
            if s9[e] != 0:
                rng_state = xorshift(rng_state)
                k[e] = 0.1 * math.pow(100.0, u01(rng_state))      # 0.1..10
                rng_state = xorshift(rng_state)
                K[e] = 0.001 * math.pow(100000.0, u01(rng_state)) # 0.001..100
                ne += 1
        # basal flags and params
        flags = np.zeros(3, dtype=np.int64)
        kb_act = np.zeros(3); Kb_act = np.zeros(3)
        kb_de = np.zeros(3); Kb_de = np.zeros(3)
        for j in range(3):
            pos_in = 0; neg_in = 0
            for e in range(9):
                if DST[e] == j and s9[e] != 0:
                    if s9[e] > 0:
                        pos_in += 1
                    else:
                        neg_in += 1
            if pos_in > 0 and neg_in == 0:
                flags[j] = 2
            elif neg_in > 0 and pos_in == 0:
                flags[j] = 1
            elif pos_in == 0 and neg_in == 0:
                flags[j] = 3
            if flags[j] == 1 or flags[j] == 3:
                rng_state = xorshift(rng_state)
                kb_act[j] = 0.1 * math.pow(100.0, u01(rng_state))
                rng_state = xorshift(rng_state)
                Kb_act[j] = 0.001 * math.pow(100000.0, u01(rng_state))
            if flags[j] == 2 or flags[j] == 3:
                rng_state = xorshift(rng_state)
                kb_de[j] = 0.1 * math.pow(100.0, u01(rng_state))
                rng_state = xorshift(rng_state)
                Kb_de[j] = 0.001 * math.pow(100000.0, u01(rng_state))
        # steady phase: G random ICs
        n_on = 0
        S = np.zeros(3)
        S_count = 0
        for g in range(G):
            x = np.empty(3)
            for j in range(3):
                rng_state = xorshift(rng_state)
                x[j] = 0.05 + 0.9 * u01(rng_state)
            outS = np.zeros(3)
            integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, NSTEP, outS)
            on = True
            for j in range(3):
                if outS[j] < 0.1:
                    on = False
            if on:
                n_on += 1
                for j in range(3):
                    S += outS[j]
                S_count += 1
        if n_on == 0:
            continue
        for j in range(3):
            S[j] /= S_count
        basin_frac = n_on / G
        # recovery: 3 knockdowns from S
        ok_rec = True
        for kd in range(3):
            x = S.copy()
            x[kd] *= 0.3
            outS = np.zeros(3)
            integrate(x, s9, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, NSTEP, outS)
            for j in range(3):
                denom = S[j] if S[j] > 0.1 else 0.1
                if outS[j] / denom < 0.8:
                    ok_rec = False
        # cycle-necessity (on the all-ON state): break one edge per cycle, check collapse
        load_bearing = False
        for c in range(ncyc):
            if load_bearing:
                break
            for eidx in range(3):
                e = cyc_edges[c, eidx]
                if e < 0 or s9[e] == 0:
                    continue
                s_mod = s9.copy()
                s_mod[e] = 0
                x = S.copy()
                outS = np.zeros(3)
                integrate(x, s_mod, k, K, kb_act, Kb_act, kb_de, Kb_de, flags, NSTEP, outS)
                collapsed = False
                for j in range(3):
                    if outS[j] < 0.1:
                        collapsed = True
                if collapsed:
                    load_bearing = True
                    break
        if not load_bearing:
            continue
        Q += 1
        basin_sum += basin_frac
        n_cand += 1
    return tid, Q, (basin_sum / Q if Q > 0 else 0.0)

def _worker(tid, s9, cyc, ncyc, cyc_flat):
    return run_topo(tid, s9, cyc, ncyc, cyc)

def main():
    # enumerate all topologies
    topo = np.zeros((NTOPO, 9), np.int8)
    for t in range(NTOPO):
        v = t
        for e in range(9):
            topo[t, e] = (v % 3) - 1
            v //= 3
    # directed cycles per topology: self-loops(3), 2-cycles(3 pairs), 3-cycles(2 hamiltonian)
    cyc_list = []
    for t in range(NTOPO):
        s = topo[t]
        cyc = []
        for e in range(9):
            if SRC[e] == DST[e] and s[e] != 0:
                cyc.append([e, -1, -1])
        for e1 in range(9):
            for e2 in range(9):
                if SRC[e1] == DST[e2] and DST[e1] == SRC[e2] and SRC[e1] != DST[e1] \
                   and s[e1] != 0 and s[e2] != 0:
                    cyc.append([e1, e2, -1])
        # hamiltonian 3-cycles: orientation A: 0->1,1->2,2->0 ; B: 0->2,2->1,1->0
        A = [1, 5, 6]; B = [2, 7, 3]
        for cycE in (A, B):
            if all(s[e] != 0 for e in cycE):
                cyc.append([cycE[0], cycE[1], cycE[2]])
        if len(cyc) > 0:
            arr = np.full((len(cyc), 3), -1, np.int64)
            for i, c in enumerate(cyc):
                arr[i, :len(c)] = c
            cyc_list.append(arr)
        else:
            cyc_list.append(np.zeros((0, 3), np.int64))
    has_cycle = np.array([len(c) > 0 for c in cyc_list])
    idx_cycle = np.where(has_cycle)[0]
    import os as _os
    if _os.environ.get("RESTRICT") == "1":
        keep = []
        for t in idx_cycle:
            s = topo[t]
            if (s[1] != 0 and s[5] != 0 and s[6] != 0) or (s[2] != 0 and s[7] != 0 and s[3] != 0):
                keep.append(t)
        idx_cycle = np.array(keep, dtype=idx_cycle.dtype)
        print(f"restricted to Hamiltonian-3-cycle topologies: {len(idx_cycle)}")
    print(f"topologies total {NTOPO}, with >=1 directed cycle: {len(idx_cycle)}")

    res = np.zeros((NTOPO, 2))
    # our canonical loop: (0->1)+ (1->2)+ (2->0)+  = edges 1,5,6 all +
    canon = np.zeros(9, np.int8); canon[1] = 1; canon[5] = 1; canon[6] = 1
    canon_id = int(sum(int(v) * (3**e) for e, v in enumerate((canon+1))))
    anti = np.zeros(9, np.int8); anti[2] = 1; anti[7] = 1; anti[3] = 1
    anti_id = int(sum(int(v) * (3**e) for e, v in enumerate((anti+1))))

    import time
    from multiprocessing import Pool
    t0 = time.time()
    jobs = [(int(tid), topo[tid].astype(np.int64), cyc_list[tid]) for tid in idx_cycle]
    print(f"jobs: {len(jobs)}", flush=True)
    with Pool(processes=32) as pool:
        out = pool.starmap(_worker, [(t, s, c, c.shape[0], c) for t, s, c in jobs], chunksize=8)
    for r in out:
        tid, Qn, basin, q2, _ = r
        res[tid, 0] = Qn
        res[tid, 1] = basin
        res[tid, 3] = q2
    print(f"pool done in {time.time()-t0:.0f}s", flush=True)

    func = np.where(res[:, 0] > 0)[0]
    print(f"\nfunctional topologies (loop-necessary self-maintenance, Q>0): {len(func)} of {len(idx_cycle)}")
    Qs = res[func, 0]
    n_rep = int((res[func, 3] > 0).sum())
    print(f"self-repairing among them: {n_rep}")
    print(f"Q: median {np.median(Qs):.0f}  max {Qs.max():.0f}" if len(func) else "none functional")
    if res[canon_id, 0] > 0:
        pctQ = float((res[func, 0] < res[canon_id, 0]).mean() * 100)
        print(f"canonical C1^C2^C3 loop: Q={res[canon_id,0]:.0f}, basin={res[canon_id,1]:.2f}, "
              f"self-repair={res[canon_id,3]:.0f}, Q-percentile {pctQ:.1f}%")
    else:
        print("canonical loop NOT functional in this scheme")
    if res[anti_id, 0] > 0:
        print(f"anti-orientation loop: Q={res[anti_id,0]:.0f}, basin={res[anti_id,1]:.2f}")

    # classify functional topologies by load-bearing cycle sign product (from stored? recheck cheaply:
    # classify by contained cycle sign products)
    classes = {"all-pos 3-cycle": 0, "3-cycle 1-neg": 0, "3-cycle 2-neg": 0,
               "pos 2-cycle only": 0, "neg 2-cycle": 0, "self-loop only": 0, "other": 0}
    Q_by_class = {k: [] for k in classes}
    for t in func:
        s = topo[t]
        has3pos = (s[1] > 0 and s[5] > 0 and s[6] > 0) or (s[2] > 0 and s[7] > 0 and s[3] > 0)
        neg3 = 0
        for cycE in ([1,5,6], [2,7,3]):
            if all(s[e] != 0 for e in cycE):
                nneg = sum(1 for e in cycE if s[e] < 0)
                neg3 = max(neg3, nneg)
        has2 = False; neg2 = False
        for e1 in range(9):
            for e2 in range(9):
                if SRC[e1] == DST[e2] and DST[e1] == SRC[e2] and SRC[e1] != DST[e1] \
                   and s[e1] != 0 and s[e2] != 0:
                    has2 = True
                    if s[e1] * s[e2] < 0:
                        neg2 = True
        selfl = any(s[e] != 0 and SRC[e] == DST[e] for e in range(9))
        if has3pos:
            k = "all-pos 3-cycle"
        elif neg3 >= 1:
            k = "3-cycle 1-neg" if neg3 == 1 else "3-cycle 2-neg"
        elif has2 and not neg2:
            k = "pos 2-cycle only"
        elif neg2:
            k = "neg 2-cycle"
        elif selfl:
            k = "self-loop only"
        else:
            k = "other"
        classes[k] += 1
        Q_by_class[k].append(res[t, 0])
    summary = {k: dict(count=v, median_Q=float(np.median(Q_by_class[k])) if v else 0)
               for k, v in classes.items()}
    print(json.dumps(summary, indent=1))

    out = dict(n_topo=NTOPO, n_cycle_topo=int(len(idx_cycle)), n_param=NPARAM, n_ic=G,
               T=T, functional_count=int(len(func)), selfrepair_count=n_rep,
               Q_median=float(np.median(Qs)) if len(func) else 0,
               Q_max=float(Qs.max()) if len(func) else 0,
               canonical=dict(id=canon_id, Q=float(res[canon_id, 0]), basin=float(res[canon_id, 1])),
               anti_orientation=dict(id=anti_id, Q=float(res[anti_id, 0]), basin=float(res[anti_id, 1])),
               classes=summary)
    suffix = __import__("os").environ.get("SUFFIX", "")
    json.dump(out, open(os.path.join(OUT, f"design_table{suffix}.json"), "w"), indent=1)
    np.save(os.path.join(OUT, f"design_table_res{suffix}.npy"), res)
    # per-functional-topology CSV
    import csv
    with open(os.path.join(OUT, f"design_table{suffix}.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["topo_id", "Q", "basin", "signs(9)"])
        for t in func:
            w.writerow([t, int(res[t, 0]), f"{res[t,1]:.3f}",
                        "".join({-1: "-", 0: "0", 1: "+"}[int(v)] for v in topo[t])])
    print("saved design_table.json / .csv ; total time", time.time() - t0)

if __name__ == "__main__":
    main()
