#!/usr/bin/env python3
"""56_refs_v3.py — build the alphabetical References section for the V3 manuscript
(author-year style) and verify each cited work is actually named in the text."""
import os, re, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MD = os.path.join(ROOT, "manuscript", "triple_unity_v3_final.md")
refs = json.load(open(os.path.join(ROOT, "data", "processed", "references.json")))

CITED = ["akashi2002", "aon2004", "bennett1982", "berman2000", "brand1991", "brandes2002",
         "brandman2005", "champoux2001", "cock2009", "crick1968", "drake1991", "drake1999",
         "drummond2009", "eckerle2010", "edelsbrunner2002", "eigen1971", "fell2000",
         "figge2012", "friston2010", "fuller1971", "gago2009", "ganti2003", "hagberg2008",
         "haig1991", "helfrich1973", "hopfield1974", "hu2012", "hunter2007", "jeong2000",
         "jiang2001", "joyce2002", "kanehisa2000", "kirkwood1977", "knight1999",
         "koonin2006", "koonin2009", "kraus2021", "kun2005", "kuhn1962", "lakatos1970",
         "landauer1961", "lane2010", "lane2012", "langen1995", "li2004", "maloney1983",
         "martin2003", "ma2009", "matthies2009", "maturana1980", "michel1980", "milo2002",
         "mitome2004", "morlot2013", "mulkidjanian2008", "nagle2000", "nicholls2013",
         "ninio1975", "orgel2004", "page1999", "pogoryelov2009", "prigogine1971",
         "raoult2004", "rashevsky1955", "rawicz2000", "rolfe1997", "rosen1958",
         "sanjuan2010", "schrodinger1944", "shen2021", "smith2013", "sojo2016",
         "stock1999", "szostak2001", "tononi2004", "tralie2018", "tsai2008",
         "uniprot2023", "varela1974", "west1997", "white1969", "woese1965", "woese1990",
         "xia2014", "zhu2009", "zomorodian2005", "mitchell1961", "mitchell1978",
         "marcus1956", "moser1992", "moser2006", "fiedler1973", "dimova2019", "kirkwood1977"]
CITED = [k for k in CITED if k]

def fmt(k):
    v = refs[k]
    a = v.get("authors", [])
    fams = []
    for x in a[:6]:
        f = x.get("family", ""); g = x.get("given", "")
        inis = " ".join(p[0] + "." for p in g.replace("-", "- ").split() if p)
        fams.append(f"{f} {inis}".strip())
    if len(a) > 6:
        fams.append("et al.")
    if not fams:
        fams = ["Anonymous"]
    t = re.sub(r"&amp;", "&", v.get("title", "?")); t = re.sub(r"<[^>]+>", "", t)
    j = re.sub(r"<[^>]+>", "", v.get("journal", "?"))
    s = f"{', '.join(fams)} ({v.get('year')}). {t}. {j}"
    if v.get("volume"): s += f" {v['volume']}"
    if v.get("pages"): s += f", {v['pages']}"
    if v.get("doi"): s += f". https://doi.org/{v['doi']}"
    return s

# verification tokens: first-author family + year must appear in text
md = open(MD).read()
missing_checks = []
entries = []
for k in sorted(set(CITED), key=lambda x: x):
    if k not in refs:
        missing_checks.append(k); continue
    v = refs[k]
    a = v.get("authors", [])
    fam = a[0].get("family", "") if a else ""
    yr = str(v.get("year", ""))
    token_ok = (fam.split()[0].rstrip(".").lower() in md.lower()) and (yr in md)
    entries.append((k, fmt(k), token_ok, fam, yr))

bad = [e for e in entries if not e[2]]
print("references emitted:", len(entries))
print("not matched in text (check manually):", [(e[0], e[3], e[4]) for e in bad])
missing = sorted(set(CITED) - set(refs))
print("keys missing from references.json:", missing)

# append references section
md_out = md + "\n\n# References\n\n" + "\n\n".join(e[1] for e in entries) + "\n"
open(MD, "w").write(md_out)
print("References appended ->", MD)
