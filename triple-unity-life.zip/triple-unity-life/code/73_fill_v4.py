#!/usr/bin/env python3
"""73_fill_v4.py — fill @PERSIST@ / @SPONT@ placeholders from the eps sweep, and
run the terminology + truncated-sentence sanity checks (evaluator C #8, #9).
"""
import glob, json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = os.path.join(ROOT, "manuscript", "triple_unity_v4_full.md")
md = open(F).read()

files = sorted(glob.glob(os.path.join(ROOT, "data", "design_table_v4_eps*.json")))
assert files, "eps sweep outputs missing"
runs = {}
for f in files:
    d = json.load(open(f))
    runs[d["EPS"]] = d
eps0 = runs[0.0]
persist = eps0["functional_count"]
tot0 = eps0["n_topo"] * eps0["n_param"]
sp0 = eps0["spont_param_sets"]

parts = [f"{sp0} of {tot0:,} parameter sets ({100*sp0/tot0:.2f}%) ignite from the near-dead state "
         f"at eps = 0"]
for eps in sorted(runs):
    if eps == 0.0:
        continue
    r = runs[eps]
    tot = r["n_topo"] * r["n_param"]
    parts.append(f"{r['spont_param_sets']} of {tot:,} ({100*r['spont_param_sets']/tot:.1f}%) at "
                 f"eps = {eps:g}")
spont_text = "; ".join(parts) + (
    f". The critical-leak line of Sect. 6.2 is exactly this boundary seen from the enumeration side: "
    f"basal flux below eps_c(rho) leaves genesis a rare discrete event; above it, ignition becomes "
    f"the rule rather than the exception.")

# ranking stability across eps
stab = []
for eps in sorted(runs):
    cls = runs[eps]["classes"]
    ap = cls["all-pos 3-cycle"]["median_Q"]; on = cls["3-cycle 1-neg"]["median_Q"]
    tn = cls["3-cycle 2-neg"]["median_Q"]
    stab.append(ap > on > tn)
print("ranking stable across eps:", all(stab), [(e, runs[e]["classes"]["all-pos 3-cycle"]["median_Q"],
      runs[e]["classes"]["3-cycle 1-neg"]["median_Q"], runs[e]["classes"]["3-cycle 2-neg"]["median_Q"])
      for e in sorted(runs)])
conv = glob.glob(os.path.join(ROOT, "data", "design_table_v4_epse*2000*")) # convergence tag check below
# convergence run tag: EPS=0 NPARAM=2000 SUBSET -> same tag 'eps0p0'? it would overwrite!
# (run_eps_sweep.sh writes with the same tag; convergence summary read from log instead.)

assert "@PERSIST@" in md and "@SPONT@" in md
md = md.replace("@PERSIST@", f"{persist:,}")
md = md.replace("@SPONT@", spont_text)
open(F, "w").write(md)
print("placeholders filled")

# ---------------- sanity checks (report only) ----------------
print("\n== sanity: 'Sect.' refs now present ==")
for m in sorted(set(re.findall(r"Sect\. \d+(?:\.\d+)?", md))):
    print("  ", m, md.count(m))
print("\n== sanity: heading list ==")
for line in md.splitlines():
    if re.match(r"^#{1,3} \d+\.", line):
        print("  ", line)
print("\n== sanity: pmf / proton-motive force ==")
print("   'proton-motive force':", md.count("proton-motive force"), "| 'pmf':", md.count("pmf"))
print("\n== sanity: figure embeds ==")
figs = re.findall(r"figures/(fig\d+[a-z0-9_]*)\.png", md)
print("   ", figs)
print("   sequential check:", [int(f[3:5] if False else f[3:4] + ('' )) for f in []] or
      all(int(f[3:5]) == i+1 for i, f in enumerate(sorted(set(figs), key=lambda x: int(x[3:5])))))
