#!/usr/bin/env python3
"""75_final_numbers.py — after the eps sweep: update the manuscript's design-table
numbers to the corrected-engine (V4) values, regenerate fig13 + fig17, and print
the change log. Also fills any remaining @PERSIST@/@SPONT@ placeholders.
"""
import glob, json, os
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = os.path.join(ROOT, "manuscript", "triple_unity_v4_full.md")
md = open(F).read()

runs = {}
for f in sorted(glob.glob(os.path.join(ROOT, "data", "design_table_v4_eps*.json"))):
    d = json.load(open(f)); runs[float(d["EPS"])] = d
assert 0.0 in runs, "eps=0 sweep output missing"
e0 = runs[0.0]
func = e0["functional_count"]
canon = e0["canonical"]
cls = e0["classes"]
m_all = cls["all-pos 3-cycle"]["median_Q"]
m_1n = cls["3-cycle 1-neg"]["median_Q"]
m_2n = cls["3-cycle 2-neg"]["median_Q"]
pct = 100.0 * func / e0["n_topo"]

# spont text (same logic as 73)
tot0 = e0["n_topo"] * e0["n_param"]
sp0 = e0["spont_param_sets"]
parts = [f"{sp0} of {tot0:,} parameter sets ({100*sp0/tot0:.2f}%) ignite from the near-dead state "
         f"at \\ensuremath{{\\varepsilon}} = 0"]
for eps in sorted(runs):
    if eps == 0.0:
        continue
    r = runs[eps]
    tot = r["n_topo"] * r["n_param"]
    parts.append(f"{r['spont_param_sets']} of {tot:,} ({100*r['spont_param_sets']/tot:.1f}%) at "
                 f"\\ensuremath{{\\varepsilon}} = {eps:g}")
spont_text = "; ".join(parts) + (
    ". The critical-leak line of Sect. 6.2 is exactly this boundary seen from the enumeration side: "
    "basal flux below \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}) leaves genesis a rare discrete event; above it, "
    "ignition becomes the rule rather than the exception.")

reps = [
    # persistence count (V3's 9,915) — appears several times
    ("9,915 of 9,936", f"{func:,} of 9,936"),
    ("(9,915 topologies qualify)", f"({func:,} topologies qualify)"),
    ("Ninety-nine point eight per cent of Hamiltonian-cycle topologies",
     f"{pct:.1f} per cent of Hamiltonian-cycle topologies"),
    ("@PERSIST@", f"{func:,}"),
    ("@SPONT@", spont_text),
    # canonical Q / basin
    ("Q = 30, basin fraction\n0.45", f"Q = {canon['Q']:.0f}, basin fraction\n{canon['basin']:.2f}"),
    ("sits at Q = 30, at the median of the most robust class (63)",
     f"sits at Q = {canon['Q']:.0f}, at the median of the most robust class ({m_all:.0f})"),
    ("the canonical loop itself sits at\nQ = 30, at the class median (63) rather than above it",
     f"the canonical loop itself sits at\nQ = {canon['Q']:.0f}, at the class median ({m_all:.0f}) rather than above it"),
    ("(Q = 30 vs 63)", f"(Q = {canon['Q']:.0f} vs {m_all:.0f})"),
    ("sits at its class median (Q = 30 vs class median 63)",
     f"sits at its class median (Q = {canon['Q']:.0f} vs class median {m_all:.0f})"),
    ("the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits mid-field (Q = 30, basin fraction\n0.45)",
     f"the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits mid-field (Q = {canon['Q']:.0f}, basin fraction\n{canon['basin']:.2f})"),
    # class medians in the sign-class table
    ("| all-positive (+++) | 1,431 | **63** | most robust design |",
     f"| all-positive (+++) | 1,431 | **{m_all:.0f}** | most robust design |"),
    ("| one negative (+\\ensuremath{-}+) | 3,321 | 40 | intermediate |",
     f"| one negative (+\\ensuremath{{-}}+) | 3,321 | {m_1n:.0f} | intermediate |"),
    ("| two negatives (+\\ensuremath{-}\\ensuremath{-}) | 5,163 | 18 | least robust of the three-cycles |",
     f"| two negatives (+\\ensuremath{{-}}\\ensuremath{{-}}) | 5,163 | {m_2n:.0f} | least robust of the three-cycles |"),
    ("median Q = 63 versus 18\nfor two-negative cycles",
     f"median Q = {m_all:.0f} versus {m_2n:.0f}\nfor two-negative cycles"),
    ("all-positive cycles are the most robust designs, and self-repair is a separate, rare capacity requiring negative feedback.",
     f"the all-positive sign class is the most robust (median Q = {m_all:.0f}); knockdown self-repair is a separate, rarer capacity requiring negative feedback."),
]
changed = []
for old, new in reps:
    if old in md:
        if old != new:
            md = md.replace(old, new)
            changed.append((old[:60], new[:60]))
    else:
        print("  [skip, not found]", old[:70])

open(F, "w").write(md)
print(f"\n{len(changed)} manuscript numbers updated")
print("V4 baseline (eps=0):")
print(f"  functional: {func} of 9936 ({pct:.2f}%)")
print(f"  canonical: Q={canon['Q']:.0f} Qp={canon['Qp']:.0f} spont={canon['spont']} basin={canon['basin']:.3f}")
for k in sorted(cls):
    print(f"  {k}: n={cls[k]['count']} medianQ={cls[k]['median_Q']} medianQp={cls[k]['median_Qp']}")
for eps in sorted(runs):
    c = runs[eps]["classes"]
    print(f"  eps={eps}: spont={runs[eps]['spont_param_sets']}  "
          f"Q medians {c['all-pos 3-cycle']['median_Q']}/{c['3-cycle 1-neg']['median_Q']}/{c['3-cycle 2-neg']['median_Q']}")
json.dump(dict(runs={str(e): r for e, r in runs.items()}),
          open(os.path.join(ROOT, "data", "design_table_v4_summary.json"), "w"), indent=1)
