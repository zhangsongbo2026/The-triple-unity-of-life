#!/usr/bin/env python3
"""53c_founder_patch.py — Founder-patch experiment (deterministic spatial model).
Dead state exactly absorbing; founder = simultaneous seed of (m,e,i) over a disc.
Outcome classes per (rho, patch radius r, founder size s0):
  extinct  : live area -> 0
  pinned   : live area settles near the founder area (self-sustaining island, no expansion)
  expanding: live area grows beyond the founder area
Output: data/processed/founder_patch.json
"""
import os, json
import numpy as np

OUTP = "/app/workspaces/e536ea244ec7/projects/5d075b7975/sessions/wk3vr045/task_263/data/processed"
BASE = dict(rho=1.0, ell=0.35, gam=0.6, a=2.0, delta=0.5, b=1.5, w=0.15)

def run(rho, s0, patch_r, D=0.05, T=400, dt=0.1, L=40):
    p = dict(BASE, rho=rho, D=D)
    m = np.zeros((L, L)); e = np.zeros((L, L)); i = np.zeros((L, L))
    yy, xx = np.mgrid[0:L, 0:L]
    patch = (xx - L//2)**2 + (yy - L//2)**2 <= patch_r**2
    m[patch] = s0; e[patch] = s0; i[patch] = s0
    founder_area = float(patch.sum()) / (L*L)
    for t in range(int(T/dt)):
        e_nb = (np.roll(e,1,0)+np.roll(e,-1,0)+np.roll(e,1,1)+np.roll(e,-1,1))/4.0
        dm = p["b"]*i*(1-m) - p["w"]*m
        de = p["rho"]*m*(1-e) - p["ell"]*e - p["gam"]*e*i + p["D"]*(e_nb-e)
        di = p["a"]*e*i*(1-i) - p["delta"]*i
        m = np.clip(m+dt*dm,0,1); e = np.clip(e+dt*de,0,1); i = np.clip(i+dt*di,0,1)
    live = float(((i > 0.5) & (e > 0.3)).mean())
    if live < 0.02 * founder_area or live < 0.001:
        cls = "extinct"
    elif live < 1.6 * founder_area:
        cls = "pinned"
    else:
        cls = "expanding"
    return live, founder_area, cls

res = []
L = 40
for rho in (0.9, 1.2, 1.5):
    for patch_r in (2, 5, 8, 12, 19):
        for s0 in (0.9, 0.5, 0.2):
            live, fa, cls = run(rho, s0, patch_r, L=L)
            res.append(dict(rho=rho, patch_r=patch_r, s0=s0, live_area=round(live,4),
                            founder_area=round(fa,4), cls=cls))
        print(f"rho={rho} r={patch_r}: " +
              " ".join(f"s0={r['s0']}:{r['cls']}({r['live_area']:.2f})" for r in res[-3:]), flush=True)

json.dump(dict(L=L, results=res), open(os.path.join(OUTP, "founder_patch.json"), "w"), indent=1)
print("saved founder_patch.json")
