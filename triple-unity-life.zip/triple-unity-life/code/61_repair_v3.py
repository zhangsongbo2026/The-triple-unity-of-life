#!/usr/bin/env python3
"""61_repair_v3.py — consolidated post-merge repairs for the V3 manuscript:
in-text figure-number remaps, duplicate-embed repair, author-year -> [@key] conversion."""
import re, os

D = "/app/workspaces/e536ea244ec7/projects/5d075b7975/sessions/wk3vr045/task_263"
p = os.path.join(D, "manuscript", "triple_unity_v3_full.md")
md = open(p).read()

# 1) duplicate-path embed repair: ](figures/figX)figures/figX  ->  ](figures/figX.png)
md, n1 = re.subn(r"\]\((figures/fig[a-z0-9_]+)\)figures/fig[a-z0-9_]+", r"](\1.png)", md)

# 2) in-text figure-number remaps (V2 numbers -> V3 numbers), single occurrence each
REM = [("Fig. 10a", "Fig. 8a"), ("Fig. 10b", "Fig. 8b"), ("Fig. 3)", "Fig. 4)"),
       ("Fig. 4a", "Fig. 5a"), ("Fig. 4b", "Fig. 5b"), ("Fig. 6a", "Fig. 7a"),
       ("Fig. 6b", "Fig. 7b"), ("Fig. 8c", "Fig. 11c"), ("Fig. 11d", "Fig. 12d"),
       ("Fig. 12)", "Fig. 16)"), ("(Fig. 4)", "(Fig. 5)"), ("(Fig. 5)", "(Fig. 6)"),
       ("(Fig. 6)", "(Fig. 7)"), ("(Fig. 10)", "(Fig. 8)"), ("(Fig. 11)", "(Fig. 12)"),
       ("(Fig. 7, 8)", "(Fig. 10, 11)")]
tmp = md
for i, (old, new) in enumerate(REM):
    tmp = tmp.replace(old, "@@F%d@@" % i, 1)
for i, (old, new) in enumerate(REM):
    tmp = tmp.replace("@@F%d@@" % i, new)
md = tmp

# 3) author-year -> [@key]
MAP = [
 ("(Mitchell 1961, 1979)", "[@mitchell1961; @mitchell1978]"),
 ("(Mitchell 1961)", "[@mitchell1961]"),
 ("(Stock et al. 1999; Jiang et al. 2001; Mitome et al. 2004)", "[@stock1999; @jiang2001; @mitome2004]"),
 ("(Dimroth et al. 2006)", "[@dimroth2006]"),
 ("(Seelert et al. 2000)", "[@seelert2000]"),
 ("(Pogoryelov et al. 2009)", "[@pogoryelov2009]"),
 ("(Matthies et al. 2009)", "[@matthies2009]"),
 ("(Watt et al. 2010)", "[@watt2010]"),
 ("(Haig & Hurst 1991; Freeland & Hurst 1998)", "[@haig1991; @freeland1998]"),
 ("(Sanjuán et al. 2010)", "[@sanjuan2010]"),
 ("(Drake & Holland 1999)", "[@drake1999]"),
 ("(Drake 1991)", "[@drake1991]"),
 ("(Gago et al. 2009)", "[@gago2009]"),
 ("(Eckerle et al. 2007)", "[@eckerle2010]"),
 ("(Smith et al. 2013)", "[@smith2013]"),
 ("(Kun et al. 2005)", "[@kun2005]"),
 ("(Langen et al. 1995)", "[@langen1995]"),
 ("(Moser et al. 1992)", "[@moser1992]"),
 ("(Page et al. 1999)", "[@page1999]"),
 ("(Moser et al. 2006)", "[@moser2006]"),
 ("(West et al. 1997)", "[@west1997]"),
 ("(Lane & Martin 2012)", "[@lane2012]"),
 ("(Lane et al. 2010)", "[@lane2010]"),
 ("(Martin & Russell 2003)", "[@martin2003]"),
 ("(Sojo et al. 2016)", "[@sojo2016]"),
 ("(Michel & Oesterhelt 1980)", "[@michel1980]"),
 ("(Maloney 1983)", "[@maloney1983]"),
 ("(Brand 1991)", "[@brand1991]"),
 ("(Brandes & Bers 2002)", "[@brandes2002]"),
 ("(Nicholls & Ferguson 2013)", "[@nicholls2013]"),
 ("(Hopfield 1974)", "[@hopfield1974]"),
 ("(Ninio 1975)", "[@ninio1975]"),
 ("(Akashi & Gojobori 2002)", "[@akashi2002]"),
 ("(Landauer 1961)", "[@landauer1961]"),
 ("(Bennett 1982)", "[@bennett1982]"),
 ("(Helfrich 1973)", "[@helfrich1973]"),
 ("(Hu et al. 2012)", "[@hu2012]"),
 ("(Rawicz et al. 2000)", "[@rawicz2000]"),
 ("(Nagle & Tristram-Nagle 2000)", "[@nagle2000]"),
 ("(Morlot & Roux 2013)", "[@morlot2013]"),
 ("(Kraus et al. 2021)", "[@kraus2021]"),
 ("(Champoux 2001)", "[@champoux2001]"),
 ("(White 1969; Fuller 1971)", "[@white1969; @fuller1971]"),
 ("(Edelsbrunner et al. 2002; Zomorodian & Carlsson 2004)", "[@edelsbrunner2002; @zomorodian2005]"),
 ("(Tralie & Saul 2018)", "[@tralie2018]"),
 ("(Kanehisa & Goto 2000)", "[@kanehisa2000]"),
 ("(Berman et al. 2000)", "[@berman2000]"),
 ("(UniProt Consortium 2023)", "[@uniprot2023]"),
 ("(Biopython, Cock et al. 2009; NetworkX, Hagberg et al. 2008; matplotlib, Hunter 2007)",
  "[@cock2009; @hagberg2008; @hunter2007; @tralie2018]"),
 ("(Rashevsky 1955)", "[@rashevsky1955]"),
 ("(Maturana & Varela 1980)", "[@maturana1980]"),
 ("(Varela et al. 1974)", "[@varela1974]"),
 ("(Gánti 2003)", "[@ganti2003]"),
 ("(Rosen 1958)", "[@rosen1958]"),
 ("(Prigogine 1971)", "[@prigogine1971]"),
 ("(Friston 2010)", "[@friston2010]"),
 ("(Tononi 2004)", "[@tononi2004]"),
 ("(Brown et al. 2004)", "[@brown2004]"),
 ("(Milo et al. 2002)", "[@milo2002]"),
 ("(Brandman et al. 2005)", "[@brandman2005]"),
 ("(Tsai et al. 2008)", "[@tsai2008]"),
 ("(Bak, Tang and Wiesenfeld 1987)", "[@btw1987]"),
 ("(Lakatos 1970)", "[@lakatos1970]"),
 ("(Kuhn 1962)", "[@kuhn1962]"),
 ("(Schrödinger 1944)", "[@schrodinger1944]"),
 ("(Aon et al. 2004)", "[@aon2004]"),
 ("(Figge et al. 2012)", "[@figge2012]"),
 ("(Zhu & Szostak 2009)", "[@zhu2009]"),
 ("(Crick 1968)", "[@crick1968]"),
 ("(Woese 1965)", "[@woese1965]"),
 ("(Koonin 2009)", "[@koonin2009]"),
 ("(Shen et al. 2021)", "[@shen2021]"),
 ("(Ma et al. 2009)", "[@ma2009]"),
 ("(Yang et al. 2013)", "[@yang2013]"),
 ("(Li et al. 2004)", "[@li2004]"),
 ("(Jiang et al. 2001)", "[@jiang2001]"),
 ("(Fiedler 1973)", "[@fiedler1973]"),
 ("(Dimova 2019)", "[@dimova2019]"),
 ("(Drummond & Wilke 2009)", "[@drummond2009]"),
 ("(Rolfe & Brand 1997)", "[@rolfe1997]"),
 ("(Shannon 1948)", "[@shannon1948]"),
 ("(BTW 1987)", "[@btw1987]"),
]
n3 = 0
for old, new in MAP:
    if old in md:
        md = md.replace(old, new); n3 += 1
# multi-line variants
md = md.replace("(Brandman et al. 2005; Tsai et al.\n2008; Li et al. 2004)", "[@brandman2005; @tsai2008; @li2004]")
md = md.replace("(Kuhn\n1962; Lakatos 1970)", "[@kuhn1962; @lakatos1970]")

# 4) section number fix
md = md.replace("# 7. Evidence discipline", "# 10. Evidence discipline")

open(p, "w").write(md)
print("repairs: dup-embed %d, author-year %d" % (n1, n3))
left = re.findall(r"\([A-ZÀ-Ž][^()]*[0-9]{4}\)", md)
print("remaining author-year:", sorted(set(left))[:12])
