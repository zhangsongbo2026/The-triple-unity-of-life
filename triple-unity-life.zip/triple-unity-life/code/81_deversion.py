#!/usr/bin/env python3
"""81_deversion.py — publication-state final pass (editor round 5):
de-version the main text (narrative kept, version labels folded into the history
note), referee -> reader/critical-colleague compliance, leftover invasion-figure
citations (3), dangling earlier/previous check."""
import re

F = "/app/workspaces/e536ea244ec7/projects/5d075b7975/sessions/wk3vr045/task_264/manuscript/triple_unity_v4_source.md"
md = open(F).read()
n = 0

def rep(old, new, count=1):
    global md, n
    assert old in md, f"NOT FOUND: {old[:90]!r}"
    md = md.replace(old, new, count)
    n += 1

# ---- intro opening (keep structure, de-label) ----
rep("Version 2 of this framework closed with a claim we can now afford to examine:",
    "An earlier formulation of this framework closed with a claim we can now afford to examine:")
rep("A referee's rejoinder was immediate and\ncorrect:",
    "The obvious rejoinder was immediate and\ncorrect:")
rep("This version is our answer. It does three things the previous version could not.",
    "This manuscript is our answer. It does three things the earlier formulation could not.")
rep("Everything else from version 2 survives here:",
    "Everything else from the earlier formulation survives here:")
rep("CrossRef-verified for version 2; eighteen more are verified for this version, including the",
    "CrossRef-verified in the initial analysis; eighteen more are verified here, including the")
rep("We report this as the version's most instructive negative.",
    "We report this as the manuscript's most instructive negative.")

# ---- 3.2 margins ----
rep("Version 2 presented eight\nmeasured proton-motive forces",
    "An initial analysis presented eight\nmeasured proton-motive forces")
rep("Two referees put a finger on the same wound:",
    "Two readers of an earlier draft put a finger on the same wound:")
rep("the\nmammalian case is exactly what the referees suspected and is now stated as such:",
    "the\nmammalian case is exactly what those readers suspected and is now stated as such:")

# ---- 2. negative heuristic ----
rep("**Negative heuristic.** Referees and authors agree not to attack",
    "**Negative heuristic.** Author and critical readers agree not to attack")

# ---- 3.6 viruses ----
rep("**Viruses.** Version 2 argued that the virus, carrying only the symbol layer, is",
    "**Viruses.** An earlier formulation argued that the virus, carrying only the symbol layer, is")
rep("A referee called this circular, and the call is right: that viruses",
    "One objection, which we accept, calls this circular: that viruses")
rep("with the force the referees asked for.",
    "with the force the objection demanded.")

# ---- 5.4 KEGG ----
rep("Version 2 claimed, from 12 pathway graphs, that metabolic graphs are loop-rich and signalling",
    "A first pass, from 12 pathway graphs, claimed that metabolic graphs are loop-rich and signalling")
rep("A referee identified the flaw precisely: with one graph carrying the",
    "A critical reader identified the flaw precisely: with one graph carrying the")
rep("The claim that survives is smaller than\nversion 2's: topological features encode",
    "The claim that survives is smaller than\nthe first pass's: topological features encode")
rep("computable from a point cloud — the referee's objection is answerable in one plot.",
    "computable from a point cloud — the objection is answerable in one plot.")

# ---- 5.6 ----
# ---- 6.1 ----
# ---- 6.2/6.3 ----
rep("Version 2's minimal ODE could not\nanswer this; it could only show that",
    "An earlier formulation's minimal ODE could not\nanswer this; it could only show that")
rep("Version 3 folded two requirements into criterion (i):",
    "An earlier formulation of the criterion folded two requirements into (i):")
rep("A referee was right to call\nthis a conflation:",
    "A critical reader was right to call\nthis a conflation:")
rep("Version 3 applied\nthem from a fixed out-of-range state",
    "The first implementation applied\nthem from a fixed out-of-range state")

# ---- 6.3.2 subsample + invasion citations (three leftovers) ----
rep("the stratified V4 subsample remain functional", "the stratified subsample remain functional")
rep("rising monotonically with coupling (Fig. 13b). On the",
    "rising monotonically with coupling (Fig. 17b). On the")
rep("three-phase diagram in (\\ensuremath{\\rho}, p_div) (Fig. 13a):",
    "three-phase diagram in (\\ensuremath{\\rho}, p_div) (Fig. 17a):")
rep("| Loop | Dispersal-unlocked invasion boundary (Fig. 13) |",
    "| Loop | Dispersal-unlocked invasion boundary (Fig. 17) |")

# ---- 6.3.3 overturn ----
rep("Version 3 claimed, from the strictest criterion — knockdown self-repair — that persistence and",
    "An earlier run of the enumeration claimed, from the strictest criterion — knockdown self-repair — that persistence and")
rep("What version 3 measured was an artefact of testing",
    "What the first implementation measured was an artefact of testing")

# ---- 6.4 ----
rep("Version 2 gave the ignition curve; the basin surface gives its geometry, and the geometry is what",
    "The ignition curve alone gives a one-parameter slice; the basin surface gives its geometry, and the geometry is what")

# ---- 7.1 ----
rep("The minimal loop has a property that version 2 stated but did not exploit:",
    "The minimal loop has a property stated but not exploited in earlier formulations:")

# ---- 7.2 ----
rep("p_div = 0 pins the island exactly as in version 3, while division",
    "p_div = 0 pins the island exactly as in the no-dispersal case, while division")
rep("What was a liability in version 3 is now a controlled, falsifiable contrast",
    "What was a liability without dispersal is now a controlled, falsifiable contrast")
rep("version 3's all-pinned result is the",
    "the no-dispersal run's all-pinned result is the")

# ---- 7.5 genealogy ----
rep("Version 2's Table 4 omitted the tradition that anticipated the loop most directly, and a referee",
    "An earlier comparative table omitted the tradition that anticipated the loop most directly, and a critical reader")

# ---- 7.6 ----
rep("The referees pressed one question harder than any other: what does the framework do besides the",
    "One question pressed harder than any other: what does the framework do besides the")

# ---- 12 conclusion ----
rep("of version 3's self-repair separation) are places where",
    "of the earlier self-repair claim) are places where")

# ---- acknowledgements ----
rep("testable; the referees of an earlier version made it honest.",
    "testable; the readers of earlier drafts made it honest.")

# ---- 3.2 caveat reviewer ----
rep("An honest caveat, raised by an earlier reviewer:",
    "An honest caveat, raised by a critical reader of an earlier draft:")

# ---- 7.4 earlier version ----
rep("is where an earlier version of this framework was silent, and we address it here as",
    "is where an earlier formulation of this framework was silent, and we address it here as")

# ---- Appendix A de-versioning ----
rep("Registered before the V4 recomputation, in the sense of",
    "Registered before the present recomputation, in the sense of")
rep("- **V4 outcome.** Retained:", "- **Outcome of the present analysis.** Retained:")

# ---- history note: retitle + first-public sentence ----
rep("""**Version note.** The author list of this manuscript series is S. Zhang (single author) in V2,
V3 and V4 alike; no author change has occurred between versions.""",
    """**Note on the manuscript's history.** The version labels below refer to the private manuscript
series; this is the first public version. The author list is S. Zhang (single author) in V2, V3
and V4 alike; no author change has occurred between versions.""")

# ---- 7.4 (iv) "this version" / other stragglers ----
md = re.sub(r"\bVersion 2\b", "The earlier formulation", md)
md = re.sub(r"\bversion 2\b", "the earlier formulation", md)
md = re.sub(r"\bVersion 3\b", "The earlier enumeration", md)
md = re.sub(r"\bversion 3\b", "the earlier enumeration", md)
md = re.sub(r"\bVersion 4\b", "The present version", md)
md = re.sub(r"\bversion 4\b", "the present version", md)
md = re.sub(r"\bV4 subsample\b", "stratified subsample", md)

open(F, "w").write(md)
print(f"{n} targeted patches + regex sweep applied")
leftover = [(i, l.strip()[:100]) for i, l in enumerate(md.splitlines(), 1)
            if re.search(r"[Vv]ersion [234]", l)]
print("leftover version mentions (should be history-note only):")
for i, l in leftover:
    print(f"  {i}: {l}")
EOF_MARKER_UNUSED = None
