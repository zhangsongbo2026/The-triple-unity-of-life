#!/usr/bin/env python3
"""52_kegg_blind.py — Reviewer-C M4: KEGG pathway graphs, BLIND topological classification.

Scale-up from 12 to the full parseable set for three organisms (hsa, eco, sce) restricted to
the three cleanly separable KEGG top-level classes:
  MET (metabolism, 00010-01232), GEN (genetic information, 03000-03420),
  ENV (environmental information / signalling, 04000-04220).
Blind protocol: features computed WITHOUT labels; hierarchical clustering k=2,3;
ARI/NMI against the 3-class label only AFTER clustering.
Nulls: degree-preserving undirected rewiring (lambda2 z-score), directed rewiring
(directed-cycle edge fraction z-score).
"""
import os, json, time, re
import numpy as np
import requests
import xml.etree.ElementTree as ET
import networkx as nx
from scipy.cluster.hierarchy import linkage, fcluster
from sklearn.metrics import adjusted_rand_score as ari, normalized_mutual_info_score as nmi

RAW = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "raw")
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "processed")
UA = {"User-Agent": "triple-unity-paper/3.0 (research use)"}

CLASSES = [("MET", 10, 1232), ("GEN", 3000, 3420), ("ENV", 4000, 4220)]

def pclass(pid_num):
    for tag, lo, hi in CLASSES:
        if lo <= pid_num <= hi:
            return tag
    return None

def get(url, path, retries=2):
    if os.path.exists(path) and os.path.getsize(path) > 0:
        return True
    for i in range(retries):
        try:
            r = requests.get(url, headers=UA, timeout=30)
            r.raise_for_status()
            open(path, "w").write(r.text)
            return True
        except Exception:
            time.sleep(1.5)
    return False

def parse_graph(path):
    """Directed graph from KGML. Metabolic: compound graph from reactions.
    Others: directed relations between entries."""
    kind = "reaction"
    root = ET.parse(path).getroot()
    G = nx.DiGraph()
    if kind == "reaction":
        for rxn in root.findall("reaction"):
            subs = [s.attrib["id"] for s in rxn.findall("substrate")]
            prods = [s.attrib["id"] for s in rxn.findall("product")]
            rev = rxn.attrib.get("type", "irreversible") == "reversible"
            for s in subs:
                for p in prods:
                    if s != p:
                        G.add_edge(s, p)
                        if rev:
                            G.add_edge(p, s)
    for rel in root.findall("relation"):
        e1, e2 = rel.attrib["entry1"], rel.attrib["entry2"]
        if e1 != e2:
            G.add_edge(e1, e2)
    G.remove_nodes_from(list(nx.isolates(G)))
    return G

def features(G):
    if G.number_of_nodes() < 6:
        return None
    wcc = max(nx.weakly_connected_components(G), key=len)
    H = G.subgraph(wcc).copy()
    n, m = H.number_of_nodes(), H.number_of_edges()
    U = H.to_undirected()
    c = nx.number_connected_components(U)
    beta1 = m - n + c
    try:
        lam2 = nx.algebraic_connectivity(U) if n > 2 else 0.0
    except Exception:
        lam2 = 0.0
    # directed-cycle edge fraction via SCCs
    sccs = [s for s in nx.strongly_connected_components(H) if len(s) > 1]
    cyc_nodes = set().union(*sccs) if sccs else set()
    cyc_edges = sum(1 for a, b in H.edges() if a in cyc_nodes and b in cyc_nodes)
    frac_cyc = cyc_edges / m if m else 0.0
    degs = [d for _, d in U.degree()]
    return dict(V=n, E=m, beta1=beta1, beta1_over_V=beta1 / n, lam2=lam2,
                frac_cyc=frac_cyc, mean_deg=float(np.mean(degs)))

def null_z(G, nswap=200, tries=60):
    """z-scores of lambda2 (undirected degree-preserving rewiring) and
    directed-cycle edge fraction (directed rewiring)."""
    H = max(nx.weakly_connected_components(G), key=len)
    H = G.subgraph(H).copy()
    if H.number_of_nodes() < 8:
        return None
    U0 = H.to_undirected()
    lam0 = nx.algebraic_connectivity(U0) if nx.is_connected(U0) else 0.0
    lams, fracs = [], []
    base_frac = None
    sccs = [s for s in nx.strongly_connected_components(H) if len(s) > 1]
    cyc_nodes = set().union(*sccs) if sccs else set()
    base_frac = sum(1 for a, b in H.edges() if a in cyc_nodes and b in cyc_nodes) / max(1, H.number_of_edges())
    for t in range(tries):
        try:
            U = U0.copy()
            nx.double_edge_swap(U, nswap=50, max_tries=5000, seed=t)
            if nx.is_connected(U):
                lams.append(nx.algebraic_connectivity(U))
        except Exception:
            pass
        D = H.copy()
        try:
            nx.directed_edge_swap(D, nswap=30, max_tries=3000, seed=1000 + t)
            sccs = [s for s in nx.strongly_connected_components(D) if len(s) > 1]
            cyc_nodes = set().union(*sccs) if sccs else set()
            fracs.append(sum(1 for a, b in D.edges() if a in cyc_nodes and b in cyc_nodes)
                         / max(1, D.number_of_edges()))
        except Exception:
            pass
    if not lams or not fracs:
        return None
    zl = (lam0 - np.mean(lams)) / (np.std(lams) + 1e-12)
    zf = (base_frac - np.mean(fracs)) / (np.std(fracs) + 1e-12)
    return dict(lam2_z=float(zl), frac_cyc_z=float(zf))

def main():
    # 1. pathway lists
    todo = []
    for org in ("hsa", "eco", "sce"):
        lst = os.path.join(RAW, f"pathway_list_{org}.txt")
        if not get(f"https://rest.kegg.jp/list/pathway/{org}", lst):
            continue
        for line in open(lst):
            pid = line.split("\t")[0].replace("path:", "")
            num = int(re.sub(r"\D", "", pid.replace(org, "", 1))[:5]) if False else \
                  int(pid.replace(org, "", 1))
            tag = pclass(num)
            if tag:
                todo.append((org, pid, tag))
    print(f"pathways to fetch: {len(todo)}")
    # 2. fetch KGML + parse
    rows = []
    t0 = time.time()
    for i, (org, pid, tag) in enumerate(todo):
        fp = os.path.join(RAW, f"kgml_{pid}.xml")
        if not get(f"https://rest.kegg.jp/get/{pid}/kgml", fp):
            continue
        try:
            G = parse_graph(fp)
        except Exception:
            continue
        f = features(G)
        if f is None:
            continue
        f.update(org=org, pid=pid, label=tag)
        rows.append(f)
        if (i + 1) % 40 == 0:
            print(f"  {i+1}/{len(todo)} elapsed {time.time()-t0:.0f}s kept {len(rows)}", flush=True)
        time.sleep(0.25)
    print(f"parsed graphs: {len(rows)}")
    # 3. blind clustering on topology features
    import numpy as np
    F = np.array([[np.log1p(r["V"]), np.log1p(r["E"]), r["beta1_over_V"],
                   r["lam2"], r["frac_cyc"], r["mean_deg"]] for r in rows])
    Fz = (F - F.mean(0)) / (F.std(0) + 1e-12)
    labels = np.array([r["label"] for r in rows])
    Z = linkage(Fz, method="average", metric="euclidean")
    res = {}
    best = None
    for k in (2, 3, 4, 5):
        cl = fcluster(Z, k, criterion="maxclust")
        a3, n3 = ari(labels, cl), nmi(labels, cl)
        # binary metabolism vs rest
        lab2 = np.array([0 if l == "MET" else 1 for l in labels])
        a2 = ari(lab2, cl)
        res[k] = dict(ARI_3class=float(a3), NMI_3class=float(n3), ARI_METvsREST=float(a2))
        if best is None or a3 > best[1]:
            best = (k, a3, cl)
    print("blind clustering:", json.dumps(res, indent=1))
    # confusion for best k=3
    k, a3, cl = best
    conf = {}
    for ci in np.unique(cl):
        sub = labels[cl == ci]
        conf[f"cluster{ci}"] = {t: int((sub == t).sum()) for t in ("MET", "GEN", "ENV")}
    print("confusion (best k):", json.dumps(conf, indent=1))
    # class means of key features
    means = {t: dict(beta1_over_V=float(np.mean([r["beta1_over_V"] for r in rows if r["label"] == t])),
                     frac_cyc=float(np.mean([r["frac_cyc"] for r in rows if r["label"] == t])),
                     lam2=float(np.mean([r["lam2"] for r in rows if r["label"] == t])))
             for t in ("MET", "GEN", "ENV")}
    # 4. nulls for a sample of graphs (compute budget)
    zs = []
    rng = np.random.default_rng(7)
    sample_idx = rng.choice(len(rows), size=min(60, len(rows)), replace=False)
    for j in sample_idx:
        r = rows[j]
        fp = os.path.join(RAW, f"kgml_{r['pid']}.xml")
        G = parse_graph(fp)
        zz = null_z(G)
        if zz:
            zs.append(dict(pid=r["pid"], label=r["label"], **zz))
    json.dump(dict(n_graphs=len(rows), clustering=res, best_k=k, confusion=conf,
                   class_means=means, nulls=zs),
              open(os.path.join(OUT, "kegg_blind.json"), "w"), indent=1)
    import csv
    with open(os.path.join(OUT, "kegg_features.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["pid", "org", "label", "V", "E", "beta1", "beta1_over_V", "lam2",
                    "frac_cyc", "mean_deg"])
        for r in rows:
            w.writerow([r["pid"], r["org"], r["label"], r["V"], r["E"], r["beta1"],
                        round(r["beta1_over_V"], 4), round(r["lam2"], 5),
                        round(r["frac_cyc"], 4), round(r["mean_deg"], 3)])
    print("saved kegg_blind.json / kegg_features.csv ; total", time.time() - t0)

if __name__ == "__main__":
    main()
