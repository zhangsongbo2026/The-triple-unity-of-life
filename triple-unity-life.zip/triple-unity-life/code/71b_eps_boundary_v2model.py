#!/usr/bin/env python3
"""71b: eps_c(rho) + 1D front velocity on the §6.2 model family itself.
   dm = b*i*(1-m) - w*m + eps ;  de = rho*m*(1-e) - l*e - g*e*i + eps ;  di = a*e*i*(1-i) - d*i + eps
   base params (V3 §6.2/12b): b=1.5, w=0.15, rho varies, l=0.35, g=0.6, a=2.0, d=0.5
Output: data/eps_boundary_v2.json
"""
import numpy as np, json
from scipy.integrate import solve_ivp
B, W, G_, A, D = 1.5, 0.15, 0.6, 2.0, 0.5

def rhs(t, y, rho, eps, l=0.35):
    m, e, i = y
    return [B*i*(1-m) - W*m + eps,
            rho*m*(1-e) - l*e - G_*e*i + eps,
            A*e*i*(1-i) - D*i + eps]

def ignites(rho, eps, l=0.35, T=800.0):
    y0 = [1.2*eps/W, 1.2*eps/l, 1.2*eps/D]
    s = solve_ivp(rhs, (0, T), y0, args=(rho, eps, l), rtol=1e-8, atol=1e-10, max_step=1.0)
    return float(s.y[2, -1]) > 0.5

def eps_c(rho, l=0.35):
    lo, hi = 1e-7, 0.2
    if ignites(rho, lo, l): return 0.0
    if not ignites(rho, hi, l): return float('nan')
    for _ in range(42):
        mid = np.sqrt(lo*hi)
        if ignites(rho, mid, l): hi = mid
        else: lo = mid
        if hi/lo < 1.02: break
    return float(np.sqrt(lo*hi))

print("eps_c(rho) on the §6.2 family (l=0.35):")
tab = []
for r in sorted(set([round(x,2) for x in np.linspace(0.35, 2.0, 18)])):
    ec = eps_c(r); tab.append((r, ec)); print(f"  rho={r:4.2f}  eps_c={ec:.3e}")

# 1D front velocity, e diffuses (D=0.05), i optional, m immobile; reflecting BC
def front_speed(rho, D_i=0.0, D_e=0.05, l=0.35, NX=600, T=1500.0, dt=0.02):
    ss = solve_ivp(rhs, (0, 800), [0.5,0.5,0.5], args=(rho,0.0,l), rtol=1e-9, atol=1e-11, max_step=1.0).y[:,-1]
    m = np.zeros(NX); e = np.zeros(NX); ii = np.zeros(NX); x0 = NX//3
    m[:x0]=ss[0]; e[:x0]=ss[1]; ii[:x0]=ss[2]
    def lapn(u):
        d = (np.roll(u,1)+np.roll(u,-1)-2*u); d[0]=u[0]-u[1]; d[-1]=u[-1]-u[-2]; return d
    pos=[]
    for s in range(int(T/dt)):
        dm = B*ii*(1-m) - W*m
        de = rho*m*(1-e) - l*e - G_*e*ii + D_e*lapn(e)
        di = A*e*ii*(1-ii) - D*ii + (D_i*lapn(ii) if D_i>0 else 0.0)
        m=np.clip(m+dt*dm,0,1); e=np.clip(e+dt*de,0,1); ii=np.clip(ii+dt*di,0,1)
        t=s*dt
        if abs(t-round(t/50)*50)<1e-6:
            live = ii>0.5; x=0
            while x<NX and live[x]: x+=1
            pos.append((t, x-1))
    return (pos[-1][1]-pos[2][1])/(pos[-1][0]-pos[2][0]), pos[-1][1]

front=[]
for Di in (0.0, 0.02):
    for r in (0.6, 0.9, 1.2, 1.5, 4.0):
        v, end = front_speed(r, D_i=Di)
        front.append(dict(D_i=Di, rho=r, v=round(v,4), front_end=int(end)))
        print(f"front: D_i={Di} rho={r}: v={v:+.4f} end@{end}")

# also: does a live state exist at l=0.15 (the plan's leak) for reference?  skip.
json.dump(dict(eps_table=[[r, e] for r, e in tab],
               params=dict(b=B, w=W, gam=G_, a=A, delta=D, l=0.35),
               front=front), open('data/eps_boundary_v2.json','w'), indent=1)
print("saved data/eps_boundary_v2.json")
