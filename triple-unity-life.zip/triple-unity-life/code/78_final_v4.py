#!/usr/bin/env python3
"""78_final_v4.py — fill V4 numbers, apply the self-repair overturn, rebuild claims.
Reads:  data/design_table_v4_eps*.json (subsample sweep) + benchmark values
Writes: manuscript/triple_unity_v4_full.md (patched) + prints the change log.
"""
import glob, json, os

ROOT = "/app/workspaces/e536ea244ec7/projects/5d075b7975/sessions/wk3vr045/task_264"
F = os.path.join(ROOT, "manuscript", "triple_unity_v4_source.md")
md = open(F).read()
n = 0

def rep(old, new, count=1):
    global md, n
    assert old in md, f"NOT FOUND: {old[:90]!r}"
    md = md.replace(old, new, count)
    n += 1

runs = {}
for f in sorted(glob.glob(os.path.join(ROOT, "data", "design_table_v4_eps*.json"))):
    d = json.load(open(f))
    runs[float(d["EPS"])] = d
e0 = runs[0.0]
sp0 = e0["spont_param_sets"]; tot0 = e0["total_param_sets"]
sp1 = runs[0.001]["spont_param_sets"]; sp01 = runs[0.01]["spont_param_sets"]; sp1e1 = runs[0.1]["spont_param_sets"]
cls0 = e0["classes"]

# ---------------- 1. criterion-split paragraph (replaces placeholders) ----------------
rep("""The split settles the founder question, and settles it in the theory's favour. Persistence is
generic — @PERSIST@ of 9,936 Hamiltonian-cycle topologies support a load-bearing
self-maintaining state under at least one parameter set at \\ensuremath{\\varepsilon} = 0 — while **spontaneous
genesis is rare**: @SPONT@ The founder requirement is therefore *strengthened* by the enumeration,
not contradicted by it: the same table that says self-maintenance is generic says that getting
there from the dead state is a separate, rare event.""",
    """The split settles the founder question, and settles it in the theory's favour. Persistence is
unchanged by the split — the full enumeration's 9,915 of 9,936 functional topologies qualify under
either wording, and all 1,983 topologies of the stratified V4 subsample remain functional — while
**spontaneous genesis is rare and leak-gated**: \\ensuremath{\\varepsilon} = 0: 26,802 of 396,600 parameter sets
(6.8%) ignite from the near-dead state; \\ensuremath{\\varepsilon} = 10^{-3}: 7.3%; \\ensuremath{\\varepsilon} = 10^{-2}: 10.2%;
\\ensuremath{\\varepsilon} = 10^{-1}: 22.4%. The critical-leak line of Sect. 6.2 is exactly this boundary seen from the
enumeration side: basal flux below \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}) leaves genesis a rare discrete event, and even
a leak ten times the \\ensuremath{\\varepsilon}_c scale leaves most of design space founder-dependent. The founder
requirement is therefore *strengthened* by the enumeration, not contradicted by it: the same table
that says self-maintenance is generic says that getting there from the dead state is a separate,
rare event.""")

# ---------------- 2. the sign-class table + medians (subsample corroboration) ----------------
rep(""": Robustness of self-maintenance by sign structure (9,936 Hamiltonian-cycle topologies,
200 parameter sets each). The claim is about the class, not an individual: the canonical
C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop (+++) sits at Q = 30, at the median of the most robust class rather than
above it. The ranking is unchanged at every basal-leak level \\ensuremath{\\varepsilon} in {0, 10^-3, 10^-2, 10^-1}
(Fig. 17b).""",
    """: Robustness of self-maintenance by sign structure (9,936 Hamiltonian-cycle topologies,
200 parameter sets each). The claim is about the class, not an individual: the canonical
C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop (+++) sits at Q = 31, below the median of its own class. The ranking is
preserved at every basal-leak level \\ensuremath{\\varepsilon} \\ensuremath{\\in} {0, 10^{-3}, 10^{-2}, 10^{-1}} on the stratified
subsample (medians 65/40/19, 66/41/19, 69/46/24, 53/39/30 across the four levels — ordered
throughout, compressing as the leak floods the design space), and preserved again at 2,000
parameter sets on the 50-topology convergence subset (Fig. 17b).""")

# ---------------- 3. the self-repair overturn: rewrite 6.3.3 ----------------
rep("""### 6.3.3 Genesis and homeostasis are different design problems

The strictest criterion — knockdown self-repair — is satisfied by almost none of the robust
topologies. This is not a numerical shadow: it is a structural fact about positive feedback. An
all-positive loop told to survive a knockdown amplifies the perturbation (the canonical loop has
zero recovering parameter sets among 200 in our scheme), while negative feedback is what restores
a disturbed state. Persistence and homeostasis therefore occupy different regions of design space.

This is an old idea with a modern quantitative form — the interlinked fast-and-slow positive and
negative feedback loops that make cell-fate decisions reliable [2,45--46] — and the enumeration places the present framework inside it rather than
beside it. HC-4 is a claim about persistence, and it should be stated as such: the loop explains
why a living system *keeps existing*, and the regulation of *how much* is a second, negative-feedback
problem. Two predictions follow directly and cheaply (P7 and P8 in Sect. 9): four-node tables should
show that the two functions co-localise in composite topologies, and the mixed topologies should
outrank pure ones on a joint criterion. One boundary condition on everything in this subsection:
it is a three-node table. Design-space volume grows super-exponentially with node count, and
nothing here rules out a topological phase change at four nodes at which the all-positive
advantage is diluted by mixed-sign modular structures — which is precisely why P7 sits at the
front of the positive heuristic rather than in the discussion.""",
    """### 6.3.3 What the corrected engine taught us: self-repair is not separate — genesis is

Version 3 claimed, from the strictest criterion — knockdown self-repair — that persistence and
homeostasis occupy different regions of design space, and that the canonical loop had *zero*
recovering parameter sets. **The corrected engine overturns that claim, and we report the
overturning rather than bury it.** With knockdowns taken from the true sampled steady states, the
all-positive class repairs best of all: median self-repair counts Q_p of 56 (against persistence
Q = 65), 25 (Q = 40) and 10 (Q = 19) for the all-positive, one-negative and two-negative classes —
86%, 63% and 53% of their own load-bearing parameter sets. A 30% knockdown of one variable of a
mutually reinforcing loop stays inside the all-high basin, and the loop re-amplifies it: *positive
feedback is what restores positive feedback*. What version 3 measured was an artefact of testing
recovery from an out-of-range state.

What survives — and it is the part that matters — is a separation with a firmer boundary. Genesis
is separated from persistence by the \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}) line: spontaneous ignition is rare (6.8% of
parameter sets at \\ensuremath{\\varepsilon} = 0) even where persistence and self-repair are generic. And adaptation —
returning a *regulated output* to a set-point against a persistent input, Ma et al.'s own
criterion — is a genuinely different design problem with a genuinely different sign requirement
[1]. Persistence, self-repair and adaptation are three functions, not two, and only the first two
share a sign preference. This is an old idea with a modern quantitative form — the interlinked
fast-and-slow positive and negative feedback loops that make cell-fate decisions reliable
[2,45--46] — and the corrected enumeration places the present framework inside it rather than
beside it. HC-4 is a claim about persistence, and it should be stated as such. Two predictions
follow (P7 and P8 in Sect. 9): four-node tables should show that adaptation co-localises with
negative feedback while persistence and repair co-localise with positive reinforcement, and the
mixed topologies should win only on the adaptation criterion. One boundary condition on
everything in this subsection: it is a three-node table. Design-space volume grows
super-exponentially with node count, and nothing here rules out a topological phase change at four
nodes — which is precisely why P7 sits at the front of the positive heuristic rather than in the
discussion.""")

# ---------------- 4. Highlights: self-repair line + eps line ----------------
rep("- Genesis and homeostasis are different design problems: knockdown self-repair needs negative feedback.",
    "- Genesis, not self-repair, is the separated function: spontaneous ignition is rare (6.8% of sets) and leak-gated.")
rep("- The all-positive sign class is the most robust (median Q = 63); the canonical loop sits at the class median.",
    "- The all-positive sign class is the most robust (median Q = 63); the canonical loop sits at Q = 31, mid-class.")

# ---------------- 5. Abstract: self-repair + spont ----------------
rep("""and knockdown self-repair is a rare, separate capacity — genesis and homeostasis are
different design problems.""",
    """and knockdown self-repair follows the same sign hierarchy as persistence — the
separated function is genesis: spontaneous ignition is rare (6.8% of parameter sets) and gated by
a smooth critical-leak line \\ensuremath{\\varepsilon}_c(\\ensuremath{\\rho}).""")
rep("""the all-positive class is the most robust (median Q = 63 versus 18
for two-negative cycles), the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits at its class median (Q = 30, basin fraction
0.45)""",
    """the all-positive class is the most robust (median Q = 63 versus 18
for two-negative cycles), the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits mid-class (Q = 31, basin fraction
0.45)""")

# ---------------- 6. Conclusion: add the overturn ----------------
rep("""Each of
these is a place where the framework could have been wrong and is not, and two of them (the
closeness of the floor, the failure of blind classification) are places where the framework's own
earlier claims were too strong.""",
    """Each of
these is a place where the framework could have been wrong and is not, and three of them (the
closeness of the floor, the failure of blind classification, and the corrected engine's overturning
of version 3's self-repair separation) are places where the framework's own earlier claims were too
strong or its instruments too loose.""")

# ---------------- 7. Highlights SOC line still says "pinned, not invasive" — align ----------------
rep("- Without dispersal live patches are pinned; vesicle-like dispersal unlocks invasion above a critical coupling.",
    "- Without dispersal live patches are pinned (structural, to rho = 4); vesicle-like dispersal unlocks invasion.")

open(F, "w").write(md)
print(f"{n} final V4 patches applied")
