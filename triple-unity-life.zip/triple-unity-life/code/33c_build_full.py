#!/usr/bin/env python3
"""33_build_final_md.py — assign reference numbers by first appearance, emit final markdown."""
import os, re, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
md = open(os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md")).read()
refs = json.load(open(os.path.join(ROOT, "data", "processed", "references.json")))

# collect keys in order of first appearance
order = []
for m in re.finditer(r"\[@([a-zA-Z0-9_]+)((?:;\s*@[a-zA-Z0-9_]+)*)\]", md):
    keys = [m.group(1)] + re.findall(r"@([a-zA-Z0-9_]+)", m.group(2) or "")
    for k in keys:
        if k not in order:
            order.append(k)

missing = [k for k in order if k not in refs]
assert not missing, f"missing keys: {missing}"
num = {k: i + 1 for i, k in enumerate(order)}

def repl(m):
    keys = [m.group(1)] + re.findall(r"@([a-zA-Z0-9_]+)", m.group(2) or "")
    ns = sorted(num[k] for k in keys)
    # compress consecutive runs: [1,2,3] -> [1-3]
    parts, i = [], 0
    while i < len(ns):
        j = i
        while j + 1 < len(ns) and ns[j + 1] == ns[j] + 1:
            j += 1
        parts.append(str(ns[i]) if i == j else f"{ns[i]}–{ns[j]}")
        i = j + 1
    return "[" + ",".join(parts) + "]"

md_out = re.sub(r"\[@([a-zA-Z0-9_]+)((?:;\s*@[a-zA-Z0-9_]+)*)\]", repl, md)

# build reference list in citation order
def fmt_entry(k):
    v = refs[k]
    a = v.get("authors", [])
    fams = []
    for x in a[:6]:
        f = x.get("family", "")
        g = x.get("given", "")
        inis = " ".join(p[0] + "." for p in g.replace("-", "- ").split() if p)
        fams.append(f"{f} {inis}".strip())
    if len(a) > 6:
        fams.append("et al.")
    if not fams:
        fams = ["Anonymous"]
    t = re.sub(r"&amp;", "&", v.get("title", "?"))
    t = re.sub(r"<[^>]+>", "", t)
    j = re.sub(r"<[^>]+>", "", v.get("journal", "?"))
    s = f"{', '.join(fams)} ({v.get('year')}). {t}. {j}"
    if v.get("volume"):
        s += f" {v['volume']}"
    if v.get("pages"):
        s += f", {v['pages']}"
    if v.get("doi"):
        s += f". https://doi.org/{v['doi']}"
    return s

ref_lines = [f"{num[k]}. {fmt_entry(k)}" for k in order]
md_out += "\n\n# References\n\n" + "\n\n".join(ref_lines) + "\n"

open(os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md"), "w").write(md_out)
json.dump(order, open(os.path.join(ROOT, "data", "processed", "citation_order.json"), "w"), indent=1)
print(f"cited {len(order)} references, numbered by first appearance -> triple_unity_v3_numbered.md")
# sanity: figure files exist
import glob
figs = set(re.findall(r"\]\((figures/[A-Za-z0-9_\.]+)\)", md_out))
for f in sorted(figs):
    p = os.path.join(ROOT, f)
    print(("OK  " if os.path.exists(p) else "MISS") + " " + f)

