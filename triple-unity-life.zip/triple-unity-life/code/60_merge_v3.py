#!/usr/bin/env python3
"""60_merge_v3.py — assemble the complete V3 manuscript:
V2 full text as the base, with V3's new sections, corrections and renumbered figures."""

import os, re

ROOT = "/app/workspaces/e536ea244ec7/projects/5d075b7975/sessions/wk3vr045/task_263"
v2 = open(os.path.join(ROOT, "manuscript", "triple_unity.md")).read()
v3 = open(os.path.join(ROOT, "manuscript", "triple_unity_v3.md")).read()

def sections(md, level=1):
    """split by '# '-level headers; return list of (header, body)."""
    pat = re.compile(r"^# .*$", re.M)
    marks = [(m.start(), m.end(), m.group(0)) for m in pat.finditer(md)]
    out = []
    for i, (s, e, h) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(md)
        out.append((h.strip(), md[s:end]))
    return out

v2s = dict((h, body) for h, body in sections(v2))
v3s = dict((h, body) for h, body in sections(v3))

def get(d, prefix):
    for h, body in d.items():
        if h.startswith(prefix):
            return body
    raise KeyError(prefix)

def sub(block, old_prefix, new_prefix):
    """renumber '## old_prefix' style headers inside a top-level block."""
    return block

# ---- V3 front matter (YAML + Highlights + Abstract + Keywords)
v3_front = v3[: v3.index("# 1. Introduction")]

# ---- V3 intro
v3_intro = get(v3s, "# 1. Introduction")

# ---- V3 hard core
v3_hardcore = get(v3s, "# 2. The structure of the theory")

# ---- V2 mechanism section, split into subsections
v2_mech = get(v2s, "# 2. The mechanism unity")
m21 = v2_mech[v2_mech.index("## 2.1 Closure"): v2_mech.index("## 2.2")]
m23 = v2_mech[v2_mech.index("## 2.3 Geometric"): v2_mech.index("## 2.4")]
m24 = v2_mech[v2_mech.index("## 2.4 Scale"): v2_mech.index("## 2.5")]
m25 = v2_mech[v2_mech.index("## 2.5 One motor"): v2_mech.index("## 2.6")]

# ---- V3 mechanism: margins (3.2) and boundary (3.6)
v3_mech = get(v3s, "# 3. The mechanism unity")
v3_m32 = v3_mech[v3_mech.index("## 3.2 The coupling window"): v3_mech.index("## 3.3 Geometric")]
v3_m36 = v3_mech[v3_mech.index("## 3.6 The boundary"):]

# ---- symbol section: V2 full with V3's 4.3 boundary conditions
v2_sym = get(v2s, "# 3. The symbol unity")
s31 = v2_sym[v2_sym.index("## 3.1 The channel"): v2_sym.index("## 3.2")]
s32 = v2_sym[v2_sym.index("## 3.2 The energetic"): v2_sym.index("## 3.3")]
s34 = v2_sym[v2_sym.index("## 3.4 The cost of freezing"): v2_sym.index("## 3.5")]
s35 = v2_sym[v2_sym.index("## 3.5 Proposition I"):]
v3_sym = get(v3s, "# 4. The symbol unity")
v3_s43 = v3_sym[v3_sym.index("## 4.3 The code is optimal"): v3_sym.index("## 4.4")]

# ---- language section: V2 full, networks replaced by V3 blind
v2_lang = get(v2s, "# 4. The language unity")
l41 = v2_lang[v2_lang.index("## 4.1 Topological"): v2_lang.index("## 4.2")]
l42 = v2_lang[v2_lang.index("## 4.2 Membranes"): v2_lang.index("## 4.3")]
l43 = v2_lang[v2_lang.index("## 4.3 Chains and their wrapping"): v2_lang.index("## 4.4")]
l45_typing = v2_lang[v2_lang.index("## 4.5 Typing real structures"): v2_lang.index("## 4.6 Proposition T")]
l45 = v2_lang[v2_lang.index("## 4.6 Proposition T"):]
v3_lang = get(v3s, "# 5. The language unity")
v3_l52 = v3_lang[v3_lang.index("## 5.2 Membranes"): v3_lang.index("## 5.3")]
v3_l54 = v3_lang[v3_lang.index("## 5.4 Networks"):]
# tempered claim from V3 5.2 (paragraph 2)
v3_caution = v3_l52.split("\n\n")[2] if len(v3_l52.split("\n\n")) > 2 else ""

# ---- loop section: V2 5.1 + 5.2
v2_loop = get(v2s, "# 5. The closed loop")
lp51 = v2_loop[v2_loop.index("## 5.1 Three couplings"): v2_loop.index("## 5.2")]
lp52 = v2_loop[v2_loop.index("## 5.2 A minimal loop"): v2_loop.index("## 5.3")]

# ---- V3 design table section (6.x)
v3_design = get(v3s, "# 6. The design table")
d61 = v3_design[v3_design.index("## 6.1 The question"): v3_design.index("## 6.2")]
d62 = v3_design[v3_design.index("## 6.2 What the enumeration found"): v3_design.index("## 6.3")]
d63 = v3_design[v3_design.index("## 6.3 Genesis and homeostasis"): v3_design.index("## 6.4")]
d64 = v3_design[v3_design.index("## 6.4 The basin surface"):]

# ---- V3 genesis: absorbing + founder + SOC
v3_gen = get(v3s, "# 7. Genesis")
g71 = v3_gen[v3_gen.index("## 7.1 The dead state"): v3_gen.index("## 7.2")]
g72 = v3_gen[v3_gen.index("## 7.2 Founder patches"): v3_gen.index("## 7.3")]
g73 = v3_gen[v3_gen.index("## 7.3 Self-organised criticality"): v3_gen.index("## 7.4")]
g74 = v3_gen[v3_gen.index("## 7.4 The company we keep"):]

# ---- V2 origins narrative (5.3) and lambda2 (5.4)
origins = v2_loop[v2_loop.index("## 5.3 Origins"): v2_loop.index("## 5.4")]
lambda2 = v2_loop[v2_loop.index("## 5.4 Loss of the loop"):]

# ---- V3 predictions + programme + conclusion
v3_preds = get(v3s, "# 8. Predictions")
v3_prog = get(v3s, "# 9. The programme")
v3_concl = get(v3s, "# 10. Conclusion")

# ---- V2 evidence + data availability/ack
v2_evid = get(v2s, "# 7. Evidence discipline")
v2_data = v2[v2.index("# Data and code availability"): v2.index("# Acknowledgements")]
v2_ack = v2[v2.index("# Acknowledgements"):]

def ren(section, pairs):
    for old, new in pairs:
        section = section.replace(old, new)
    return section

# ================= assemble =================
out = []
out.append(v3_front)
FIG1S = ("![Figure 1. The triple unity as a closed loop. Three layers of unequal strength — language "
"(structure), mechanism (energy) and symbol (information) — are joined by the couplings C1, C2 and C3. "
"C1: the topology of the compartment enables a sustained proton-motive force. C2: ATP flux pays the "
"thermodynamic cost of proofreading and code fidelity. C3: the error-minimising code rebuilds structure "
"from a template, closing the loop. Evidence grades: A empirical, B inferred, C model, D interpretive.]"
"(figures/fig01_framework.png){width=6.5in}\n")
v3_intro = v3_intro.replace("genealogical gap.", "genealogical gap.\n\n" + FIG1S, 1)
out.append(v3_intro)
out.append(v3_hardcore)

# 3. mechanism
mech = "# 3. The mechanism unity (energy layer)\n"
mech += ren(m21, [("## 2.1 Closure", "## 3.1 Closure")])
v3_m32 = v3_m32.replace("![Thermodynamic margins.", '\n![Figure 2. The coupling-ratio window. (a) The thermodynamic floor n_H ≥ ΔG_ATP/(FΔp) for four values of the ATP free energy; the shaded band is the measured biological range of Δp. Markers show real c-ring stoichiometries (c/3). (b) Reported proton-motive forces across the three domains (Table 1).](figures/fig02_coupling_window.png){width=6.5in}\n' + "\n![Thermodynamic margins.")
mech += "\n" + ren(v3_m32, [("## 3.2", "## 3.2")])
mech += "\n" + ren(m23, [("## 2.3", "## 3.3")])
mech += "\n" + ren(m24, [("## 2.4", "## 3.4")])
mech += "\n" + ren(m25, [("## 2.5", "## 3.5")])
mech += "\n" + ren(v3_m36, [("## 3.6", "## 3.6")])
# strip V2's old 2.2 (coupling window binary text) — replaced by margins
out.append(mech)

# 4. symbol
sym = "# 4. The symbol unity (information layer)\n"
sym += ren(s31, [("## 3.1", "## 4.1")])
sym += "\n" + ren(s32, [("## 3.2", "## 4.2")])
sym += "\n" + ren(v3_s43, [("## 4.3", "## 4.3")])
sym += "\n" + ren(s34, [("## 3.4", "## 4.4")])
sym += "\n" + ren(s35, [("## 3.5", "## 4.5")])
out.append(sym)

# 5. language
lang = "# 5. The language unity (structure layer)\n"
lang += ren(l41, [("## 4.1", "## 5.1")])
lang += "\n" + ren(l42, [("## 4.2", "## 5.2")])
lang += "\n" + ren(l43, [("## 4.3", "## 5.3")])
lang += "\n" + ren(v3_l54, [("## 5.4", "## 5.4")])
lang += "\n" + ren(l45_typing, [("## 4.5", "## 5.5")])
lang += "\n" + ren(l45, [("## 4.6", "## 5.6")])
out.append(lang)

# 6. loop + design table
loop = "# 6. The closed loop and its design space\n"
loop += ren(lp51, [("## 5.1", "## 6.1")])
loop += "\n" + ren(lp52, [("## 5.2", "## 6.2")])
loop += "\n## 6.3 The design table: which loops can sustain themselves?\n\n" + \
        ren(d61 + "\n" + d62 + "\n" + d63, [("## 6.1", "### 6.3.1"), ("## 6.2", "### 6.3.2"), ("## 6.3", "### 6.3.3")])
loop += "\n" + ren(d64, [("## 6.4", "## 6.4")])
out.append(loop)

# 7. genesis
gen = "# 7. Genesis: absorbing dead states, pinned founders, and the company we keep\n"
gen += "\n" + ren(g71, [("## 7.1", "## 7.1")])
gen += "\n" + ren(g72, [("## 7.2", "## 7.2")])
gen += "\n" + ren(g73, [("## 7.3", "## 7.3")])
gen += "\n" + ren(origins, [("## 5.3", "## 7.4")])
gen += "\n" + ren(g74, [("## 7.4", "## 7.5")])
out.append(gen)

# 8. lambda2 loss
out.append(ren(lambda2, [("## 5.4", "## 8. Loss of the loop")]))

# 9. predictions
out.append(ren(v3_preds, [("## 8. Predictions", "## 9. Predictions")]))

# 10. evidence discipline (V2, with updated table refs)
out.append(ren(v2_evid, [("## 7. Evidence discipline", "## 10. Evidence discipline")]))

# 11. programme
out.append(ren(v3_prog, [("## 9. The programme", "## 11. The programme")]))

# 12. conclusion
out.append(ren(v3_concl, [("## 10. Conclusion", "# 12. Conclusion")]))

# data availability + ack (V2) with V3 note
out.append(v2_data.replace("The 85 primary references were verified against CrossRef",
                           "All 105 primary references were verified against CrossRef"))
out.append(v2_ack)

text = "\n\n".join(x.strip() + "\n" for x in out)
# figure path + caption renumbering (V2 -> V3)
# 1) strip V2 caption prefixes
text = re.sub(r"!\[Figure \d+\.\s*", "![", text)
# 2) translate V2 image paths to V3 paths
PATHMAP = {
    "figures/fig01_framework.png": "figures/fig01_framework.png",
    "figures/fig02_coupling_window.png": "figures/fig02_coupling_window.png",
    "figures/fig03_et_ruler.png": "figures/fig04_et_ruler.png",
    "figures/fig04_atp_homology.png": "figures/fig05_atp_homology.png",
    "figures/fig05_code_minimization.png": "figures/fig06_code_minimization.png",
    "figures/fig06_error_threshold.png": "figures/fig07_error_threshold.png",
    "figures/fig07_membrane_energetics.png": "figures/fig08_membrane_energetics.png",
    "figures/fig09_tda_curves.png": "figures/fig10_tda_curves.png",
    "figures/fig10_typing.png": "figures/fig11_typing.png",
    "figures/fig11_origin_dynamics.png": "figures/fig12_origin_dynamics.png",
    "figures/fig12_lambda2_fragmentation.png": "figures/fig16_lambda2_fragmentation.png",
    "figures/fig13_basin_surface.png": "figures/fig14_basin_surface.png",
    "figures/fig12_design_table.png": "figures/fig13_design_table.png",
}
for old, new in PATHMAP.items():
    text = text.replace(old, new)
# 3) drop any leftover old-kegg figure embeds (replaced by blind version)
text = re.sub(r"!\[[^\]]*\]\(figures/fig08_kegg_loops\.png\)\{[^}]*\}\n?", "", text)
# 4) add V3 caption prefixes by filename
NUM = {"fig01_framework": 1, "fig02_coupling_window": 2, "fig03_margin": 3,
       "fig04_et_ruler": 4, "fig05_atp_homology": 5, "fig06_code_minimization": 6,
       "fig07_error_threshold": 7, "fig08_membrane_energetics": 8,
       "fig09_kegg_blind": 9, "fig10_tda_curves": 10, "fig11_typing": 11,
       "fig12_origin_dynamics": 12, "fig13_design_table": 13,
       "fig14_basin_surface": 14, "fig15_founder": 15,
       "fig16_lambda2_fragmentation": 16}
def add_prefix(m):
    stem = m.group(2).split("/")[-1].replace(".png", "")
    n = NUM[stem]
    return "![Figure %d. %s](%s)%s" % (n, m.group(1), m.group(2), m.group(3) or "")
text = re.sub(r"!\[(.+?)\]\((figures/(fig\d+[a-z0-9_]+)\.png)\)(\{[^}]*\})?", add_prefix, text)
# 5) evidence section number
text = text.replace("# 7. Evidence discipline", "# 10. Evidence discipline")

open(os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md"), "w").write(text)
print("assembled triple_unity_v3_full.md:", len(text), "bytes")
