#!/usr/bin/env python3
"""40_build_latex.py — build the JTB-style LaTeX submission (v3).
Unicode→math transliteration via \\ensuremath{} so pandoc never mis-parses $ spans.
"""
import os, re, subprocess, unicodedata

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MD = os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md")
OUT = os.path.join(ROOT, "manuscript", "triple_unity_V3.tex")

md = open(MD).read()
md = re.sub(r"\A---.*?\n---\n", "", md, flags=re.S)
md = re.sub(r"!\[Figure \d+\.\s*", "![", md)
md = re.sub(r"\n: Table \d+\.\s*", "\n: ", md)
md = unicodedata.normalize("NFC", md)

GREEK = {"α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "varepsilon",
         "κ": "kappa", "λ": "lambda", "μ": "mu", "π": "pi", "ρ": "rho", "σ": "sigma",
         "τ": "tau", "χ": "chi", "Γ": "Gamma", "Δ": "Delta", "Σ": "Sigma",
         "Θ": "Theta", "Ω": "Omega", "ℓ": "ell"}
OPS = {"≈": r"\approx", "≥": r"\geq", "≤": r"\leq", "±": r"\pm", "×": r"\times",
       "→": r"\rightarrow", "∧": r"\wedge", "∝": r"\propto", "≫": r"\gg",
       "−": "-", "·": r"\cdot", "∅": r"\emptyset", "∈": r"\in"}
SUPMAP = {"⁻": "-", "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
          "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9"}
SUBMAP = {"₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4",
          "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9", "ᵢ": "i"}

def em(s):
    return "\\ensuremath{%s}" % s

# combining-macron compounds
md = md.replace("κ\u0304", em(r"\bar\kappa")).replace("g\u0304", em(r"\bar g"))
# explicit compound tokens
TOKENS = {
    "10⁻⁶": em("10^{-6}"), "10⁻⁴": em("10^{-4}"), "10⁻³": em("10^{-3}"),
    "10⁻²": em("10^{-2}"), "10⁻¹": em("10^{-1}"), "10⁶": em("10^{6}"),
    "10⁴": em("10^{4}"), "10³": em("10^{3}"), "10⁵": em("10^{5}"),
}
for k, v in TOKENS.items():
    md = md.replace(k, v)

out = []
for ch in md:
    if ch in GREEK:
        out.append(em("\\" + GREEK[ch]))
    elif ch in OPS:
        out.append(em(OPS[ch]))
    elif ch == "–":
        out.append("--")
    elif ch == "‐":
        out.append("-")
    else:
        out.append(ch)
md = "".join(out)

def sup_run(m):
    return em("^{" + "".join(SUPMAP[c] for c in m.group(0)) + "}")
def sub_run(m):
    return em("_{" + "".join(SUBMAP[c] for c in m.group(0)) + "}")

md = re.sub("[" + "".join(SUPMAP) + "]+", sup_run, md)
md = re.sub("[" + "".join(SUBMAP) + "]+", sub_run, md)

# merge adjacent \ensuremath: \beta + _{1} -> \beta_1 ; \beta + ^{2} -> \beta^2
md = re.sub(r"\\ensuremath\{\\(\w+)\}\\ensuremath\{_\{(\w+)\}\}", r"\\ensuremath{\g<1>_\g<2>}", md)
md = re.sub(r"\\ensuremath\{\\(\w+)\}\\ensuremath\{\^\{(\w+)\}\}", r"\\ensuremath{\g<1>^\g<2>}", md)
# merge digit-run exponents onto preceding math: 10 \ensuremath{^{-6}} -> 10^{-6}
md = re.sub(r"([0-9A-Za-z])\\ensuremath\{\^\{([^{}]+)\}\}", r"\\ensuremath{\g<1>^\g<2>}", md)
md = re.sub(r"([0-9A-Za-z])\\ensuremath\{_\{([^{}]+)\}\}", r"\\ensuremath{\g<1>_\g<2>}", md)

open(os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md"), "w").write(md)

PREAMBLE = r"""% LaTeX source for "The triple unity of life: closure, code and the topology of living form"
% Target journal style: Journal of Theoretical Biology (Elsevier), single column.
\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{longtable}
\usepackage[margin=2.4cm]{geometry}
\usepackage{setspace}
\usepackage[font=small,labelfont=bf]{caption}
\usepackage{microtype}
\usepackage[hidelinks]{hyperref}
\usepackage{xurl}
\usepackage{etoolbox}
\AtBeginEnvironment{longtable}{\footnotesize}
\usepackage{xcolor}
\setstretch{1.18}
\graphicspath{{../}}
\newcommand{\tightlist}{\setlength{\itemsep}{0pt}\setlength{\parskip}{0pt}}
\begin{document}
"""

HEADER = r"""\begin{center}
{\LARGE\bfseries The triple unity of life: closure, code and the topology of living form}\\[1.2em]
{\large Songbo Zhang}\\[0.4em]
{\small Yueyang Vocational and Technical University, Yueyang, Hunan, China}\\[0.3em]
{\small Correspondence: 8568266@qq.com}\\[0.3em]
{\small Manuscript prepared for the \textit{Journal of Theoretical Biology}, October 2026}
\end{center}
\vspace{0.8em}
"""

r = subprocess.run(["pandoc", "manuscript/triple_unity_v3_full.md", "-f",
                    "markdown+tex_math_dollars+raw_tex", "-t", "latex", "--wrap=none",
                    "-o", "manuscript/_body.tex"],
                   cwd=ROOT, capture_output=True, text=True)
if r.returncode:
    print(r.stderr[:2000]); raise SystemExit(1)
body = open(os.path.join(ROOT, "manuscript", "_body.tex")).read()

with open(OUT, "w") as f:
    f.write(PREAMBLE)
    f.write(HEADER)
    # sloppy typesetting for the References section (long DOIs)
    body = body.replace("\\section{References}", "\\sloppy\n\\section{References}")
    f.write(body)
    f.write("\n\\end{document}\n")
print("wrote", OUT)
