#!/usr/bin/env python3
"""72_make_v4.py — V3 -> V4 master revision script.

Implements review round 4: (1) eps basal-leak phase boundary + criterion split,
(2) dispersal-unlocked invasion, (3) margin-null robustness protocol, plus the
31-item production checklist (section renumbering, cross-refs, references dedup,
Highlights alignment, SOC tone, P10 rewrite, canonical-loop wording, etc).

Reads:  manuscript/triple_unity_v3_full.md
Writes: manuscript/triple_unity_v4_full.md
Numbers are filled from data/v4_analyses.json, data/eps_boundary_v2.json,
data/design_table_v4_eps*.json (design-table sweep).
"""
import json, os, re, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md")
DST = os.path.join(ROOT, "manuscript", "triple_unity_v4_full.md")
md = open(SRC).read()
n_edits = 0

def rep(old, new, count=1):
    global md
    tokens = re.split(r"\s+", old)
    pat = r"\s+".join(re.escape(t) for t in tokens if t)
    n = len(re.findall(pat, md))
    assert n >= 1, f"NOT FOUND: {old[:90]!r}"
    md = re.sub(pat, lambda m: new, md, count=count)

va = json.load(open(os.path.join(ROOT, "data", "v4_analyses.json")))
eb = json.load(open(os.path.join(ROOT, "data", "eps_boundary_v2.json")))

# ---------------------------------------------------------------- numbers
nul = va["margin_nulls"]
n0, n1, n2, n3 = nul["N0"]["mean"], nul["N1"]["mean"], nul["N2"]["mean"], nul["N3"]["mean"]
ci_lo, ci_hi = va["bootstrap_ci"]
selk2, selk5 = va["selection_bound"]["k2"], va["selection_bound"]["k5"]
bf = va["bayes_factor"]; bf_min = min(bf.values()); bf_max = max(bf.values())
fr = {(d["D_i"], d["rho"]): d["v"] for d in va["front_velocity"]}
v10, v15, v40 = fr[(0.02, 1.0)], fr[(0.02, 1.5)], fr[(0.02, 4.0)]
phase = {(p["rho"], p["p_div"]): p["cls"] for p in va["budding_phase"]}
etab = eb["eps_table"]
e35 = dict(etab)[0.35]; e20 = dict(etab)[2.0]

# ======================================================================
# A. STRUCTURE: section renumbering and ordering (evaluator C #1, #2)
# ======================================================================
# promote "Loss of the loop" to a top-level section and fix duplicated title
rep("## 8. Loss of the loop Loss of the loop: fragmentation and \\ensuremath{lambda_2}",
    "# 8. The loss of the loop: fragmentation and \\ensuremath{lambda_2}")
rep("# 8. Predictions, with protocols", "# 9. Predictions, with protocols")
rep("# 10. Evidence discipline", "# 11. Evidence discipline")
rep("# 9. The programme: comparative accounting and next steps",
    "# 10. The programme: comparative accounting and next steps")
rep("## 9.1 Against the neighbours", "## 10.1 Against the neighbours")
rep("## 9.2 The positive heuristic, ranked", "## 10.2 The positive heuristic, ranked")
rep("## 9.3 What would falsify the hard core", "## 10.3 What would falsify the hard core")
rep("# 10. Conclusion", "# 12. Conclusion")
# sub-numbering fix
rep("#### 6.3.3.1 The question, made askable", "### 6.3.1 The question, made askable")
rep("#### 6.3.3.2 What the enumeration found", "### 6.3.2 What the enumeration found")
# reorder: Evidence discipline must come AFTER the programme (9 -> 10)
ev_start = md.index("# 11. Evidence discipline")
ev_end = md.index("# 10. The programme")
ev_block = md[ev_start:ev_end]
md = md[:ev_start] + md[ev_end:]
pr_end = md.index("# 12. Conclusion")
md = md[:pr_end] + ev_block + md[pr_end:]
# drop the trailing empty duplicate References
rep("\n\n# References\n\n\n", "\n", count=1) if md.endswith("# References\n\n\n") else None
if md.rstrip().endswith("# References"):
    md = md.rstrip()[: -len("# References")].rstrip() + "\n"

# ======================================================================
# B. CROSS-REFERENCES (machine-checked remap)
# ======================================================================
rep("corroborated predictions (Sect. 8)", "corroborated predictions (Sect. 9)")
rep("The ranked programme of Sect. 9", "The ranked programme of Sect. 10")
rep("(P7 and P8 in Sect. 8)", "(P7 and P8 in Sect. 9)")
rep("the comparative accounting in Sect. 9, Table 4", "the comparative accounting in Sect. 10, Table 4")
pass  # covered by the longer "Sect. 9, Table 4" replacement above
rep("claim we test directly in Sect. 4.3", "claim we test directly in Sect. 5.5")
rep("ATP flux bounds fidelity (Sect. 3.2); the code's error-minimising\narchitecture bounds the mutational cost of rebuilding structure (Sect. 3.3)",
    "ATP flux bounds fidelity (Sect. 4.2); the code's error-minimising\narchitecture bounds the mutational cost of rebuilding structure (Sect. 4.3)")
rep("thermodynamic window of Sect. 2.2", "thermodynamic window of Sect. 3.2")
rep("replication must beat the error\nthreshold (Sect. 3.4) and the loop must be ignited (Sect. 5.2)",
    "replication must beat the error\nthreshold (Sect. 4.4) and the loop must be ignited (Sect. 6.2)")
rep("ignition curve (Fig. 11d)", "ignition curve (Fig. 12d)")
rep("Topological typing of 19 structures (Figs. 7--8)", "Topological typing of 19 structures (Figs. 10--11)")
rep("Threshold-plus-founder origin dynamics (Fig. 11)", "Threshold-plus-founder origin dynamics (Fig. 12)")

# ======================================================================
# C. HIGHLIGHTS: <=85 chars each, class-level wording, V4 results
# ======================================================================
h_start = md.index("# Highlights")
h_end = md.index("# Abstract")
highlights = """# Highlights

- Monte-Carlo margins put real rotor/gradient pairs at the null's 12.5th percentile, robust to four nulls.
- Exhaustive 9,936-topology design table: self-maintenance is generic; robustness is graded by sign class.
- The all-positive sign class is the most robust (median Q = 63); the canonical loop sits at the class median.
- Genesis and homeostasis are different design problems: knockdown self-repair needs negative feedback.
- Dead state absorbing at zero basal flux: founders required below a smooth critical-leak line eps_c(rho).
- Without dispersal live patches are pinned; vesicle-like dispersal unlocks invasion above a critical coupling.

"""
md = md[:h_start] + highlights + md[h_end:]

# ======================================================================
# D. ABSTRACT: align three-layer wording + add V4 results
# ======================================================================
rep("Self-maintenance is generic (9,915 topologies qualify) but robustness is\ngraded by sign structure: all-positive cycles are the most robust designs (median Q = 63 versus 18\nfor two-negative cycles), the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits mid-field (Q = 30, basin fraction\n0.45), and knockdown self-repair is a rare, separate capacity",
    "Self-maintenance is generic (9,915 topologies qualify) but robustness is\ngraded by sign structure: the all-positive class is the most robust (median Q = 63 versus 18\nfor two-negative cycles), the canonical C1\\ensuremath{\\wedge}C2\\ensuremath{\\wedge}C3 loop sits at its class median (Q = 30, basin fraction\n0.45), and knockdown self-repair is a rare, separate capacity")
rep("live patches are pinned by\ndiffusive dilution, and power-law avalanches of the kind self-organised criticality would predict\nare absent.",
    "live patches are pinned by\ndiffusive dilution when only the gradient diffuses — a structural, not parametric, pinning —\nwhile compartment dispersal (vesicle-like division) unlocks invasion above a critical coupling;\npower-law avalanches of the kind self-organised criticality would predict are absent. A basal-leak\nextension unifies the two origin statements: below a smooth critical-leak line eps_c(rho) the dead\nstate stays absorbing and genesis needs a founder event; above it, ignition is spontaneous.")
rep("at a mean 12.5th percentile of a neutral null (median |margin| 4.5 versus 25.3 kJ mo\\ensuremath{l^-1}), so",
    "at a mean 12.5th percentile of a neutral null (median |margin| 4.5 versus 25.3 kJ mo\\ensuremath{l^-1}; the\nfinding is robust across four null models, mean percentiles 12.5--19.0), so")
rep("ten predictions, pre-registered\nprotocols for the three that matter most",
    "ten predictions, pre-registered\nand frozen protocols for the ones that matter most")

# ======================================================================
# E. KEYWORDS (evaluator C #11)
# ======================================================================
rep("**Keywords:** chemiosmosis; ATP synthase; genetic code; error threshold; persistent homology;\ndesign table; autopoiesis; self-organised criticality; origin of life",
    "**Keywords:** chemiosmosis; ATP synthase; genetic code; error threshold; persistent homology;\ndesign table; autopoiesis; self-organised criticality; origin of life; protocell; research programme\n\n**Classification:** Systems Biology; Biophysics")

# ======================================================================
# F. AUTHOR DECLARATIONS (evaluator C #10)
# ======================================================================
rep("The maintainers of the PDB, UniProt, KEGG and CrossRef open archives made a framework of this kind\ntestable; the referees of an earlier version made it honest.",
    "The maintainers of the PDB, UniProt, KEGG and CrossRef open archives made a framework of this kind\ntestable; the referees of an earlier version made it honest.\n\n**Author contributions (CRediT).** S. Zhang: conceptualisation, methodology, software, formal\nanalysis, investigation, data curation, writing — original draft, writing — review and editing.\n\n**Declaration of interests.** The author declares no competing interests.\n\n**Funding.** This work received no external funding.")

# ======================================================================
# G. SOC TONE (evaluator A #3 / plan text-fix 2) + Hinrichsen ref
# ======================================================================
rep("Self-organised criticality is not merely unsupported here — with an absorbing dead state it cannot be the right\ndescription of genesis, because criticality requires a system that stays near a critical point,\nwhereas the dead state is a point, and a stable one.",
    "Self-organised criticality is not merely unsupported here — it cannot describe *this model\nclass*: with an absorbing dead state, zero ignitions from sub-threshold pulses is close to a\ndefinitional result, not an independent verdict. The honest statement is narrower and stronger at\nthe same time: the framework predicts a characteristic threshold where SOC predicts scale-free\navalanches, and the discriminating observable is the sub-threshold fluctuation size distribution\n(exponential truncation versus power law), which is what P6b registers. Absorbing states are, of\ncourse, the heart of the modern SOC literature — absorbing-state phase transitions and directed\npercolation [62] — and a driven version of this model (basal leak above the critical line of\nSect. 6.2, or stochastic re-seeding) sits precisely in that universality question; the framework's\nclaim is about genesis from the clean dead state, not about driven absorbing-state systems\nin general.")

# reference renumbering: insert Hinrichsen as [62], bump old 62-64 -> 63-65
rep("percolation-like transitions have been measured in\nmitochondrial networks [62--63]",
    "percolation-like transitions have been measured in\nmitochondrial networks [63--64]")
rep("the algebraic connectivity \\ensuremath{lambda_2} [64]", "the algebraic connectivity \\ensuremath{lambda_2} [65]")
rep("64. Fiedler M. (1973). Algebraic connectivity of graphs.",
    "62. Hinrichsen H. (2000). Non-equilibrium critical phenomena and phase transitions into absorbing\n    states. Advances in Physics 49, 815-958. https://doi.org/10.1080/00018730050198152\n\n63. (was 62) PLACEHOLDER-A\n\n64. (was 63) PLACEHOLDER-B\n\n65. Fiedler M. (1973). Algebraic connectivity of graphs.")

# restore the bumped reference texts into placeholders (from the V3 file's own list)
oldmd = open(os.path.join(ROOT, "manuscript", "triple_unity_v3_full.md")).read()
oref = oldmd[oldmd.index("# References"):]
o62 = re.search(r"\n62\.\s(.*?)(?=\n\n63\.)", oref, re.S).group(1)
o63 = re.search(r"\n63\.\s(.*?)(?=\n\n64\.)", oref, re.S).group(1)
md = md.replace("63. (was 62) PLACEHOLDER-A", "63. " + o62.strip())
md = md.replace("64. (was 63) PLACEHOLDER-B", "64. " + o63.strip())

print(f"part 1 done: {n_edits} edits")
open(os.path.join(ROOT, "manuscript", "triple_unity_v4_full.md"), "w").write(md)
