#!/usr/bin/env python3
"""50_m1_margin.py — Reviewer-C M1: thermodynamic margin statistics for c-rings.

Replaces the binary "every system satisfies its own floor" claim with:
 (1) Monte-Carlo margin M = n_H F dp - dG, with dG_ATP ~ U(50,65) (cytosolic) or
     U(46,58) (mitochondrial matrix scenario), dp ~ N(mu, sd) truncated;
 (2) a zero model: c ~ U(4,20), dp ~ U(150,250) mV — are real (c, dp) pairs
     systematically closer to the floor than random rotor/gradient pairs?
Output: data/processed/margin_statistics.json
"""
import os, json
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "processed")
F = 96.485  # kJ/(V mol)

rng = np.random.default_rng(42)
N = 200_000

SYSTEMS = [
    # name, dp_mean mV (None = not measured), dp_sd, c-ring (None = unknown), mito?
    ("Halobacterium salinarum", 230, 25, None, False),
    ("Bacillus subtilis",        220, 20, 10,  False),
    ("Cardiac mitochondrion",    200, 15, 8,   True),
    ("Liver mitochondrion",      190, 15, 8,   True),
    ("Escherichia coli",         180, 15, 10,  False),
    ("Yeast mitochondrion",      180, 15, 10,  True),
    ("Streptococcus lactis",     170, 15, None, False),
    ("Thylakoid (spinach)",      160, 15, 14,  False),
    ("Spirulina platensis",      None, None, 15, False),
    ("Thermoalkaliphilic ATP synthase", None, None, 13, False),
]

def margin_samples(dp, c, dG_lo, dG_hi):
    dG = rng.uniform(dG_lo, dG_hi, N)
    if c is not None:
        nH = np.full(N, c / 3.0)
    else:
        nH = None
    dpV = np.clip(rng.normal(dp[0]/1000.0, dp[1]/1000.0, N), 0.12, 0.28) if dp is not None else None
    return dG, nH, dpV

results = []
for name, mu, sd, c, is_mito in SYSTEMS:
    if c is None or mu is None:
        continue
    # scenario: mitochondrial systems may run lower dG_ATP (matrix values)
    dG_lo, dG_hi = (46.0, 58.0) if is_mito else (50.0, 65.0)
    dG, nH_fix, dpV = margin_samples((mu, sd), c, dG_lo, dG_hi)
    nH = nH_fix if c is not None else rng.uniform(4/3, 20/3, N)  # unknown-c systems: skip MC on c
    if c is None:
        continue
    M = nH * F * dpV - dG
    p_pos = float((M > 0).mean())
    results.append(dict(system=name, c=c, dp_mean=mu, dp_sd=sd, mito=is_mito,
                        dG_range=[dG_lo, dG_hi],
                        margin_median_kJ=float(np.median(M)),
                        margin_ci90=[float(np.percentile(M, 5)), float(np.percentile(M, 95))],
                        P_margin_pos=p_pos))
    print(f"{name:34s} c={c:2d} dp={mu} mV  P(M>0)={p_pos:5.3f}  median M={np.median(M):+7.1f} kJ/mol")

# ---- zero model: c ~ U(4,20), dp ~ U(150,250) mV; same dG scenarios mixed 50-65
NZ = 1_000_000
c_null = rng.uniform(4, 20, NZ)
dp_null = rng.uniform(0.150, 0.250, NZ)
dG_null = rng.uniform(50, 65, NZ)
M_null = (c_null / 3.0) * F * dp_null - dG_null
absM_null = np.abs(M_null)

# real systems' |median M| vs null distribution
real_absM = []
for r in results:
    # use median |M| per system
    real_absM.append(abs(r["margin_median_kJ"]))
real_absM = np.array(real_absM)
pct = [float((absM_null < a).mean() * 100) for a in real_absM]
print("\nreal |median margin| vs null (percentile within null):")
for (name, mu, sd, c, _), a, p in zip([s for s in SYSTEMS if s[2] and s[3]], real_absM, pct):
    print(f"  {name:34s} |M|={a:6.1f} kJ  -> {p:5.1f}th percentile of null")
med_null_abs = float(np.median(absM_null))
print(f"null median |M| = {med_null_abs:.1f} kJ/mol; real systems median |M| = {np.median(real_absM):.1f}")

# tightness test: are real |M| smaller than null?  Mann-Whitney U via percentile mean
mean_pct = float(np.mean(pct))
print(f"mean percentile of real |M| within null = {mean_pct:.1f}% (50% = indistinguishable, <50% = tighter)")

json.dump(dict(systems=results,
               zero_model=dict(n=NZ, c_range=[4, 20], dp_range_mV=[150, 250],
                               absM_median=med_null_abs,
                               absM_p90=[float(np.percentile(absM_null, 90))],
                               real_percentiles=dict(zip([r["system"] for r in results], pct)),
                               real_mean_percentile=mean_pct)),
          open(os.path.join(OUT, "margin_statistics.json"), "w"), indent=1)
print("saved margin_statistics.json")
