#!/usr/bin/env python3
"""53_soc_avalanche.py — Reviewer-C M6: founder events vs self-organised criticality.

Stochastic spatial version of the C1-C3 loop on a 2-D lattice:
  each site carries (m, e, i) evolving under the V2 ODE with e diffusing to neighbours;
  random sub-threshold gradient pulses (delta < ignition threshold) seed "avalanches":
  the number of sites crossing into the live state within a relaxation window.
SOC (BTW 1987) predicts power-law avalanches without a characteristic scale;
  the saddle-node + founder picture predicts exponentially truncated distributions
  with a characteristic scale set by delta and the distance to the threshold.
Output: data/processed/soc_avalanche.json
"""
import os, json
import numpy as np
from scipy import stats

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUTP = os.path.join(OUT, "data", "processed")

# V2 loop parameters (base, from origin_dynamics)
BASE = dict(rho=1.0, ell=0.35, gam=0.6, a=2.0, delta=0.5, b=1.5, w=0.15)

def rhs(m, e, i, p, e_nb):
    de = p["rho"] * m * (1 - e) - p["ell"] * e - p["gam"] * e * i + p.get("D", 0.0) * (e_nb - e)
    di = p["a"] * e * i * (1 - i) - p["delta"] * i
    dm = p["b"] * i * (1 - m) - p["w"] * m
    return dm, de, di

def simulate(L=48, rho=0.95, delta=0.15, n_pulses=3000, dt=0.05, tau=400, D=0.08, seed=0):
    rng = np.random.default_rng(seed)
    p = dict(BASE, rho=rho, D=D)
    m = np.zeros((L, L)); e = np.zeros((L, L)); i = np.zeros((L, L))
    live = np.zeros((L, L), bool)
    sizes = []
    for pulse in range(n_pulses):
        # seed a sub-threshold gradient pulse at a random site
        x0, y0 = rng.integers(L), rng.integers(L)
        e[x0, y0] = min(1.0, e[x0, y0] + delta)
        pre_alive = live.copy()
        size = 0
        for t in range(tau):
            e_nb = (np.roll(e, 1, 0) + np.roll(e, -1, 0) + np.roll(e, 1, 1) + np.roll(e, -1, 1)) / 4.0
            dm, de, di = rhs(m, e, i, p, e_nb)
            m = np.clip(m + dt * dm, 0, 1); e = np.clip(e + dt * de, 0, 1); i = np.clip(i + dt * di, 0, 1)
            live = i > 0.5
            size = int((live & ~pre_alive).sum())
        # count newly live sites during this pulse window (relative to before pulse)
        newly = int((live & ~pre_alive).sum())
        sizes.append(newly)
        # reset: dead sites decay back (they will, since i decays when e collapses)
        # let system relax fully before next pulse
        for t in range(600):
            e_nb = (np.roll(e, 1, 0) + np.roll(e, -1, 0) + np.roll(e, 1, 1) + np.roll(e, -1, 1)) / 4.0
            dm, de, di = rhs(m, e, i, p, e_nb)
            m = np.clip(m + dt * dm, 0, 1); e = np.clip(e + dt * de, 0, 1); i = np.clip(i + dt * di, 0, 1)
    return np.array(sizes)

def classify(sizes):
    s = sizes[sizes > 0]
    if len(s) < 20:
        return dict(n_positive=int(len(s)), verdict="insufficient", mean=float(sizes.mean()))
    # fit truncated power law vs exponential on s>=1
    s_pos = s.astype(float)
    alpha, loc, scale = stats.expon.fit(s_pos, floc=0)
    ll_exp = np.sum(stats.expon.logpdf(s_pos, loc=0, scale=scale))
    # power law: fit alpha on s>=smin (Clauset): use smin = 1 here, MLE
    smin = 1.0
    s_pl = s_pos[s_pos >= smin]
    n = len(s_pl)
    if np.min(s_pl) == np.max(s_pl):
        alpha_pl = np.nan
    else:
        alpha_pl = 1 + n / np.sum(np.log(s_pl / (np.min(s_pl))))
    ll_pl = np.sum(np.log((alpha_pl - 1) * smin ** (alpha_pl - 1) * s_pl ** (-alpha_pl)))
    # AIC comparison (same data, 2 params each)
    aic_exp = 2 - 2 * ll_exp
    aic_pl = 2 - 2 * ll_pl
    verdict = "power-law" if aic_pl < aic_exp - 10 else ("exponential" if aic_exp < aic_pl - 10 else "ambiguous")
    return dict(n_pulses=int(len(sizes)), n_positive=int(len(s)), mean=float(sizes.mean()),
                max=int(sizes.max()), expon_scale=float(scale), alpha_pl=float(alpha_pl),
                AIC_exp=float(aic_exp), AIC_pl=float(aic_pl), verdict=verdict)

res = {}
for rho, tag in [(0.95, "sub_threshold"), (0.99, "near_threshold"), (0.999, "at_threshold")]:
    sizes = simulate(rho=rho, delta=0.15, n_pulses=1500, seed=int(rho * 1000))
    r = classify(sizes); r["rho"] = rho; r["delta"] = 0.15
    res[tag] = r
    print(tag, json.dumps(r))
# different pulse sizes at near-threshold coupling
for delta in (0.05, 0.10, 0.25, 0.40):
    sizes = simulate(rho=0.99, delta=delta, n_pulses=1200, seed=int(delta * 10000))
    r = classify(sizes); r["rho"] = 0.99; r["delta"] = delta
    res[f"delta_{delta}"] = r
    print(f"delta={delta}", json.dumps(r))

json.dump(res, open(os.path.join(OUTP, "soc_avalanche.json"), "w"), indent=1)
print("saved soc_avalanche.json")
