#!/usr/bin/env python3
"""70_v4_fast.py — V4 fast analyses (review round 4: three critical flaws).

P1a  epsilon_c(rho) phase boundary of the minimal ODE with basal leak eps:
       dm = rho*e*i*(1-m) - dm*m + eps
       de = a*m*(1-e) - l*e - b*i*e + eps
       di = c*e*i*(1-i) - di*i + eps
     eps=0 -> exactly absorbing dead state (V3 §6.2); eps>0 -> basal-flux regime
     (V3 §6.3 MM engine).  eps_c = smallest eps at which the low state ignites.
P2a  1-D front velocity, D_e=0.05, D_i in {0, 0.02}: pinning is structural (D_i=0
     pins at every rho), dispersal unlocks invasion above rho_inv.
P2b  2-D budding phase diagram on the V3 founder lattice: budding rule deposits
     diluted child seed (eta=0.4) when Phi = m*e*i > theta; (rho, p_div) plane ->
     extinct / pinned / invading.
P3   margin null sensitivity N0-N3 + bootstrap CI + selection-effect bound +
     Bayes-factor contrast (independent-null vs floor-seeking).
FS   lambda2 finite-size (28x20 / 56x40 / 112x80) and quasispecies sigma/L checks.
Output: data/v4_analyses.json
"""
import os, json
import numpy as np
from scipy.integrate import solve_ivp

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
rng = np.random.default_rng(7)

# ---------------- P1a: eps_c(rho) ----------------
A, L_, B, C, DM, DI = 2.0, 0.15, 0.5, 2.0, 0.5, 0.5

def rhs_eps(t, y, rho, eps):
    m, e, i = y
    return [rho*e*i*(1-m) - DM*m + eps,
            A*m*(1-e) - L_*e - B*i*e + eps,
            C*e*i*(1-i) - DI*i + eps]

def ignites(rho, eps, T=600.0):
    y0 = [1.2*eps/DM, 1.2*eps/L_, 1.2*eps/DI]
    sol = solve_ivp(rhs_eps, (0, T), y0, args=(rho, eps),
                    rtol=1e-8, atol=1e-10, dense_output=False, max_step=1.0)
    return float(sol.y[2, -1]) > 0.5

def eps_c(rho):
    lo, hi = 1e-7, 0.2
    if ignites(rho, lo):
        return 0.0
    if not ignites(rho, hi):
        return float('nan')
    for _ in range(42):
        mid = np.sqrt(lo*hi)
        if ignites(rho, mid):
            hi = mid
        else:
            lo = mid
        if hi/lo < 1.02:
            break
    return float(np.sqrt(lo*hi))

print("== P1a: eps_c(rho) boundary ==", flush=True)
rho_grid = [round(x, 3) for x in np.concatenate([
    np.array([0.35, 0.60, 1.00, 1.60]),
    np.linspace(0.2, 2.0, 19)])]
rho_grid = sorted(set(rho_grid))
eps_table = []
for r in rho_grid:
    ec = eps_c(r)
    eps_table.append((r, ec))
    print(f"  rho={r:5.2f}  eps_c={ec:.3e}", flush=True)

# ---------------- P2a: 1-D front velocity ----------------
print("== P2a: 1-D front velocity ==", flush=True)

def high_state(rho):
    sol = solve_ivp(rhs_eps, (0, 400), [0.5, 0.5, 0.5], args=(rho, 0.0),
                    rtol=1e-9, atol=1e-11, max_step=1.0)
    return sol.y[:, -1]

def front_speed(rho, D_i, NX=600, D_e=0.05, T=400.0, dt=0.02, rec=(200, 400)):
    ss = high_state(rho)
    m = np.zeros(NX); e = np.zeros(NX); i = np.zeros(NX)
    x0 = NX // 3
    m[:x0] = ss[0]; e[:x0] = ss[1]; i[:x0] = ss[2]
    nst = int(T/dt)
    positions = []
    r2e, r2i = D_e/dt/dt, (D_i/dt/dt if D_i > 0 else 0.0)
    # explicit FD with dt=0.02, dx=1: D/dx^2*dt = 0.05*0.02 = 1e-3 stable
    for s in range(nst):
        e_nb = (np.roll(e,1)+np.roll(e,-1))/2.0
        i_nb = (np.roll(i,1)+np.roll(i,-1))/2.0
        dm = rho*e*i*(1-m) - DM*m
        de = A*m*(1-e) - L_*e - B*i*e + D_e*(e_nb-e)
        di = C*e*i*(1-i) - DI*i + (D_i*(i_nb-i) if D_i > 0 else 0.0)
        m = np.clip(m + dt*dm, 0, 1); e = np.clip(e + dt*de, 0, 1); i = np.clip(i + dt*di, 0, 1)
        t = s*dt
        if t >= rec[0] and abs(t - round(t/5)*5) < dt/2:
            idx = np.where(i > 0.5)[0]
            positions.append((t, float(idx[-1]) if len(idx) else 0.0))
    if len(positions) < 2:
        return 0.0
    (t1, x1), (t2, x2) = positions[0], positions[-1]
    return (x2 - x1) / (t2 - t1)

front = []
for Di in (0.0, 0.02):
    for r in (0.6, 1.0, 1.5, 4.0):
        v = front_speed(r, Di)
        front.append(dict(D_i=Di, rho=r, v=v))
        print(f"  D_i={Di:.3f} rho={r:4.1f}  v={v:+.4f}", flush=True)

# ---------------- P2b: 2-D budding phase diagram ----------------
print("== P2b: 2-D budding (rho, p_div) ==", flush=True)
BASE2 = dict(ell=0.35, gam=0.6, a=2.0, delta=0.5, b=1.5, w=0.15)

def run_budding(rho, p_div, s0=0.5, patch_r=5, D=0.05, T=100.0, dt=0.1, L=40,
                theta=0.2, eta=0.4):
    m = np.zeros((L, L)); e = np.zeros((L, L)); i = np.zeros((L, L))
    yy, xx = np.mgrid[0:L, 0:L]
    patch = (xx - L//2)**2 + (yy - L//2)**2 <= patch_r**2
    m[patch] = s0; e[patch] = s0; i[patch] = s0
    founder_area = float(patch.sum()) / (L*L)
    nst = int(T/dt)
    live_series = []
    for s in range(nst):
        e_nb = (np.roll(e,1,0)+np.roll(e,-1,0)+np.roll(e,1,1)+np.roll(e,-1,1))/4.0
        dm = BASE2["b"]*i*(1-m) - BASE2["w"]*m
        de = rho*m*(1-e) - BASE2["ell"]*e - BASE2["gam"]*e*i + D*(e_nb-e)
        di = BASE2["a"]*e*i*(1-i) - BASE2["delta"]*i
        m = np.clip(m+dt*dm,0,1); e = np.clip(e+dt*de,0,1); i = np.clip(i+dt*di,0,1)
        if p_div > 0:
            phi = m*e*i
            mask = (phi > theta) & (rng.random((L, L)) < p_div*dt)
            if mask.any():
                d = rng.integers(0, 4, size=(L, L))
                empty = i < 0.05
                # d codes: 0=up,1=down,2=left,3=right
                offs = [(-1,0),(1,0),(0,-1),(0,1)]
                for code, (dr, dc) in enumerate(offs):
                    selm = mask & (d == code)
                    if not selm.any():
                        continue
                    don_m = np.roll(np.where(selm, m, 0.0), (-dr, -dc), axis=(0,1))
                    don_e = np.roll(np.where(selm, e, 0.0), (-dr, -dc), axis=(0,1))
                    don_i = np.roll(np.where(selm, i, 0.0), (-dr, -dc), axis=(0,1))
                    tgt = empty & (don_i > 0)
                    m[tgt] = np.maximum(m[tgt], eta*don_m[tgt])
                    e[tgt] = np.maximum(e[tgt], eta*don_e[tgt])
                    i[tgt] = np.maximum(i[tgt], eta*don_i[tgt])
        if s % 50 == 0:
            live_series.append(float(((i > 0.5) & (e > 0.3)).mean()))
    live = float(((i > 0.5) & (e > 0.3)).mean())
    if live < 0.02 * founder_area or live < 0.001:
        cls = "extinct"
    elif live < 1.6 * founder_area:
        cls = "pinned"
    else:
        cls = "invading"
    return live, founder_area, cls, live_series

phase = []
for r in (0.6, 0.9, 1.2, 1.5, 2.0):
    for pd in (0.0, 0.005, 0.01, 0.02, 0.05, 0.1):
        live, fa, cls, ser = run_budding(r, pd)
        phase.append(dict(rho=r, p_div=pd, live=round(live, 4),
                          founder=round(fa, 4), cls=cls))
        print(f"  rho={r:4.1f} p_div={pd:5.3f} -> {cls:9s} live={live:.3f} founder={fa:.3f}", flush=True)

# ---------------- P3: margin nulls ----------------
print("== P3: margin null sensitivity ==", flush=True)
F = 96.485
ms = json.load(open(os.path.join(OUT, "margin_statistics.json")))
real = ms["systems"]                     # 6 systems with medians
obs = np.array([abs(s["margin_median_kJ"]) for s in real])
names = [s["system"] for s in real]
is_mito = np.array([s["mito"] for s in real])
N = 2_000_000

def draw_null(kind, n=N):
    if kind == "N0":
        c = rng.uniform(4, 20, n); dp = rng.uniform(150, 250, n)/1000.0
        dG = rng.uniform(50, 65, n)
    elif kind == "N1":
        c = rng.choice([8, 10, 11, 13, 14, 15], n).astype(float)
        dp = rng.uniform(150, 250, n)/1000.0
        dG = rng.uniform(50, 65, n)
    elif kind == "N2":
        c = rng.uniform(4, 20, n)
        dp = np.power(10.0, rng.uniform(2.18, 2.40, n))/1000.0
        dG = rng.uniform(50, 65, n)
    nH = c/3.0
    return nH*F*dp - dG

CLADE_C = {"mito": [8.0, 10.0], "bact": [10.0, 11.0, 15.0], "chloro": [13.0, 14.0, 15.0]}
CLADE_OF = {0: "bact", 1: "mito", 2: "mito", 3: "bact", 4: "mito", 5: "chloro"}

def percentiles(kind):
    if kind == "N3":
        pcts = []
        for k, name in enumerate(names):
            cl = CLADE_OF[k]
            null_cl = np.abs(draw_null_kind3(cl))
            pcts.append(float((null_cl < obs[k]).mean()*100))
        return pcts
    Ms = draw_null(kind)
    absM = np.abs(Ms)
    return [float((absM < o).mean()*100) for o in obs]

_cache3 = {}
def draw_null_kind3(cl):
    if cl not in _cache3:
        c = rng.choice(CLADE_C[cl], N).astype(float)
        dp = rng.uniform(150, 250, N)/1000.0
        dG = np.where(np.isin(c, [8.0, 10.0]) & (CLADE_C[cl] == [8.0, 10.0]),
                      rng.uniform(46, 58, N), rng.uniform(50, 65, N))
        # mito clade uses matrix dG band; others cytosolic
        if cl == "mito":
            dG = rng.uniform(46, 58, N)
        else:
            dG = rng.uniform(50, 65, N)
        _cache3[cl] = c/3.0*F*dp - dG
    return _cache3[cl]

null_out = {}
for kind in ("N0", "N1", "N2", "N3"):
    pcts = percentiles(kind)
    null_out[kind] = dict(per_system=dict(zip(names, [round(p, 2) for p in pcts])),
                          mean=round(float(np.mean(pcts)), 2))
    print(f"  {kind}: mean percentile {np.mean(pcts):.2f}  ({[round(p,1) for p in pcts]})", flush=True)

# bootstrap CI of the mean percentile under N0
p0 = np.array([null_out["N0"]["per_system"][n] for n in names])
bs = [float(np.mean(rng.choice(p0, 6, replace=True))) for _ in range(10_000)]
ci = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
print(f"  bootstrap 95% CI of mean percentile: [{ci[0]:.1f}, {ci[1]:.1f}]", flush=True)

# selection-effect worst-case bound: k=2 systems with c but no dp measured, placed at null median
k = 2
bound = (6*np.mean(p0) + k*50) / (6 + k)
bound5 = (6*np.mean(p0) + 5*50) / (6 + 5)
print(f"  worst-case mean percentile with {k} missing systems at null median: {bound:.1f} (k=5: {bound5:.1f})", flush=True)

# Bayes factor: independent null vs floor-seeking, on the 6 observed |M| medians
from scipy import stats
absM0 = np.abs(draw_null("N0"))
kde_x = np.linspace(0, 120, 4001)
hist, edges = np.histogram(absM0, bins=kde_x, density=True)
centers = 0.5*(edges[:-1] + edges[1:])
def lik_indep(x):
    return np.interp(x, centers, hist)
bf = {}
for theta in (2.0, 3.0, 5.0):
    lik_floor = stats.gamma.pdf(np.maximum(obs, 1e-6), a=2.0, scale=theta)
    lf = float(np.sum(np.log(lik_floor)))
    li = float(np.sum(np.log(np.maximum(lik_indep(obs), 1e-12))))
    bf[f"theta={theta}"] = round(10**((lf - li)/np.log(10) / np.log(10)), 1) if False else round(float(np.exp((lf-li))), 1)
    print(f"  BF(floor vs N0) theta={theta}: {np.exp(lf-li):.3g}", flush=True)

# ---------------- FS: lambda2 finite size ----------------
print("== FS: lambda2 finite size ==", flush=True)
import networkx as nx
lam_fs = []
for (L1, L2) in ((28, 20), (56, 40), (112, 80)):
    nseed = 20 if L1 <= 56 else 8
    res = []
    for p in np.linspace(0.0, 0.60, 16):
        l2s = []
        for s in range(nseed):
            G = nx.grid_2d_graph(L1, L2)
            keep = [ed for ed in G.edges() if rng.random() > p]
            G2 = nx.Graph(); G2.add_nodes_from(G.nodes()); G2.add_edges_from(keep)
            l2s.append(nx.algebraic_connectivity(G2) if nx.is_connected(G2) else 0.0)
        res.append((float(p), float(np.mean(l2s))))
    l20 = res[0][1]
    lam_fs.append(dict(grid=[L1, L2],
                       curve=[(round(p, 3), round(v/l20, 4)) for p, v in res]))
    print(f"  grid {L1}x{L2}: lambda2/lambda2(0) at p=0.2,0.4: "
          f"{[r for p, r in res if abs(p-0.2)<1e-9 or abs(p-0.4)<1e-9]}", flush=True)

# ---------------- FS: quasispecies sigma / L ----------------
print("== FS: quasispecies sensitivity ==", flush=True)

def wf_oneway(L=50, sigma=5.0, mu=1e-2, pop=3000, gens=1000, seed=0, burn=300):
    r = np.random.default_rng(seed)
    genomes = np.zeros((pop, L), dtype=np.int8)
    acc = 0.0; cnt = 0
    for t in range(gens):
        flip = (r.random((pop, L)) < mu) & (genomes == 0)
        mutated = genomes | flip.astype(np.int8)
        fit = np.where(mutated.sum(1) == 0, sigma, 1.0)
        idx = r.choice(pop, size=pop, p=fit/fit.sum())
        genomes = mutated[idx]
        if t >= gens - burn:
            acc += (genomes.sum(1) == 0).mean(); cnt += 1
    return acc/cnt

qs = []
for sig in (2.0, 3.0, 5.0, 8.0):
    Uc_an = 1 - 1/sig
    # find simulated threshold: largest mu with master retained (>0.5)
    mus = np.linspace(0.0005, 0.08, 12)
    thr = None
    for mu in mus:
        U = 1 - (1-mu)**50
        x = float(np.mean([wf_oneway(sigma=sig, mu=mu, seed=s) for s in range(2)]))
        if x < 0.5 and thr is None:
            thr = U
    qs.append(dict(sigma=sig, Uc_analytic=round(Uc_an, 4),
                   Uc_sim_first_collapse=(round(thr, 4) if thr else None)))
    print(f"  sigma={sig}: U_c analytic {Uc_an:.3f}, sim first collapse at U={thr}", flush=True)
x50 = float(np.mean([wf_oneway(L=50, mu=2e-3, seed=s) for s in range(2)]))
x100 = float(np.mean([wf_oneway(L=100, mu=2e-3, seed=s) for s in range(2)]))
print(f"  L finite-size at mu=2e-3 (U=0.096): x(L=50)={x50:.3f} x(L=100)={x100:.3f}", flush=True)

json.dump(dict(
    eps_boundary=dict(table=[[r, e] for r, e in eps_table],
                      params=dict(a=A, ell=L_, b=B, c=C, delta_m=DM, delta_i=DI)),
    front_velocity=front,
    budding_phase=phase,
    margin_nulls=null_out,
    bootstrap_ci=ci,
    selection_bound=dict(k2=round(bound, 1), k5=round(bound5, 1)),
    bayes_factor=bf,
    lambda2_finitesize=lam_fs,
    quasispecies_sensitivity=dict(sigma_table=qs, L_check=dict(x_L50=x50, x_L100=x100)),
), open(os.path.join(OUT, "v4_analyses.json"), "w"), indent=1)
print("saved data/v4_analyses.json")
