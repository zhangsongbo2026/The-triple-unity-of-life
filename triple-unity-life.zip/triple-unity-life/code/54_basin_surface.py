#!/usr/bin/env python3
"""54_basin_surface.py — Reviewer-C M2.1: global basin volume B(rho, ell) of the
C1-C3 loop ODE, over a grid of initial conditions (vectorised RK4)."""
import os, json
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "processed")
BASE = dict(rho=1.0, ell=0.35, gam=0.6, a=2.0, delta=0.5, b=1.5, w=0.15)

def rhs(m, e, i, p):
    dm = p["b"] * i * (1 - m) - p["w"] * m
    de = p["rho"] * m * (1 - e) - p["ell"] * e - p["gam"] * e * i
    di = p["a"] * e * i * (1 - i) - p["delta"] * i
    return dm, de, di

def basin_volume(rho, ell, ic_grid, dt=0.1, T=300):
    p = dict(BASE, rho=rho, ell=ell)
    m, e, i = ic_grid.copy()
    nsteps = int(T / dt)
    for s in range(nsteps):
        dm, de, di = rhs(m, e, i, p)
        k1m, k1e, k1i = dm, de, di
        dm, de, di = rhs(m + dt/2*k1m, e + dt/2*k1e, i + dt/2*k1i, p)
        k2m, k2e, k2i = dm, de, di
        dm, de, di = rhs(m + dt/2*k2m, e + dt/2*k2e, i + dt/2*k2i, p)
        k3m, k3e, k3i = dm, de, di
        dm, de, di = rhs(m + dt*k3m, e + dt*k3e, i + dt*k3i, p)
        m = np.clip(m + dt/6*(k1m + 2*k2m + 2*k3m + dm), 0, 1)
        e = np.clip(e + dt/6*(k1e + 2*k2e + 2*k3e + de), 0, 1)
        i = np.clip(i + dt/6*(k1i + 2*k2i + 2*k3i + di), 0, 1)
    live = (e > 0.05) & (i > 0.05) & (m > 0.05)
    return float(live.mean())

def main():
    n = 12
    ax = np.linspace(0.04, 0.96, n)
    M, E, I = np.meshgrid(ax, ax, ax, indexing="ij")
    ic_grid = np.stack([M.ravel(), E.ravel(), I.ravel()])
    rhos = np.linspace(0.15, 1.2, 22)
    ells = np.linspace(0.05, 1.0, 16)
    B = np.zeros((len(ells), len(rhos)))
    for a, el in enumerate(ells):
        for b, r in enumerate(rhos):
            B[a, b] = basin_volume(r, el, ic_grid)
        print(f"ell={el:.2f} row done: {B[a].round(2)}", flush=True)
    json.dump(dict(rhos=rhos.tolist(), ells=ells.tolist(), B=B.tolist(),
                   n_ic=int(ic_grid.shape[1])),
              open(os.path.join(OUT, "basin_surface.json"), "w"), indent=1)
    print("saved basin_surface.json")

if __name__ == "__main__":
    main()
