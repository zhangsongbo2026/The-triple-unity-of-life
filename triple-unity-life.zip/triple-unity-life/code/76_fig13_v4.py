#!/usr/bin/env python3
"""76_fig13_v4.py — regenerate fig13 (design table) from the corrected V4 engine
(eps=0 npz), same style as 55_figures_new.py."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIG = os.path.join(ROOT, "figures")
OI = {"orange": "#E69F00", "sky": "#56B4E9", "green": "#009E73", "yellow": "#F0E442",
      "blue": "#0072B2", "verm": "#D55E00", "purple": "#CC79A7", "black": "#000000",
      "grey": "#7F7F7F"}
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["DejaVu Sans"],
    "font.size": 8, "axes.labelsize": 8.5, "axes.titlesize": 9,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7.5,
    "axes.linewidth": 0.7, "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "savefig.bbox": "tight", "axes.unicode_minus": False})
S = 190/25.4

dt = json.load(open(os.path.join(ROOT, "data", "design_table_v3.json")))
z = np.load(os.path.join(ROOT, "data", "design_table_v4_eps0p0_base.npz"))
Q, Qp, spont, basin = z["Q"], z["Qp"], z["spont"], z["basin"]

fig, axes = plt.subplots(1, 2, figsize=(S, S*0.40))
ax = axes[0]
cls = dt["classes"]; ks = list(cls)
xs = np.arange(len(ks))
ax.bar(xs, [c["count"] for c in cls.values()],
       color=[OI["green"], OI["sky"], OI["orange"]][:len(ks)])
ax.set_yscale("log")
ax.set_xticks(xs); ax.set_xticklabels([k.replace(" ", "\n") for k in ks], fontsize=6.0)
ax.set_ylabel("number of functional topologies")
ax.set_title(f"a  self-maintaining designs (of {dt['n_topo']})", fontsize=8.5)
ax2 = ax.twinx(); ax2.spines["top"].set_visible(False)
med = [c["median_Q"] for c in cls.values()]
ax2.plot(xs, med, "o--", color=OI["black"], ms=4, lw=1)
ax2.set_ylabel("median Q", fontsize=7)

ax = axes[1]
Qs = Q[Q > 0]
ax.hist(np.log10(Qs), bins=40, color=OI["sky"], alpha=0.8, density=True)
qcan = dt["canonical"]["Q"]
if qcan > 0:
    ax.axvline(np.log10(qcan), color=OI["verm"], lw=1.6)
    ax.text(np.log10(qcan)+0.05, ax.get_ylim()[1]*0.85,
            f"C1$\\wedge$C2$\\wedge$C3\nQ={qcan:.0f}", fontsize=7, color=OI["verm"])
ax.set_xlabel("$\\log_{10} Q$ (robustness)")
ax.set_ylabel("density of functional topologies")
ax.set_title("b  robustness distribution", fontsize=8.5)
fig.tight_layout(w_pad=2.0)
fig.savefig(os.path.join(FIG, "fig13_design_table.png"), dpi=600)
print("fig13 regenerated from corrected engine:",
      f"functional={dt['functional_count']}, canonical Q={qcan}, basin={dt['canonical']['basin']:.2f}")
